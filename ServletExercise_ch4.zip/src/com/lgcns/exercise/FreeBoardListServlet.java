package com.lgcns.exercise;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GuestBookListServlet
 */
@WebServlet(name = "FreeBoardList", urlPatterns = { "/freeboardList" })
public class FreeBoardListServlet extends HttpServlet {

	/**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	    // JDBC 드라이버 및 DB URL 정보
	    String driver = "oracle.jdbc.driver.OracleDriver";
	    String url = "jdbc:oracle:thin:@192.168.0.100:1521:VCC";

	    Connection con = null;
	    PreparedStatement stmt= null;
	    ResultSet rs = null;

	    // 게시글 목록 받을 ArrayList 선언
	    ArrayList<FreeBoardEntity> list = new ArrayList<FreeBoardEntity>();

	    try{
	        //JDBC 드라이버 로딩
    	    Class.forName(driver);
    	    //CONNECTION 획득(본인의 계정 입력)
    	    con = DriverManager.getConnection(url, "STUDENT##", "STUDENT##");

            //쿼리 작성
    	    String sql = "select bnum, content, writeDate, mid from freeboard order by bnum desc";

    	    // STATEMENT 생성
    	    stmt = con.prepareStatement(sql);

            //쿼리 수행
    	    rs = stmt.executeQuery();

            //수행 결과 처리
    	    while(rs.next()) {

    	        int bnum = rs.getInt("bnum");
    	        String content = rs.getString("content");
    	        String writeDate = rs.getString("writeDate");
    	        String mid = rs.getString("mid");
    	        System.out.println("번호 :"+bnum);
    	        System.out.println("내용 :"+content);
    	        System.out.println("작성일시 :"+writeDate);
    	        System.out.println("작성자ID:"+mid);

    	        list.add( new FreeBoardEntity(bnum, content, writeDate, mid));
    	    }


            // 게시물 내용 화면 전달
            HttpSession session = request.getSession();
            session.setAttribute("list", list);
            response.sendRedirect("freeboardList.jsp");


	    } catch(Exception e) {
	        e.printStackTrace();
	        //sendRedirect 사용
            HttpSession session = request.getSession();
            session.setAttribute("title", "오류 발생 - 글목록");
            session.setAttribute("type", "error");
            response.sendRedirect("message.jsp");

	    } finally {
	        try {
	            rs.close();
	            stmt.close();
	            con.close();
	        } catch(Exception e1) {
	            e1.printStackTrace();
	        }
	    }

	}

}
