package com.lgcns.exercise;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Login", urlPatterns = { "/login" })
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		// 화면에서 전달된 값
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        String pw = request.getParameter("pw");
        System.out.println("입력된 아이디->"+id);
        System.out.println("입력된 비밀번호->"+pw);

        // JDBC 드라이버 및 DB URL 정보
        String driver = "oracle.jdbc.driver.OracleDriver";
        String url = "jdbc:oracle:thin:@192.168.0.100:1521:VCC";

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        boolean result = false;
        String membername = "";

        try{
            //JDBC 드라이버 로딩
            Class.forName(driver);
            //Connection 획득
            con = DriverManager.getConnection(url, "STUDENT##", "STUDENT##");
            System.out.println("DB CONNETION 획득 완료");

            //쿼리작성
            String sql = "select membername from member where memberid = ? and memberpwd = ?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, pw);

            //쿼리 실행
            rs = stmt.executeQuery();

            if( rs.next()){
                result = true;
                membername = rs.getString(1);
                System.out.println("조회된 사용자 이름 : "+membername);
            }else{
                result = false;
            }

            //수행 결과처리
            if(result) {
                System.out.println("로그인 성공");

                //SESSION에 로그인 ID 정보 추가
                HttpSession session = request.getSession();
                session.setAttribute("loginID", id);
                session.setAttribute("loginName", membername);
                response.sendRedirect("loginSuccess.jsp");

            } else {
                System.out.println("로그인 실패");
                //SESSION에 메세지 정보 추가
                HttpSession session = request.getSession();
                session.setAttribute("title", "로그인 실패");
                session.setAttribute("type", "loginFail");
                response.sendRedirect("message.jsp");
            }


        }catch( Exception e){
           e.printStackTrace();
           //sendRedirect 사용
           HttpSession session = request.getSession();
           session.setAttribute("title", "오류 발생-로그인");
           session.setAttribute("type", "error");
           response.sendRedirect("message.jsp");

        }finally{
            try {
                rs.close();
                stmt.close();
                con.close();
            } catch(Exception e1) {
                e1.printStackTrace();
            }
        }


	}
}
