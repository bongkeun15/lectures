package com.lgcns.exercise;

public class FreeBoardEntity {

    private int bnum;
    private String content;
    private String writeDate;
    private String mid;

    public FreeBoardEntity() {}

    public FreeBoardEntity( int bnum, String content, String writeDate, String mid) {
        this.bnum = bnum;
        this.content = content;
        this.writeDate = writeDate;
        this.mid = mid;
    }

    public int getBnum() {
        return bnum;
    }
    public void setBnum(int bnum) {
        this.bnum = bnum;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public String getWriteDate() {
        return writeDate;
    }
    public void setWriteDate(String writeDate) {
        this.writeDate = writeDate;
    }

    public String getMid() {
        return mid;
    }
    public void setMid(String mid) {
        this.mid = mid;
    }



}
