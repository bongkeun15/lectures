package com.lgcns.exercise;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GuestBookListServlet
 */
@WebServlet(name = "FreeBoardWrite", urlPatterns = { "/write" })
public class FreeBoardWriteServlet extends HttpServlet {

	/**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	    // 화면에서 전달된 값
        request.setCharacterEncoding("UTF-8");
        String content = request.getParameter("content");
        System.out.println("입력된 내용->"+content);

	    //세션에서 사용자 ID가져오기
        HttpSession session = request.getSession();
        String loginID = (String)session.getAttribute("loginID");

	    // JDBC 드라이버 및 DB URL 정보
	    String driver = "oracle.jdbc.driver.OracleDriver";
	    String url = "jdbc:oracle:thin:@192.168.0.100:1521:VCC";

	    Connection con = null;
	    PreparedStatement stmt= null;


	    try{
	        //JDBC 드라이버 로딩
    	    Class.forName(driver);

    	    //CONNECTION 획득(본인의 계정 입력)
    	    con = DriverManager.getConnection(url, "STUDENT##", "STUDENT##");

            //쿼리 작성
    	    String sql = "INSERT INTO FREEBOARD(BNUM,CONTENT,WRITEDATE,MID) " +
    	    		     "VALUES ((SELECT MAX(bnum)+1 FROM FREEBOARD),? ,SYSDATE,?)";

    	    // STATEMENT 생성
    	    stmt = con.prepareStatement(sql);
            stmt.setString(1, content);
            stmt.setString(2, loginID);

            //쿼리 수행
    	    stmt.executeUpdate();
    	    con.commit();

            System.out.println("글쓰기 성공");

            //결과 메시지 처리 - sendRedirect 사용
            session.setAttribute("title", "글쓰기 성공");
            session.setAttribute("type", "writeSuccess");
            response.sendRedirect("message.jsp");

	    } catch(Exception e) {
	       e.printStackTrace();

           //오류 메시지 처리 - sendRedirect 사용
           session.setAttribute("title", "오류 발생 - 글쓰기");
           session.setAttribute("type", "error");
           response.sendRedirect("message.jsp");

           try{
        	   con.rollback();

           }catch(Exception e2){

        	   e2.printStackTrace();
           }

	    } finally {

	        try {
	            stmt.close();
	            con.close();
	        } catch(Exception e1) {
	            e1.printStackTrace();
	        }
	    }



	}

}
