package com.lgcns.workshop7.travel;

public class Travel implements Comparable<Travel> {
    
    private String travelCode;
    private String cityName;
    private String flight;
    private int travelType;
    private int maxPeople;
    
    public static final int INDIVIDUAL = 0;
    public static final int PACKAGE    = 1;
    
    public Travel( String travelCode, String cityName, String flight, int travelType, int maxPeople ) {
        this.travelCode = travelCode;
        this.cityName   = cityName;
        this.flight     = flight;
        this.travelType = travelType;
        this.maxPeople  = maxPeople;
    }
    
    public String getTravelCode() {
        return travelCode;
    }
    
    public int getTravelType() {
        return travelType;
    }
    
    public void setMaxPeople( int maxPeople ) {
        this.maxPeople = maxPeople;
    }
    
    public void printTravelInfo() {
        StringBuffer sb = new StringBuffer();
        sb.append(travelCode).append("\t").append(cityName).append("\t").append(flight).append("\t");
        
        if ( travelType == Travel.INDIVIDUAL ) {
        	sb.append("개별자유여행\t");
        } else if ( travelType == Travel.PACKAGE ) {
        	sb.append("패키지여행\t");
        }
        
        sb.append(maxPeople).append("명");
        System.out.println( sb );
    }

	
	public int compareTo(Travel travel) {
		
		int result = 0;
		
		if (this.travelCode.compareTo(travel.travelCode) < 0 ){
			result = -1;
			
		} else if (this.travelCode.compareTo(travel.travelCode) == 0){
			result = 0;
			
		} else {
			result = 1;
			
		}
		
		return result;
	}

}