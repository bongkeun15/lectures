package com.lgcns.workshop7.travel;

import java.util.Arrays;

import com.lgcns.workshop7.util.WorkshopUtil;

public class TravelTest {
    
    public static void main( String[] args ) {
        
        Travel[] travels = {
                
                new Travel( "TRV004", "오사카", "대한항공", Travel.INDIVIDUAL, 15 ),
                new Travel( "TRV003", "LA", "델타항공", Travel.PACKAGE, 12 ),
                new Travel( "TRV005", "상해", "남방항공", Travel.PACKAGE, 10 ),
                new Travel( "TRV001", "뮌헨", "독일항공", Travel.INDIVIDUAL, 10 ),
                new Travel( "TRV002", "프라하", "에어프랑스", Travel.INDIVIDUAL, 20 )
        };
        
        //sortTravelsWithApi(travels);  // api를 사용한 정렬
        sortTravelsWithoutApi(travels); // api를 사용하지 않은 정렬
        
        int menu = -1;
        while ( menu != 9 ) {
            
            TravelTest.printMenu();
            menu = WorkshopUtil.getUserIntegerInput();
            
            if ( menu == 1 ) {
                
                TravelTest.printHeader();
                
                for ( int inx = 0 ; inx < travels.length ; inx++ ) {
                    travels[inx].printTravelInfo();
                }
                
                TravelTest.printSeperator();
                
            } else if ( menu == 2 ) {

                TravelTest.printHeader();
                
                for ( int inx = 0 ; inx < travels.length ; inx++ ) {
                    if ( travels[inx].getTravelType() == Travel.INDIVIDUAL ) {
                        travels[inx].printTravelInfo();
                    }
                }
                
                TravelTest.printSeperator();
                
            } else if ( menu == 3 ) {
                
                TravelTest.printHeader();
                
                for ( int inx = 0 ; inx < travels.length ; inx++ ) {
                    if ( travels[inx].getTravelType() == Travel.PACKAGE ) {
                        travels[inx].printTravelInfo();
                    }
                }
                
                TravelTest.printSeperator();
                
            } else if ( menu == 4 ) {
                
            	boolean updateFlag = false;
            	
                System.out.print( ">> 여행 코드를 입력하세요 : " );
                String travelCode = WorkshopUtil.getCodeInput();
                
                System.out.print( ">> 변경할 최대 예약 인원 수를 입력하세요 : " );
                int maxPeople = WorkshopUtil.getUserIntegerInput();
                
                if(maxPeople < 0 ){
                	System.out.println(">> [에러]최대인원은 0보다 큰 값이어야 합니다.");
                	continue;
                }
                
                for ( int inx = 0 ; inx < travels.length ; inx++ ) {
                    if ( travelCode.equals( travels[inx].getTravelCode() ) ) {
                        travels[inx].setMaxPeople( maxPeople );
                        System.out.println(">> 최대예약 인원수가 " + maxPeople+ "명으로 변경되었습니다.");
                        updateFlag = true;
                    }
                }
                
                if (!updateFlag) System.out.println("여행상품 코드 [" + travelCode + "]에 해당하는 상품을 찾을 수 없습니다.");
                
                updateFlag = false;
                
            } else if ( menu == 9 ) {
                System.out.println( ">> 종료합니다!!" );
            } else {
                System.out.println( ">> 다시 입력하세요!!" );
            }
        }
    }
    
    public static void sortTravelsWithApi(Travel [] travels){
    	Arrays.sort(travels);
    }
    
    public static void sortTravelsWithoutApi(Travel [] travels){
    
    	quickSort( travels, 0, travels.length-1);
    }
    
    public static int partition(Travel [] travels, int left, int right) {

    	String pivot = travels[(left + right) / 2].getTravelCode();

    	while ( left < right ) {
    		
    		while ((travels[left].getTravelCode().compareTo(pivot) < 0)	&& (left < right) )
    			left++;
    		
    		while ((travels[right].getTravelCode().compareTo(pivot) > 0) && (left < right) )
    			right--;

    		if (left < right) {
    			Travel temp = travels[left];
    			travels[left] = travels[right];
    			travels[right] = temp;
    		}
    	}

    	return left;
    }

    public static void quickSort(Travel [] travels, int left, int right) {

    	if (left < right) {
    		int pivotNewIndex = partition(travels, left, right);
    		quickSort(travels, left, pivotNewIndex - 1);
    		quickSort(travels, pivotNewIndex + 1, right);
    	}
    }
    
    public static void printMenu() {
    	StringBuffer sb = new StringBuffer();
    	sb.append("======== << 메뉴 >> ========\n")
    		.append(" 1. 전체 여행 상품 조회\n")
    		.append(" 2. 개별 자유여행 상품 조회\n")
    		.append(" 3. 패키지여행 상품 조회\n")
    		.append(" 4. 최대 예약 인원 변경\n")
    		.append(" 9. 종료\n")
    	    .append("=========================\n")
    	    .append("## 메뉴입력 :  ");
    	System.out.print(sb);
    }
    
    public static void printHeader() {
        printSeperator();
        System.out.println( "여행코드\t도시명\t항공편\t여행유형\t최대예약가능인원" );
        printSeperator();
    }
    
    public static void printSeperator() {
        System.out.println( "---------------------------------------------------------------------------------------" );
    }
}