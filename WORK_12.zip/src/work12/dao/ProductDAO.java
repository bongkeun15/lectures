package work12.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import work12.common.JdbcTemplate;
import work12.entity.CommentEntity;
import work12.entity.MessageEntity;
import work12.entity.ProductDetailEntity;
import work12.entity.ProductEntity;
import work12.exception.CommonException;



public class ProductDAO {

	//상품 등록
	public void productAdd(Connection con, ProductEntity entity)throws CommonException {

		PreparedStatement pstmt = null;
		try {

			String sql = "insert into product ( product_id,category_id,product_name,product_price,product_info,product_company,product_quantity,seller_id )"
					+ " values ( ? , ? , ?, ? ,? ,? ,? , ?) ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, entity.getProductId());
			pstmt.setString(2, entity.getCategoryId());
			pstmt.setString(3, entity.getProductName());
			pstmt.setInt(4, entity.getProductPrice());
			pstmt.setString(5, entity.getProductInfo());
			pstmt.setString(6, entity.getProductCompany());
			pstmt.setInt(7, entity.getProductQuantity());
			pstmt.setString(8, entity.getSellerId());

			int result = pstmt.executeUpdate();
			
			if(result == 0) {
				throw new Exception();
			}
	
		} catch (Exception e) {
		
			MessageEntity message = new MessageEntity("error", 7);
			message.setUrl("/work/work12/product/productAddForm.html");
			message.setLinkTitle("상품 등록");
			throw new CommonException(message);
		} finally {

			JdbcTemplate.close(pstmt);
		}
	}// end consumerAdd

	// 모든 상품목록 보기
		public ArrayList<ProductEntity> productAllList(Connection con) throws CommonException{

	
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
			try {

				String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date ,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				while (rs.next()) {

					String product_id = rs.getString("product_id");
					String category_id = rs.getString("category_id");
					String product_name = rs.getString("product_name");
					int product_price = rs.getInt("product_price");
					String product_info = rs.getString("product_info");
					String product_company = rs.getString("product_company");
					String product_date = rs.getString("product_date");
					int product_quantity = rs.getInt("product_quantity");
					String seller_id = rs.getString("seller_id");
					String category_name = rs.getString("large") + "-"
							+ rs.getString("middle");
					ProductEntity entity = new ProductEntity(product_id,
							category_id, product_name, product_price,
							product_company, product_quantity, product_info,
							product_date, seller_id);
					entity.setCategoryName(category_name);
					list.add(entity);
				}
			} catch (Exception e) {
				MessageEntity message = new MessageEntity("error", 8);
				message.setUrl("/work/work12/login");
				message.setLinkTitle("로그인");
				throw new CommonException(message);
			} finally {

				JdbcTemplate.close(rs);
				JdbcTemplate.close(pstmt);
			}

			return list;
		}
		
	// 특정 판매자 상품목록
	public ArrayList<ProductEntity> productList(Connection con,String id)throws CommonException {


		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
		try {

			String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id and seller_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String product_id = rs.getString("product_id");
				String category_id = rs.getString("category_id");
				String product_name = rs.getString("product_name");
				int product_price = rs.getInt("product_price");
				String product_info = rs.getString("product_info");
				String product_company = rs.getString("product_company");
				String product_date = rs.getString("product_date");
				int product_quantity = rs.getInt("product_quantity");
				String seller_id = rs.getString("seller_id");
				String category_name = rs.getString("large") + "-"
						+ rs.getString("middle");
				ProductEntity entity = new ProductEntity(product_id,
						category_id, product_name, product_price,
						product_company, product_quantity, product_info,
						product_date, seller_id);
				entity.setCategoryName(category_name);
				list.add(entity);
			}
		} catch (Exception e) {
			MessageEntity message = new MessageEntity("error", 8);
			message.setUrl("/work/work12/login");
			message.setLinkTitle("로그인");
			throw new CommonException(message);
		} finally {

			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
		}

		return list;
	}


	// 구매자 상품 검색
		public ArrayList<ProductEntity> productPurchaserSearch( Connection con , String searchName,
				String searchValue) throws CommonException {
			
			ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
			
			
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			try {

				String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id ";
				if ("productName".equals(searchName)) {
					sql += " and product_name LIKE ?";
				} else {
					sql += " and product_company LIKE ?";
				}
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%" + searchValue + "%");
				rs = pstmt.executeQuery();
				while (rs.next()) {

					String product_id = rs.getString("product_id");
					String category_id = rs.getString("category_id");
					String product_name = rs.getString("product_name");
					int product_price = rs.getInt("product_price");
					String product_info = rs.getString("product_info");
					String product_company = rs.getString("product_company");
					String product_date = rs.getString("product_date");
					int product_quantity = rs.getInt("product_quantity");
					String seller_id = rs.getString("seller_id");
					String category_name = rs.getString("large") + "-"
							+ rs.getString("middle");
					ProductEntity entity = new ProductEntity(product_id,
							category_id, product_name, product_price,
							product_company, product_quantity, product_info,
							product_date, seller_id);
					entity.setCategoryName(category_name);
					list.add(entity);
				}
			} catch (Exception e) {
				MessageEntity message = new MessageEntity("error", 8);
				message.setUrl("/work/work12/productList");
				message.setLinkTitle("상품 목록");
				throw new CommonException(message);
			} finally {
				
				JdbcTemplate.close(rs);
				JdbcTemplate.close(pstmt);

			}
			return list;
		}
		
		// 판매자 상품 검색
		public ArrayList<ProductEntity> productSellerSearch(Connection con ,  String sellerId, String searchName,
				String searchValue) throws CommonException {
			
			ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
			
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			try {

				String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id ";
				if ("productName".equals(searchName)) {
					sql += " and product_name LIKE ? and seller_id = ?";
				} else {
					sql += " and product_company LIKE ? and seller_id = ?";
				}
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%" + searchValue + "%");
				pstmt.setString(2, sellerId);
				rs = pstmt.executeQuery();
				while (rs.next()) {

					String product_id = rs.getString("product_id");
					String category_id = rs.getString("category_id");
					String product_name = rs.getString("product_name");
					int product_price = rs.getInt("product_price");
					String product_info = rs.getString("product_info");
					String product_company = rs.getString("product_company");
					String product_date = rs.getString("product_date");
					int product_quantity = rs.getInt("product_quantity");
					String seller_id = rs.getString("seller_id");
					String category_name = rs.getString("large") + "-"
							+ rs.getString("middle");
					ProductEntity entity = new ProductEntity(product_id,
							category_id, product_name, product_price,
							product_company, product_quantity, product_info,
							product_date, seller_id);
					entity.setCategoryName(category_name);
					list.add(entity);
				}
			} catch (Exception e) {
				MessageEntity message = new MessageEntity("error", 8);
				message.setUrl("/work/work12/productList");
				message.setLinkTitle("상품 목록");
				throw new CommonException(message);
			} finally {
				
				JdbcTemplate.close(rs);
				JdbcTemplate.close(pstmt);
		
			}
			return list;
		}
		
	//제품 상세보기
		public ArrayList<ProductDetailEntity> productDetail(Connection con,String productId)throws CommonException{
			

			PreparedStatement pstmt = null;
			ResultSet rs = null;
			ArrayList<ProductDetailEntity> list= new ArrayList<ProductDetailEntity>();
			try {

				String sql = "select product.product_id,product.category_id, product.product_name,product.product_price, product.product_quantity, product.product_company, "
						+ " product.product_info, prodComment.comm_content, prodComment.comm_score, prodOrder.purchaser_id , c.category_large as large , c.category_middle as middle from product , prodOrder , prodComment , category c "
						+ " where product.product_id = prodOrder.product_id (+)  and prodOrder.order_id = prodComment.order_id  and product.category_id = c.category_id and product.product_id = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, productId);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					
					String p_id = rs.getString("product_id");
					String category_id = rs.getString("category_id");
					String product_name = rs.getString("product_name");
					int product_price = rs.getInt("product_price");
					int product_quantity = rs.getInt("product_quantity");
					String product_company = rs.getString("product_company");
					String product_info = rs.getString("product_info");
					String comm_content = rs.getString("comm_content");
					String comm_score = rs.getString("comm_score");
					String purchaser_id = rs.getString("purchaser_id");
					String category_name = rs.getString("large") + "-"
							+ rs.getString("middle");
					
					ProductDetailEntity detailEntity = new ProductDetailEntity();
					CommentEntity commentEntity = new CommentEntity(purchaser_id, comm_content, comm_score);
					detailEntity.setCommentEntity(commentEntity);
					detailEntity.setProductId(p_id);
					detailEntity.setCategoryId(category_id);
					detailEntity.setCategoryName(category_name);
					detailEntity.setProductName(product_name);
					detailEntity.setProductPrice(product_price);
					detailEntity.setProductQuantity(product_quantity);
					detailEntity.setProductCompany(product_company);
					detailEntity.setProductInfo(product_info);
					list.add(detailEntity);
				}
			} catch (SQLException e) {
				MessageEntity message = 
						new MessageEntity("error",15);
				message.setUrl("/work/work12/productList");
				message.setLinkTitle("제품 상세보기 화면으로");
				throw new CommonException(message);
			} finally {

				JdbcTemplate.close(rs);
				JdbcTemplate.close(pstmt);
			}

			return list;
		}
}// end class
