/*
 *  1. 관리자 페이지 처리 서블릿
 *   - 로그인이 성공후에 사용 가능하다.
 *   
 *  2. 주요 처리는 다음과 같다.
 *   - 우수상품 리스트 구하기
 *   - 우수 고객 리스트 구하기
 *   - 만족도 리스트 구하기
 */


package work12.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class SellerManageServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/*
		 *  
		 *  1. SellerBiz의 getBestProduct() 메소드를 사용하여 우수상품 목록를 구한다.
		 *     SellerBiz의 getBestPurchaser() 메소드를 사용하여 우수고객 목록를 구한다.
		       SellerBiz의 getBestSatisfaction() 메소드를 사용하여 만족도 목록를 구한다.
		       
		 *  2. 성공시 sellerManageList.jsp.jsp로 RequestDispatcher 처리하고 실패시 
		 *      MessageEntity 클래스를 참고하여 메시지를 작성하고 
 				RequestDispatcher로 처리한다.
	            
		 * 
		 *   3. 로그인이 되지 않은 상황에서 요청이 된 경우에는 다음 방법으로 메시지를 출력한다.
		 *   
		 *     MessageEntity message = new MessageEntity("message", 0);
			   message.setUrl("loginForm.html");
			   message.setLinkTitle("로그인");
			   request.setAttribute("message", message);
			   RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
			   dis.forward(request, response);
		 *   
		 */
		
	}

}
