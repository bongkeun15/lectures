package work12.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work12.biz.CartBiz;
import work12.entity.CartEntity;
import work12.entity.MessageEntity;
import work12.exception.CommonException;
import work12.util.ValidationUtil;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work12.ProductCartAdd", urlPatterns = { "/work12/productCartAdd" })
public class ProductCartAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			String productId = request.getParameter("productId"); // 상품 아이디
			String purchaserId = request.getParameter("purchaserId"); // 구매자 아이디
			int cartQuantity = 0;
			if (request.getParameter("cartQuantity") != ""
					&& ValidationUtil.checkDigit(request
							.getParameter("cartQuantity"))) {
				cartQuantity = Integer.parseInt(request
						.getParameter("cartQuantity"));

			} else {
				MessageEntity message = new MessageEntity("validation", 8);
				message.setUrl("/work/work12/productList");
				message.setLinkTitle("장바구니 등록");
				request.setAttribute("message", message);
				RequestDispatcher dis = request
						.getRequestDispatcher("message.jsp");
				dis.forward(request, response);
				return;
			}

			CartBiz biz = new CartBiz();

			try {
				CartEntity entity = new CartEntity();
				entity.setProductId(productId);
				entity.setPurchaserId(purchaserId);
				entity.setCartQuantity(cartQuantity);

				biz.productAddCart(entity);
				// 성공
				MessageEntity message = new MessageEntity("success", 2);
				message.setUrl("/work/work12/productCartList");
				message.setLinkTitle("장바구니 목록");
				request.setAttribute("message", message);

			} catch (CommonException e) {
				request.setAttribute("message", e.getMessageEntity());

			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);

		}
		RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
		dis.forward(request, response);
	}

}
