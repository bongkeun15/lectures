package work12.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work12.biz.ProductBiz;
import work12.entity.MessageEntity;
import work12.entity.ProductDetailEntity;
import work12.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work12.ProductDetail", urlPatterns = { "/work12/productDetail" })
public class ProductDetailServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
			String productId = request.getParameter("productId"); // 상품 아이디

			ProductBiz biz = new ProductBiz();
			ArrayList<ProductDetailEntity> list;
			try {
				list = biz.productDetail(productId);
				request.setAttribute("productDetailList", list);

				RequestDispatcher dis = request
						.getRequestDispatcher("product/productDetailList.jsp");
				dis.forward(request, response);
			} catch (CommonException e) {
				RequestDispatcher dis = request
						.getRequestDispatcher("message.jsp");
				request.setAttribute("message", e.getMessageEntity());
				dis.forward(request, response);
			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);
			RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
			dis.forward(request, response);
		}

	}

}
