package work12.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import work12.biz.PurchaserBiz;
import work12.entity.MessageEntity;
import work12.entity.PurchaserEntity;
import work12.exception.CommonException;
import work12.util.ValidationUtil;

/**
 * Servlet implementation class ConsumerServlet
 */

@WebServlet(name = "work12.PurchaserAdd", urlPatterns = { "/work12/purchaserAdd" })
public class PurchaserAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		// 파라미터 추출
		String purchaserId = request.getParameter("purchaserId");
		String purchaserPw = request.getParameter("purchaserPw");
		String purchaserName = request.getParameter("purchaserName");
		String purchaserAddr = request.getParameter("purchaserAddr");
		String purchaserPhone1 = request.getParameter("purchaserPhone1");
		String purchaserPhone2 = request.getParameter("purchaserPhone2");
		String purchaserPhone3 = request.getParameter("purchaserPhone3");
		String purchaserEmail = request.getParameter("purchaserEmail");
		String purchaserPhone = purchaserPhone1 + "-" + purchaserPhone2
				+ "-" + purchaserPhone3;
		
		// 유효성 검사

		if (! ValidationUtil.checkRequired(purchaserId) || ! ValidationUtil.checkAlphaDigit(purchaserId)
				|| ! ValidationUtil.lessLength(purchaserId, 10)) {

			MessageEntity message = new MessageEntity("validation", 0); // [아이디
																		// 정보
																		// 오류]
			message.setUrl("/work/work12/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			request.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserPw) || ! ValidationUtil.checkRequired(purchaserPw)
				|| ! ValidationUtil.lessLength(purchaserPw, 10)) {
			MessageEntity message = new MessageEntity("validation", 1); // [비밀번호
																		// 정보
																		// 오류]
			message.setUrl("/work/work12/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			request.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserName)
				|| ! ValidationUtil.lessLength(purchaserName, 10)) {

			MessageEntity message = new MessageEntity("validation", 2); // [이름
																		// 정보
																		// 오류]
			message.setUrl("/work/work12/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			request.setAttribute("message", message);
		} else if (! ValidationUtil.checkRequired(purchaserAddr)) {

			MessageEntity message = new MessageEntity("validation", 3); // [ 주소
																		// 정보
																		// 오류]
			message.setUrl("/work/work12/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			request.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserPhone1)
				|| ! ValidationUtil.checkRequired(purchaserPhone2)
				|| ! ValidationUtil.checkRequired(purchaserPhone3)
				|| ! ValidationUtil.checkDigit(purchaserPhone1)
				|| ! ValidationUtil.lessLength(purchaserPhone1, 5)
				|| ! ValidationUtil.checkDigit(purchaserPhone2)
				|| ! ValidationUtil.lessLength(purchaserPhone2, 5)
				|| ! ValidationUtil.checkDigit(purchaserPhone3)
				|| ! ValidationUtil.lessLength(purchaserPhone3, 5)) {

			MessageEntity message = new MessageEntity("validation", 4);
			message.setUrl("/work/work12/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			request.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserEmail)) {

			MessageEntity message = new MessageEntity("validation", 5);
			message.setUrl("/work/work12/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			request.setAttribute("message", message);

		} else {

			
			
			PurchaserBiz biz = new PurchaserBiz();
			PurchaserEntity entity = new PurchaserEntity(purchaserId,
					purchaserPw, purchaserName, purchaserAddr,
					purchaserPhone, purchaserEmail, 0);
			try {
				biz.purchaserAdd(entity);

				// 성공
				MessageEntity message = new MessageEntity("success", 7);
				message.setUrl("/work/work12/loginForm.html");
				message.setLinkTitle("로그인");
				request.setAttribute("message", message);

			} catch (CommonException e) {
				
	
				request.setAttribute("message", e.getMessageEntity());
			}
		}
		RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
		dis.forward(request, response);

	}// end doPost

	
}// end class
