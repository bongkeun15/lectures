package work12.entity;

public class PurchaserEntity {
	
	private String purchaserId; 	// 구매자 아이디
	private String purchaserPw;		// 구매자 비번
	private String purchaserName;	// 구매자 이름
	private String purchaserAddr;	// 구매자 주소
	private String purchaserPhone;	// 구매자 전화번호
	private String purchaserEmail;	// 구매자 이메일
	private int purchaserScore; // 구매자 점수
	
	private String purchaserGrade; // 구매자 등급 예> A   grade테이블의 grade_id값

	public String getPurchaserId() {
		return purchaserId;
	}

	public void setPurchaserId(String purchaserId) {
		this.purchaserId = purchaserId;
	}

	public String getPurchaserPw() {
		return purchaserPw;
	}

	public void setPurchaserPw(String purchaserPw) {
		this.purchaserPw = purchaserPw;
	}

	public String getPurchaserName() {
		return purchaserName;
	}

	public void setPurchaserName(String purchaserName) {
		this.purchaserName = purchaserName;
	}

	public String getPurchaserAddr() {
		return purchaserAddr;
	}

	public void setPurchaserAddr(String purchaserAddr) {
		this.purchaserAddr = purchaserAddr;
	}

	public String getPurchaserPhone() {
		return purchaserPhone;
	}

	public void setPurchaserPhone(String purchaserPhone) {
		this.purchaserPhone = purchaserPhone;
	}

	public String getPurchaserEmail() {
		return purchaserEmail;
	}

	public void setPurchaserEmail(String purchaserEmail) {
		this.purchaserEmail = purchaserEmail;
	}

	public int getPurchaserScore() {
		return purchaserScore;
	}

	public void setPurchaserScore(int purchaserScore) {
		this.purchaserScore = purchaserScore;
	}

	public String getPurchaserGrade() {
		return purchaserGrade;
	}

	public void setPurchaserGrade(String purchaserGrade) {
		this.purchaserGrade = purchaserGrade;
	}

	public PurchaserEntity(String purchaserId, String purchaserPw,
			String purchaserName, String purchaserAddr, String purchaserPhone,
			String purchaserEmail, int purchaserScore) {
		super();
		this.purchaserId = purchaserId;
		this.purchaserPw = purchaserPw;
		this.purchaserName = purchaserName;
		this.purchaserAddr = purchaserAddr;
		this.purchaserPhone = purchaserPhone;
		this.purchaserEmail = purchaserEmail;
		this.purchaserScore = purchaserScore;

	}

	public PurchaserEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
