/*
 *  - 우수상품 정보를 관리하는 entity 클래스.
 *  - ProductEntity 클래스를 상속받는다.
 * 
 */


package work12.entity;

public class BestProductEntity extends ProductEntity {

	private int saleQuantity; //판매수량



	  public BestProductEntity(String product_id,
				String product_name, int product_price, String product_company,
				String product_date,int sale_quantity) {
			super(product_id, null, product_name, product_price,
					product_company, 0, null, product_date,
					null);
			this.saleQuantity = sale_quantity;
		}


	public int getSaleQuantity() {
		return saleQuantity;
	}


	public void setSaleQuantity(int saleQuantity) {
		this.saleQuantity = saleQuantity;
	}

	  
}
