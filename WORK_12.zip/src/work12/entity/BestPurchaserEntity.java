/*
 *  - 우수고객 정보를 관리하는 entity 클래스.
 *  - PurchaserEntity 클래스를 상속받는다.
 * 
 */

package work12.entity;

public class BestPurchaserEntity extends PurchaserEntity {

	private int totalPrice;  // 구매 금액

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int total_price) {
		this.totalPrice = total_price;
	}
 
    
}
