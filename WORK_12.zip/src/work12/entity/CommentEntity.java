package work12.entity;

public class CommentEntity {

	private String purchaserId;
	private String commContent;
	private String commScore;
	public String getPurchaserId() {
		return purchaserId;
	}
	public void setPurchaserId(String purchaserId) {
		this.purchaserId = purchaserId;
	}
	public String getCommContent() {
		return commContent;
	}
	public void setCommContent(String commContent) {
		this.commContent = commContent;
	}
	public String getCommScore() {
		return commScore;
	}
	public void setCommScore(String commScore) {
		this.commScore = commScore;
	}
	public CommentEntity(String purchaserId, String commContent,
			String commScore) {
		super();
		this.purchaserId = purchaserId;
		this.commContent = commContent;
		this.commScore = commScore;
	}
	public CommentEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
