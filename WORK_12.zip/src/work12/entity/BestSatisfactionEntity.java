/*
 *  - 만족도 정보를 관리하는 entity 클래스.
 * 
 */

package work12.entity;

public class BestSatisfactionEntity {

	private String productId;
	private String productName;
	private double scoreAvg;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getScoreAvg() {
		return scoreAvg;
	}
	public void setScoreAvg(double scoreAvg) {
		this.scoreAvg = scoreAvg;
	}
	public BestSatisfactionEntity(String productId, String productName,
			double scoreAvg) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.scoreAvg = scoreAvg;
	}
	public BestSatisfactionEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
}
