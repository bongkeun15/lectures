package work12.biz;

import java.sql.Connection;

import work12.common.JdbcTemplate;
import work12.dao.PurchaserDAO;
import work12.entity.PurchaserEntity;
import work12.exception.CommonException;



public class PurchaserBiz {
	
	//회원가입
	public void purchaserAdd(PurchaserEntity entity) throws CommonException{
		PurchaserDAO dao = new PurchaserDAO();
		Connection con = JdbcTemplate.getConnection();
	
	   try{
		
		dao.purchaserAdd(con, entity);
		JdbcTemplate.commit(con);
	   } catch (CommonException e) {
		   JdbcTemplate.rollback(con);
			throw e;
	   }finally{
		   JdbcTemplate.close(con);
	   }
	}
	
	//로그인
	public PurchaserEntity login(String id, String pw)throws CommonException{
		PurchaserDAO dao = new PurchaserDAO();
		Connection con = JdbcTemplate.getConnection();
		
		try{
	
			return dao.login(con , id, pw);
		} catch (CommonException e) {
				throw e;
		   }finally{
			   JdbcTemplate.close(con);
		   }
	}

	 //회원수정화면보기
    public PurchaserEntity purchaserUpdateForm(String id)throws CommonException{
    	
    	  PurchaserDAO dao = new PurchaserDAO();
    	Connection con = JdbcTemplate.getConnection();
    	
 	   try{
 		
 	    	return dao.purchaserUpdateForm(con , id);
 	  } catch (CommonException e) {
			throw e;
 	   }finally{
 		  JdbcTemplate.close(con);
 	   }
    	
    }
    
    //회원수정
    public void purchaserUpdate(PurchaserEntity entity)throws CommonException{
    	
    	PurchaserDAO dao = new PurchaserDAO();
    	Connection con = JdbcTemplate.getConnection();
    	
    	 try{
    		 
    	       dao.purchaserUpdate(con, entity);
    	       JdbcTemplate.commit(con);
    	 } catch (CommonException e) {
    		 JdbcTemplate.rollback(con);
				throw e;
    	   }finally{
    		   JdbcTemplate.close(con);
    	   }
    	 
    	
    }
}
