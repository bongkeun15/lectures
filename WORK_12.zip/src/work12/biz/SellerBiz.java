package work12.biz;

import java.sql.Connection;

import work12.common.JdbcTemplate;
import work12.dao.SellerDAO;
import work12.entity.SellerEntity;
import work12.exception.CommonException;




public class SellerBiz {

	// 회원가입
	public void sellerAdd(SellerEntity entity)throws CommonException {
		
		SellerDAO dao = new SellerDAO();
		Connection con = JdbcTemplate.getConnection();

		try {

			
			dao.sellerAdd(con, entity);
			 JdbcTemplate.commit(con);
		}catch (CommonException e) {
	    		 JdbcTemplate.rollback(con);
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}
		
		
	

	}

	// 로그인
	public SellerEntity login(String id, String pw) throws CommonException{
		  SellerDAO dao = new SellerDAO();
		Connection con = JdbcTemplate.getConnection();
		
		   try{
			 
				return dao.login(con , id, pw);
		   }catch (CommonException e) {
	    		 
			throw e;
		   }finally{
			   JdbcTemplate.close(con);
		   }
		   
		
	}

	// 회원수정 화면
	public SellerEntity sellerUpdateForm(String id)throws CommonException {
		SellerDAO dao = new SellerDAO();
		Connection con = JdbcTemplate.getConnection();

		try {

			
			return dao.sellerUpdateForm(con, id);
		 }catch (CommonException e) {
    		 
				throw e;
		} finally {
			JdbcTemplate.close(con);
		}
		
	
	}

	// 회원수정
	public void sellerUpdate(SellerEntity entity)throws CommonException {
		SellerDAO dao = new SellerDAO();
		Connection con = JdbcTemplate.getConnection();

		try {

			
			dao.sellerUpdate(con, entity);
			JdbcTemplate.commit(con);
		}catch (CommonException e) {
			JdbcTemplate.rollback(con);
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}
	}
	
	

}
