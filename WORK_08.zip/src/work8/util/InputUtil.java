/*
 *   키보드에서 입력받을때 사용하는 유틸리티 클래스
 *   
 *   1. 문자열 입력 처리는 readString() 메소드 사용
 *   2. 정수 입력 처리는 readNumber() 메소드 사용
 * 
 */

package work8.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputUtil {
	public static String readString() {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String msg = "";
		try {
			msg = in.readLine().trim();		
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return msg;
	}

	public static int readNumber() {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int number = 0;
		try {
			number = Integer.parseInt(in.readLine());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return number;
	}

}
