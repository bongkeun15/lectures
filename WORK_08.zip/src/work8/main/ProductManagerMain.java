/*
 * 
 *   상품관리 프로그램의 main 클래스.
 * 
 */

package work8.main;

import static work8.util.InputUtil.readNumber;
import static work8.util.InputUtil.readString;

import java.sql.SQLException;
import java.util.ArrayList;

import work8.product.ProductEntity;
import work8.product.ProductManager;

public class ProductManagerMain {
	static ProductManager manager = new ProductManager();

	public static void main(String[] args) {
		System.out.println("[상품관리 프로그램]");

		printLine();
		printMenu();
		int menu;
		while ((menu = readNumber()) != 5) {
			/*
			 *  sample run을 확인하고 적절한 코드 작업하기
			 * 
			 */
		}
		printLine();
		System.out.println("프로그램을 종료 합니다.");
	}

	private static void deleteProduct() throws SQLException {

		/*  1. 적절한 메시지를 출력한다.
		 *  2. 키보드에서 데이터를 입력받는다.
		 *  3. ProductManager 클래스의 deleteProduct() 메소드를 호출하여 상품을 삭제한다.
		 *  4. 실행결과는 Sample run을 참고한다.
		 */
		
	}

	private static void updateProduct() throws SQLException {
	
		/*  1. 적절한 메시지를 출력한다.
		 *  2. 키보드에서 데이터를 입력받는다.
		 *  3. ProductManager 클래스의 deleteProduct() 메소드를 호출하여 상품을 삭제한다.
		 *  4. 실행결과는 Sample run을 참고한다.
		 */
	}

	private static void insertProduct() throws SQLException {

		/*
		 *  1. 적절한 메시지를 출력한다.
		 *  2. 입력받은 데이터를 저장한다.
		 *  3. ProductManager 클래스의 insertProduct() 메소드를 호출하여 상품을 저장한다.
		 *  4. 실행결과는 Sample run을 참고한다.
		 */
	}

	public static void searchProduct() throws SQLException {
		int menu;
		while ((menu = readNumber()) != 5) {
	
			switch (menu) {
			case 1:
				System.out.print("상품 ID를 입력하세요 :");
				/*
				 *   1. 키보드로 입력 받는다.
				 *   2. 입력받은 데이터로 적절한 코드 작업 구현
				 */
	
				break;
			case 2:
				System.out.print("상품 카테고리명을 입력하세요 : ");
				/*
				 *   1. 키보드로 입력 받는다.
				 *   2. 입력받은 데이터로 적절한 코드 작업 구현
				 */
				break;
			case 3:
				System.out.print("최소값을 입력하세요. : ");
				int min = readNumber();
				System.out.print("최대값을 입력하세요. : ");
				int max = readNumber();
				/*
				 *   1. 키보드로 입력 받는다.
				 *   2. 입력받은 데이터로 적절한 코드 작업 구현
				 */
				break;
			case 4:
				/*
				 *   1. 키보드로 입력 받는다.
				 *   2. 입력받은 데이터로 적절한 코드 작업 구현
				 */
				break;
			default : 
				System.out.println("메뉴 번호를 확인해 주세요.");
			}
			printLine();
			printSearchMenu();
		}
	}

	public static void printAllProduct(ArrayList<ProductEntity> products) {
		if (products == null || products.size() == 0) {
			System.out.println("조회된 상품이 없습니다.");
			return;
		}
		/*
		 *   1. ArrayList에 저장된 데이터 출력하기
		 *   2. toString 메소드 이용하여 출력하기
		 */
	}

	public static void printProduct(ProductEntity entity) {
		if (entity != null) {
			System.out.println("상품 조회 완료 : " + entity);
		} else {
			System.out.println("조회된 상품이 없습니다.");
		}
	}

	public static void printLine() {
		System.out.println("----------------------------------");
	}

	public static void printSearchMenu() {
		System.out.println("1. ID 로 상품 검색");
		System.out.println("2. 카테고리별 상품 검색");
		System.out.println("3. 가격대별 상품 검색");
		System.out.println("4. 전체 상품 검색");
		System.out.println("5. 메인 메뉴");
		printLine();
		System.out.print("원하는 메뉴 번호를 입력 하세요[ 1- 5] : ");
	}

	public static void printMenu() {
		System.out.println("1. 상품 검색");
		System.out.println("2. 상품 입력");
		System.out.println("3. 상품 수량 수정");
		System.out.println("4. 상품 삭제");
		System.out.println("5. 프로그램 종료");
		printLine();
		System.out.print("원하는 메뉴 번호를 입력 하세요[ 1- 5] : ");
	}
}
