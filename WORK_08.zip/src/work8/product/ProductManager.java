/*
 * 
 *   JDBC 연동 핵심 클래스
 */

package work8.product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductManager {
	private Connection con;
	public ProductManager(){
		
		/*
		 *   JDBC 기술을 사용하여 데이터베이스 연동하기 위하여 Connection을 얻는다.
		 *   
		 *   드라이버명: oracle.jdbc.driver.OracleDriver
		 *   url: jdbc:oracle:thin:@192.168.0.100:1521:VCC
		 *   id: student##
		 *   pw: student##
		 */
		
	}
	public void closeCon(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ProductEntity searchProduct(String pid)throws SQLException{
		
		/*  1. ID 로 상품 검색
		 *   pid와 일치하는 데이터를 테이블에서 검색하여 리턴한다.
		 */
		
		return null;
	}
	public ArrayList<ProductEntity> serarchProductWithPrice(int min, int max) throws SQLException{
		
		/*   1. 가격대별 상품 검색
		 *   가격대별  min값과 max값에 해당되는 데이터를 검색하여 리턴한다.
		 */

		return null;
	}
	public ArrayList<ProductEntity> serarchProductWithCategoryName(String categoryName) throws SQLException{
		
		/*   1. 카테고리별 상품 검색
		 *   categoryName와 일치하는 데이터를 검색하여 리턴한다.
		 */
	
		return null;
	}
	public ArrayList<ProductEntity> getAllProduct() throws SQLException{

		/*   1. 전체 상품 검색
		 *   모든 상품 데이터를 검색하여 리턴한다.
		 */
		
		return null;
	}

	public int insertProduct(ProductEntity product) throws SQLException{
		
		/*   1. 상품 등록
		 *   데이터를 저장하고 결과값은 int로 리턴한다.
		 */
	
		return 0;
	}
	public int updateProductQuantity(String pid, int amount) throws SQLException{
		/*   1. 상품 수정
		 *  pid와 일치하는 데이터를 amount로 수정하고 결과값은 int로 리턴한다.
		 */
	
		return 0;
	}
	public int deleteProduct(String pid) throws SQLException{
		
		/*   1. 상품 삭제
		 *  pid와 일치하는 데이터를 삭제하고 결과값은 int로 리턴한다.
		 */
	
		return 0;
	}
}
