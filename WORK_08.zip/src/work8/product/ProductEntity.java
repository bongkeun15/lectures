/*
 *    상품관련 정보 저장 entity 클래스
 * 
 */

package work8.product;

public class ProductEntity {
	private String id; 
	private int price;
	private String categoryName;
	private String name;
	private int quantity;
	
	public ProductEntity() {
		super();
		// TODO Auto-generated constructor stub
	}	
	
	public ProductEntity(String id, String name, int price, int quantity, String categoryName) {
		super();
		this.id = id;
		this.price = price;
		this.categoryName = categoryName;
		this.name = name;
		this.quantity=quantity;
	}


	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String toString(){
		return "["+id+"-"+name+"-"+categoryName+"] : 수량 - "+quantity+", 가격 - "+price+"원"; 
	}

}
