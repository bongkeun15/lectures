package work12.exception;

import work12.entity.MessageEntity;

public class CommonException extends Exception {
	private MessageEntity entity;
	
	public CommonException() {}
	
	public CommonException(MessageEntity entity) {
		this.entity = entity;
	}
	
	public MessageEntity getMessageEntity() {
		return entity;
	}
}