package work12.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import work12.common.JdbcTemplate;
import work12.entity.BestProductEntity;
import work12.entity.BestPurchaserEntity;
import work12.entity.BestSatisfactionEntity;
import work12.entity.MessageEntity;
import work12.entity.SellerEntity;
import work12.exception.CommonException;



public class SellerDAO {

	
    public void sellerAdd(Connection con, SellerEntity entity)  throws CommonException{

		PreparedStatement pstmt = null;
		
		try {
			String sql = "insert into sellerMember ( seller_id,seller_pw,seller_name,seller_addr,seller_phone,seller_email, seller_reg_num, seller_account )"
					+ " values ( ?, ?, ?, ?, ?, ?, ?, ? ) ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, entity.getSellerId());
			pstmt.setString(2, entity.getSellerPw());
			pstmt.setString(3, entity.getSellerName());
			pstmt.setString(4, entity.getSellerAddr());
			pstmt.setString(5, entity.getSellerPhone());
			pstmt.setString(6, entity.getSellerEmail());
			pstmt.setString(7, entity.getSellerRegNum());
			pstmt.setString(8, entity.getSellerAccount());
			
			
			int result  = pstmt.executeUpdate();
			  if(result == 0) {
					throw new Exception();
				}
	
		} catch (Exception e) {
	
			 MessageEntity message = 
	 					new MessageEntity("error",9);
	 			message.setUrl("/work/work12/seller/sellerForm.html");
	 			message.setLinkTitle("회원 가입");
	 			throw new CommonException(message);
		}finally{

			JdbcTemplate.close(pstmt);
		}

	}//end consumerAdd
	
    //로그인
    public SellerEntity login(Connection con , String id, String pw) throws CommonException{
    	

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SellerEntity entity = null;
		try {
			String sql = "select * from sellerMember where seller_id = ? and seller_pw = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if(rs.next()){
				String seller_id = rs.getString("seller_id");
				String seller_pw = rs.getString("seller_pw");
				String seller_name = rs.getString("seller_name");
				String seller_addr = rs.getString("seller_addr");
				String seller_phone = rs.getString("seller_phone");
				String seller_email = rs.getString("seller_email");
				String seller_reg_num = rs.getString("seller_reg_num");
				String seller_account = rs.getString("seller_account");
				entity = new SellerEntity(seller_id, seller_pw, seller_name, seller_addr, seller_phone, seller_email , seller_reg_num, seller_account);
			}
		} catch (Exception e) {
			   MessageEntity message = 
						new MessageEntity("error",0);
				message.setUrl("/work/work12/loginForm.html");
				message.setLinkTitle("로그인");
				throw new CommonException(message);
		}finally{

			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
		}
    	
    	return entity;
    }//end login
    
    //회원수정화면보기
    public SellerEntity sellerUpdateForm(Connection con , String id) throws CommonException{
    	
  
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SellerEntity entity = null;
		try {

			String sql = "select * from sellerMember where seller_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()){
				String seller_id = rs.getString("seller_id");
				String seller_pw = rs.getString("seller_pw");
				String seller_name = rs.getString("seller_name");
				String seller_addr = rs.getString("seller_addr");
				String seller_phone = rs.getString("seller_phone");
				String seller_email = rs.getString("seller_email");
				String seller_reg_num = rs.getString("seller_reg_num");
				String seller_account = rs.getString("seller_account");
				entity = new SellerEntity(seller_id, seller_pw, seller_name, seller_addr, seller_phone, seller_email , seller_reg_num, seller_account);
			}
		} catch (Exception e) {
			 MessageEntity message = 
						new MessageEntity("error", 10);
			    message.setUrl("/work/work12/sellerUpdateForm");
				message.setLinkTitle("회원 수정");
				throw new CommonException(message);
		}finally{

			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
		}
    	
    	return entity;
    	
    }
    
    
    //회원수정
    public void sellerUpdate(Connection con, SellerEntity entity) throws CommonException{

		PreparedStatement pstmt = null;
		
		try {
			String sql = "update sellerMember set seller_pw = ? , seller_name=?, seller_addr = ? ,seller_phone = ? , seller_email = ? , seller_reg_num = ? , seller_account = ? "
					+ " where seller_id = ? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(8, entity.getSellerId());
			pstmt.setString(1, entity.getSellerPw());
			pstmt.setString(2, entity.getSellerName());
			pstmt.setString(3, entity.getSellerAddr());
			pstmt.setString(4, entity.getSellerPhone());
			pstmt.setString(5, entity.getSellerEmail());
			pstmt.setString(6, entity.getSellerRegNum());
			pstmt.setString(7, entity.getSellerAccount());
			
			
			int result  = pstmt.executeUpdate();
			  if(result == 0) {
					throw new Exception();
				}

		} catch (Exception e) {
	
			MessageEntity message = 
					new MessageEntity("error",10);
			message.setUrl("/work/work12/sellerUpdateForm");
			message.setLinkTitle("회원 수정");
			throw new CommonException(message);
		}finally{


			JdbcTemplate.close(pstmt);
		}
    	
    }
    
    
    
    
    public ArrayList<BestProductEntity> bestProduct(Connection con, String id) throws CommonException, SQLException{
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        ArrayList<BestProductEntity> list = new ArrayList<BestProductEntity>();
        String sql = 
                        "select * " +
                        "from (select p.product_id, p.product_name, p.product_price, p.product_company, sum(po.order_quantity) as quantity, to_char(p.product_date, 'yyyy-MM-dd') product_date " +
                        "from product p, prodorder po " +
                        "where p.product_id = po.product_id " +
                        "and   po.order_confirm = 'T' " +
                        "and   p.seller_id = ? " +
                        "group by p.product_id, p.product_name, p.product_price, p.product_company, po.order_quantity, product_date) best " +
                        "where rownum < 4 " +
                        "order by best.quantity desc";

        pstmt = con.prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();
        
        try {
        while(rs.next()){
            String productId      = rs.getString("product_id");
            System.out.println( "sellerDAO try if 1" );
            System.out.println( rs.getString("product_id") );
            String productName    = rs.getString("product_name");
            int    productPrice   = rs.getInt("product_price");
            String productCompany = rs.getString("product_company");
            int    quantity       = rs.getInt("quantity");
            int    totalPrice     = productPrice * productPrice ;
            String productDate    = rs.getString("product_date");
            
            BestProductEntity bpe = new BestProductEntity(
                   productId,
                   productName,
                   productPrice,
                   productCompany,
                   productDate,
                   quantity
                   );
            
            list.add( bpe );
            
            } 
        } catch ( Exception e ) {
            System.out.println( "sellerDAO bestProduct 에러" );
        }
        return list;
    }
    
    
    
    
    public ArrayList<BestPurchaserEntity> bestPurchaser(Connection con, String id) throws CommonException, SQLException{
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        ArrayList<BestPurchaserEntity> list = new ArrayList<BestPurchaserEntity>();
        String sql = 
                     "select * " +
                     "from (select pm.purchaser_id, pm.purchaser_name, sum(po.order_quantity * p.product_price) as total " +
                     "from purchasermember pm, prodorder po, product p " +
                     "where pm.purchaser_id = po.purchaser_id " +
                     "and p.product_id = po.product_id " +
                     "and po.order_confirm = 'T' " +
                     "and   p.seller_id = ? " +
                     "group by pm.purchaser_id, pm.purchaser_name) best " +
                     "where rownum < 4 " +
                     "order by best.total desc"; 

        pstmt = con.prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();
        
        try {
        while(rs.next()){
            String purchaserId    = rs.getString("purchaser_id");
            String purchaserName  = rs.getString("purchaser_name");
            int    total          = rs.getInt("total");
            
            BestPurchaserEntity bpe = new BestPurchaserEntity(
                   purchaserId,  
                   purchaserName, 
                   total
                   );
            
            list.add( bpe );
            
            } 
        } catch ( Exception e ) {
            System.out.println( "sellerDAO bestProduct 에러" );
        }
        return list;
    }
    
    
    
    
    
    public ArrayList<BestSatisfactionEntity> bestSatisfaction(Connection con, String id) throws CommonException, SQLException{
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        ArrayList<BestSatisfactionEntity> list = new ArrayList<BestSatisfactionEntity>();
        String sql = 
                        "select * " + 
                        "from (select p.product_id, p.product_name, avg(pc.comm_score) avg " + 
                        "from product p, prodcomment pc, prodorder po " + 
                        "where po.order_id = pc.order_id " + 
                        "and p.product_id = po.product_id " + 
                        "and   p.seller_id = ? " +
                        "group by p.product_id, p.product_name) best " + 
                        "where rownum < 4 " + 
                        "order by best.avg desc";

        pstmt = con.prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();
        
        System.out.println( "sellerDAO bestSatisfaction 1" );
        try {
        while(rs.next()){
            String productId    = rs.getString("product_id");
            String productName  = rs.getString("product_name");
            double avg            = rs.getDouble("avg");
            System.out.println( "sellerDAO bestSatisfaction 3" );
            
            BestSatisfactionEntity bse = new BestSatisfactionEntity(
                    productId,  
                    productName, 
                    avg
                   );
            System.out.println( "sellerDAO bestSatisfaction 4" );
            
            list.add( bse );
            
            System.out.println( list.size() + " SellerDAO !!!! bestSatisfaction" );
            
            } 
        } catch ( Exception e ) {
            System.out.println( "sellerDAO bestSatisfaction 에러" );
        }
        return list;
    }
    
    
    
    
}//end class
