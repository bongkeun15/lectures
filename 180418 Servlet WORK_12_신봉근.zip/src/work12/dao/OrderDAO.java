package work12.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import work12.common.JdbcTemplate;
import work12.entity.CommentEntity;
import work12.entity.MessageEntity;
import work12.entity.OrderEntity;
import work12.exception.CommonException;



public class OrderDAO {

	
	
	//구매
	public void productOrderBuy(Connection con,OrderEntity entity , int productQuantity)throws CommonException{

			PreparedStatement pstmt = null;
			//PreparedStatement pstmt2 = null;
			try {
				if( productQuantity < entity.getOrderQuantity() || entity.getOrderQuantity() < 0){
					throw new Exception();
				}
			
				//1. 구매 테이블에 저장
				String sql = "insert into prodOrder (order_id,product_id,purchaser_id, order_quantity) "
						+ " values ( ? , ?  , ? , ? ) ";
				pstmt = con.prepareStatement(sql);
				Calendar cal = Calendar.getInstance();
				String o_id = 
						String.format("%04d%02d%02d%05d",
								cal.get(Calendar.YEAR),
								cal.get(Calendar.MONTH)+1,
								cal.get(Calendar.DAY_OF_MONTH),cal.get(Calendar.MILLISECOND));
			    System.out.println("o_id > " + o_id);
				pstmt.setString(1,o_id );
				pstmt.setString(2, entity.getProductId());
				pstmt.setString(3, entity.getPurchaserId());
				pstmt.setInt(4, entity.getOrderQuantity());
				int result = pstmt.executeUpdate();
				if(result == 0) {
					throw new Exception();
				}
				//2. cart 테이블에서 삭제
				String sql2 = "delete from cart where purchaser_id = ? and product_id = ?";
				pstmt = con.prepareStatement(sql2);
				pstmt.setString(1, entity.getPurchaserId());
				pstmt.setString(2, entity.getProductId());
				result = pstmt.executeUpdate();
				if(result == 0) {
					throw new Exception();
				}
				//3. product 테이블 수정
			  
				  String sql4 = "update product set product_quantity =  ? where product_id = ?";
				  pstmt = con.prepareStatement(sql4);
					pstmt.setInt(1, productQuantity-entity.getOrderQuantity());
					pstmt.setString(2, entity.getProductId());
					result =  pstmt.executeUpdate();
					if(result == 0) {
						throw new Exception();
					}
			
			} catch (Exception e) {
		
				// TODO Auto-generated catch block
				MessageEntity message = 
						new MessageEntity("error",6);
				message.setUrl("/work/work12/productCartList");
				message.setLinkTitle("장바구니");
				throw new CommonException(message);
				
			} finally {

				JdbcTemplate.close(pstmt);
			}
		}
		
	// 전체구매
			public void productOrderAllBuy(Connection con, String purchaserId)
					throws CommonException {

		
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				try {
					
					String sql = "select * from cart , product where cart.product_id = product.product_id  and cart.purchaser_id = ? and cart.cart_quantity > product.product_quantity";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, purchaserId);
					rs = pstmt.executeQuery();
					while(rs.next()){
						throw new Exception();
					}
			
					ArrayList<HashMap<String, Object>> list= new ArrayList<HashMap<String,Object>>();
					String xxx = "select * from cart , product where cart.product_id = product.product_id  and cart.purchaser_id = ? ";
					pstmt = con.prepareStatement(xxx);
					pstmt.setString(1, purchaserId);
					rs = pstmt.executeQuery();
					while(rs.next()){
						String productId = rs.getString("product_id");
						int cartQuantity = rs.getInt("cart_quantity");
						int productQuantity = rs.getInt("product_quantity");
						HashMap<String, Object> map = new HashMap<String, Object>();
						map.put("productId", productId);
						map.put("cartQuantity", cartQuantity);
						map.put("productQuantity", productQuantity);
						list.add(map);
					}
					
					int i = 0;	
				for (HashMap<String, Object> m : list) {
					
				
					// 1. 구매 테이블에 저장
					String sql2 = "insert into prodOrder (order_id,product_id,purchaser_id, order_quantity) "
							+ " values ( ? , ?  , ? , ? ) ";
					pstmt = con.prepareStatement(sql2);
					Calendar cal = Calendar.getInstance();
					String o_id = String.format("%04d%02d%02d%05d",
							cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
							cal.get(Calendar.DAY_OF_MONTH),
							(cal.get(Calendar.MILLISECOND))+i++);
					pstmt.setString(1, o_id);
					pstmt.setString(2, m.get("productId").toString());
					pstmt.setString(3, purchaserId);
					pstmt.setInt(4, Integer.parseInt(m.get("cartQuantity").toString()));
					int result = pstmt.executeUpdate();
					if (result == 0) {
						throw new Exception();
					}
					// 2. cart 테이블에서 삭제
					String sql3 = "delete from cart where purchaser_id = ? and product_id = ?";
					pstmt = con.prepareStatement(sql3);
					pstmt.setString(1, purchaserId);
					pstmt.setString(2, m.get("productId").toString());
					int result2 = pstmt.executeUpdate();
					if (result2 == 0) {
						throw new Exception();
					}
					// 3. product 테이블 수정

					String sql4 = "update product set product_quantity =  ? where product_id = ?";
					pstmt = con.prepareStatement(sql4);
					pstmt.setInt(1, Integer.parseInt(m.get("productQuantity").toString()) - Integer.parseInt(m.get("cartQuantity").toString()));
					pstmt.setString(2, m.get("productId").toString());
					int result3 = pstmt.executeUpdate();
					if (result3 == 0) {
						throw new Exception();
					}
				}
				
				} catch (Exception e) {
					e.printStackTrace();
		
					MessageEntity message = new MessageEntity("error", 6);
					message.setUrl("/work/work12/productCartList");
					message.setLinkTitle("장바구니");
					throw new CommonException(message);
				} finally {
					JdbcTemplate.close(rs);
					JdbcTemplate.close(pstmt);
		
				}
			}
	
	//구매 목록
	public ArrayList<OrderEntity> productOrderList(Connection con,String purchaserId)throws CommonException{
		


		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<OrderEntity> list = new ArrayList<OrderEntity>();
		try {
	
			String sql = "select prodorder.order_id, p.product_id, p.product_name, p.product_price, p.product_company, order_quantity, prodorder.purchaser_id, c.category_large as large , c.category_middle as middle , to_char(prodorder.order_date,'yyyy-MM-dd') order_date  , prodorder.order_confirm, prodcomment.comm_content from product p, category c , prodorder , prodcomment  where p.category_id = c.category_id and p.product_id = prodorder.product_id and prodorder.order_id = prodcomment.order_id(+) and  prodorder.purchaser_id = ? ";

			System.out.println("sql > " + sql);
			pstmt = con.prepareStatement(sql);
			// pstmt.setString(1, product_id);
			pstmt.setString(1, purchaserId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String order_id = rs.getString("order_id");
				String p_id = rs.getString("product_id");
				String product_name = rs.getString("product_name");
				int product_price = rs.getInt("product_price");
				String product_company = rs.getString("product_company");
				int order_quantity = rs.getInt("order_quantity");
				String c_id = rs.getString("purchaser_id");
				String category_name = rs.getString("large") + "-"
						+ rs.getString("middle");
				String order_date = rs.getString("order_date");
				String order_confirm = rs.getString("order_confirm");
				String comm_content = rs.getString("comm_content");
				OrderEntity entity = 
						new OrderEntity(order_id, p_id, c_id, product_name, product_price, product_company, order_quantity, category_name, order_date , order_confirm);
				entity.setCommContent(comm_content);
				list.add(entity);
			}
		} catch (SQLException e) {
			MessageEntity message = 
					new MessageEntity("error",11);
			message.setUrl("/work/work12/productList");
			message.setLinkTitle("상품 목록");
			throw new CommonException(message);
		} finally {

			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
		}
		return list;
	}
	
	//구매확정
	public void productBuyConfirm(Connection con,OrderEntity entity)throws CommonException{
			

			PreparedStatement pstmt = null;
			//PreparedStatement pstmt2 = null;
			try {

				
			  //1. 구매자 회원점수 수정	
				  String sql = "update purchaserMember set purchaser_score = purchaser_score + ?   where purchaser_id = ?";
				    pstmt = con.prepareStatement(sql);
				    pstmt.setInt(1, (int)( entity.getProductPrice() /1000));
					pstmt.setString(2, entity.getPurchaserId());
					int result= pstmt.executeUpdate();
					if(result == 0) {
						throw new Exception();
					}
			  //2. 구매 테이블 구매확정여부 수정
				 String sql2 ="update prodOrder set order_confirm = ? where order_id = ?";
				    pstmt = con.prepareStatement(sql2);
				    pstmt.setString(1, "T" );
					pstmt.setString(2, entity.getOrderId() );
					result= pstmt.executeUpdate();
					if(result == 0) {
						throw new Exception();
					}
		
			       
			} catch (Exception e) {
				
	
				MessageEntity message = 
						new MessageEntity("error",12);
				message.setUrl("/work/work12/productOrderList");
				message.setLinkTitle("장바구니");
				throw new CommonException(message);
				
				
			} finally {

				JdbcTemplate.close(pstmt);
			}

		}
		//구매취소
	public void productBuyCancel(Connection con,OrderEntity entity)throws CommonException{
		
	

		PreparedStatement pstmt = null;
		//PreparedStatement pstmt2 = null;
		try {

		
		  //1. 재고 수정	
			  String sql = "update product set product_quantity =  product_quantity + ?  where product_id = ?";
			    pstmt = con.prepareStatement(sql);
			 	pstmt.setInt(1, entity.getOrderQuantity());
				pstmt.setString(2, entity.getProductId());
				int result= pstmt.executeUpdate();
				if(result == 0) {
					throw new Exception();
				}
		  //2. 구매 테이블 구매확정여부 수정
			 String sql2 ="delete from prodorder where order_id = ?";
			    pstmt = con.prepareStatement(sql2);
			    pstmt.setString(1, entity.getOrderId() );
			    result= pstmt.executeUpdate();
				if(result == 0) {
					throw new Exception();
				}

	
		} catch (Exception e) {
			

			MessageEntity message = 
					new MessageEntity("error",13);
			message.setUrl("/work/work12/productOrderList");
			message.setLinkTitle("장바구니");
			throw new CommonException(message);
			
			
		} finally {
			JdbcTemplate.close(pstmt);
		}
		
	}
	
	//구매후기 작성
	public void commentAdd(Connection con, CommentEntity entity  , String orderId)throws CommonException{
			
			PreparedStatement pstmt = null;

			try {

				String sql = "insert into prodComment (order_id, comm_content, comm_score ) values ( ? , ? , ? ) ";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, orderId);
				pstmt.setString(2, entity.getCommContent());
				pstmt.setString(3, entity.getCommScore());
				int result = pstmt.executeUpdate();
				if(result == 0) {
					throw new Exception();
				}
	
				
			} catch (Exception e) {
		
				MessageEntity message = new MessageEntity("error", 14);
				message.setUrl("/work/work12/productOrderList");
				message.setLinkTitle("구매 목록");
				throw new CommonException(message);
			} finally {

				JdbcTemplate.close(pstmt);
			}

		}
		
}// end class
