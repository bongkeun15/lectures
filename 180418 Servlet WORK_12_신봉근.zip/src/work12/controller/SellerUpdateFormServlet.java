package work12.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work12.biz.SellerBiz;
import work12.entity.MessageEntity;
import work12.entity.SellerEntity;
import work12.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work12.SellerUpdateForm", urlPatterns = { "/work12/sellerUpdateForm" })
public class SellerUpdateFormServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
	
			SellerEntity entity = (SellerEntity) session.getAttribute("sellerLogin");
			String	sellerId = entity.getSellerId();


		SellerBiz biz = new SellerBiz();
		try {
			entity = biz.sellerUpdateForm(sellerId);
			request.setAttribute("sellerUpdateEntity", entity);			
			RequestDispatcher dis = request.getRequestDispatcher("seller/sellerUpdateForm.jsp");
			dis.forward(request, response);
		} catch (CommonException e) {
			request.setAttribute("message", e.getMessageEntity());
			RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
			dis.forward(request, response);
		}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);
			RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
			dis.forward(request, response);
		}
	}

}
