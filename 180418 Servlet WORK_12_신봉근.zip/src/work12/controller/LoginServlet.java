package work12.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work12.biz.PurchaserBiz;
import work12.biz.SellerBiz;
import work12.entity.MessageEntity;
import work12.entity.PurchaserEntity;
import work12.entity.SellerEntity;
import work12.exception.CommonException;

/**
 * Servlet implementation class ConsumerServlet
 */

@WebServlet(name = "work12.Login", urlPatterns = { "/work12/login" })
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		// 파라미터 추출
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String member = request.getParameter("member");

		// 세션 초기화
		request.getSession().invalidate();

		HttpSession session = request.getSession();

		if ("purchaser".equals(member)) {
			PurchaserBiz biz = new PurchaserBiz();
			PurchaserEntity entity;
			try {
				entity = biz.login(id, pw);

				if (entity != null) {

					session.setAttribute("purchaserLogin", entity);
					session.setAttribute("member", "purchaser");
					RequestDispatcher dis = request.getRequestDispatcher("purchaser/purchaserLoginSuccess.jsp");
					dis.forward(request, response);
				} else {
					MessageEntity message = new MessageEntity("error",0);
					message.setUrl("/work/work12/loginForm.html");
					message.setLinkTitle("로그인");
					request.setAttribute("message", message);
					RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
					dis.forward(request, response);
				}

			} catch (CommonException e) {
	
				request.setAttribute("message", e.getMessageEntity());
				RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
				dis.forward(request, response);
			}

		} else {
			SellerBiz biz = new SellerBiz();
			SellerEntity entity;
			try {
				entity = biz.login(id, pw);
				if (entity != null) {
					session.setAttribute("sellerLogin", entity);
					session.setAttribute("member", "seller");
					RequestDispatcher dis = request.getRequestDispatcher("seller/sellerLoginSuccess.jsp");
					dis.forward(request, response);
				} else {
					MessageEntity message = new MessageEntity("error",0);
					message.setUrl("/work/work12/loginForm.html");
					message.setLinkTitle("로그인");
					request.setAttribute("message", message);
					RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
					dis.forward(request, response);
				}
			} catch (CommonException e) {
				request.setAttribute("message", e.getMessageEntity());
				RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
				dis.forward(request, response);

			}

		}
	}
}// end class
