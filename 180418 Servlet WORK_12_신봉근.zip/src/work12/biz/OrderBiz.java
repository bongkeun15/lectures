package work12.biz;

import java.sql.Connection;
import java.util.ArrayList;

import work12.common.JdbcTemplate;
import work12.dao.OrderDAO;
import work12.entity.CommentEntity;
import work12.entity.OrderEntity;
import work12.exception.CommonException;




public class OrderBiz {

	
	// 구매
		public void productOrderBuy(OrderEntity entity , int productQuantity) throws CommonException {
		
			OrderDAO dao = new OrderDAO();
			Connection con = JdbcTemplate.getConnection();
			try {

				dao.productOrderBuy(con, entity, productQuantity);
				JdbcTemplate.commit(con);
			} catch (CommonException e) {
				JdbcTemplate.rollback(con);
				throw e;
			} finally {
				JdbcTemplate.close(con);
			}

		}

		// 전체구매
		public void productOrderAllBuy(String purchaserId) throws CommonException {
			OrderDAO dao = new OrderDAO();
			Connection con = JdbcTemplate.getConnection();
			try {
				dao.productOrderAllBuy(con ,purchaserId);
				JdbcTemplate.commit(con);
			} catch (CommonException e) {
				e.printStackTrace();
				JdbcTemplate.rollback(con);
				throw e;
			} finally {
				JdbcTemplate.close(con);
			}
		}

		// 구매 목록
		public ArrayList<OrderEntity> productOrderList(String cust_id)
				throws CommonException {
			OrderDAO dao = new OrderDAO();
			Connection con = JdbcTemplate.getConnection();

			try {

				return dao.productOrderList(con, cust_id);
			} catch (CommonException e) {
				e.printStackTrace();
				throw e;
			} finally {
				JdbcTemplate.close(con);
			}

		}

		// 구매확정
		public void productBuyConfirm(OrderEntity entity) throws CommonException {
			OrderDAO dao = new OrderDAO();
			Connection con = JdbcTemplate.getConnection();

			try {

				dao.productBuyConfirm(con, entity);
				JdbcTemplate.commit(con);
			} catch (CommonException e) {
				JdbcTemplate.rollback(con);
				throw e;
			} finally {
				JdbcTemplate.close(con);
			}
		}

		// 구매취소
		public void productBuyCancel(OrderEntity entity) throws CommonException {
			OrderDAO dao = new OrderDAO();
			Connection con = JdbcTemplate.getConnection();
			try {

				dao.productBuyCancel(con, entity);
				JdbcTemplate.commit(con);
			} catch (CommonException e) {
				JdbcTemplate.rollback(con);
				throw e;
			} finally {
				JdbcTemplate.close(con);
			}
		}
	

		//구매 후기
		public void commentAdd(CommentEntity entity  , String orderId) throws CommonException {
				
			OrderDAO dao = new OrderDAO();
			Connection con = JdbcTemplate.getConnection();
				try {

					dao.commentAdd(con, entity , orderId);
					JdbcTemplate.commit(con);
				} catch (CommonException e) {
					JdbcTemplate.rollback(con);
					throw e;
				} finally {
					JdbcTemplate.close(con);
				}

			}
		
		
}// end class