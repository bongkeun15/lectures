package work12.biz;

import java.sql.Connection;
import java.util.ArrayList;

import work12.common.JdbcTemplate;
import work12.dao.ProductDAO;
import work12.entity.ProductDetailEntity;
import work12.entity.ProductEntity;
import work12.exception.CommonException;



public class ProductBiz {

	// 상품등록
	public void productAdd(ProductEntity entity) throws CommonException {

		ProductDAO dao = new ProductDAO();
		Connection con = JdbcTemplate.getConnection();

		try {

			dao.productAdd(con, entity);
			JdbcTemplate.commit(con);
		} catch (CommonException e) {
			JdbcTemplate.rollback(con);
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}

	}

	// 상품 목록
	public ArrayList<ProductEntity> productAllList() throws CommonException {
		ProductDAO dao = new ProductDAO();
		Connection con = JdbcTemplate.getConnection();
		try {

			return dao.productAllList(con);
		} catch (CommonException e) {
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}

	}

	public ArrayList<ProductEntity> productList(String id)
			throws CommonException {
		ProductDAO dao = new ProductDAO();
		Connection con = JdbcTemplate.getConnection();

		try {

			return dao.productList(con, id);
		} catch (CommonException e) {
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}
	}

	// 구매자 상품 검색
	public ArrayList<ProductEntity> productPurchaserSearch( String searchName,
			String searchValue) throws CommonException {
		
		ProductDAO dao = new ProductDAO();
		Connection con = JdbcTemplate.getConnection();

		try {
			return dao.productPurchaserSearch(con, searchName, searchValue);
		} catch (CommonException e) {
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}
	}
	
	// 판매자 상품 검색
	public ArrayList<ProductEntity> productSellerSearch( String sellerId, String searchName,
			String searchValue) throws CommonException {
		
		ProductDAO dao = new ProductDAO();
		Connection con = JdbcTemplate.getConnection();

		try {
			return dao.productSellerSearch(con, sellerId, searchName, searchValue);
		} catch (CommonException e) {
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}
		
	}
	

	// 제품 상세보기
	public ArrayList<ProductDetailEntity> productDetail(String productId)
			throws CommonException {
		ProductDAO dao = new ProductDAO();
		Connection con = JdbcTemplate.getConnection();

		try {
			
			return dao.productDetail(con, productId);
		} catch (CommonException e) {

			throw e;
		} finally {
			JdbcTemplate.close(con);
		}

	}

	
}// end class