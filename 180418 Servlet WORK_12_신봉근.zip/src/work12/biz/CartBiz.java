package work12.biz;

import java.sql.Connection;
import java.util.ArrayList;

import work12.common.JdbcTemplate;
import work12.dao.CartDAO;
import work12.entity.CartEntity;
import work12.exception.CommonException;




public class CartBiz {

	
	// 장바구니 담기
	public void productAddCart(CartEntity entity) throws CommonException {
		
		
		CartDAO dao = new CartDAO();
		Connection con = JdbcTemplate.getConnection();
		try {

			dao.productAddCart(con, entity);
			JdbcTemplate.commit(con);
		} catch (CommonException e) {
			JdbcTemplate.rollback(con);
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}
	}

	// cart 목록
	public ArrayList<CartEntity> cartList(String cust_id)
			throws CommonException {

		Connection con = JdbcTemplate.getConnection();
		try {
			CartDAO dao = new CartDAO();
			return dao.cartList(con, cust_id);
		} catch (CommonException e) {
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}

	}

	// 장바구니 수정
	public void productUpdateCart(CartEntity entity) throws CommonException {
		CartDAO dao = new CartDAO();
		Connection con = JdbcTemplate.getConnection();
		try {

			dao.productUpdateCart(con, entity);
			JdbcTemplate.commit(con);
		} catch (CommonException e) {
			JdbcTemplate.rollback(con);
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}
	}

	// 장바구니 삭제
	public void productDeleteCart(CartEntity entity)
			throws CommonException {
		CartDAO dao = new CartDAO();
		Connection con = JdbcTemplate.getConnection();
		try {

			dao.productDeleteCart(con, entity);
			JdbcTemplate.commit(con);
		} catch (CommonException e) {
			JdbcTemplate.rollback(con);
			throw e;
		} finally {
			JdbcTemplate.close(con);
		}

	}
}// end class