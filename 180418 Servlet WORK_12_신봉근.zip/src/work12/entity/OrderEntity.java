package work12.entity;

public class OrderEntity {

	private String orderId;   			//구매 아이디
	private String productId;			//상품아이디
	private String purchaserId;   			//구매자 아이디
	private String productName;		//상품명
	private int productPrice;			//가격
	private String productCompany;		//제조사
	private int orderQuantity;			//수량
	private String categoryName;      //카테고리 아이디 예> CNS01_100에 해당하는 가전-영상
	private String orderDate;         //구매 일자
	private String orderConfirm;		//구매확정여부
	
	private String commContent; 		//구매후기 작성여부

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getPurchaserId() {
		return purchaserId;
	}

	public void setPurchaserId(String purchaserId) {
		this.purchaserId = purchaserId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCompany() {
		return productCompany;
	}

	public void setProductCompany(String productCompany) {
		this.productCompany = productCompany;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderConfirm() {
		return orderConfirm;
	}

	public void setOrderConfirm(String orderConfirm) {
		this.orderConfirm = orderConfirm;
	}

	public String getCommContent() {
		return commContent;
	}

	public void setCommContent(String commContent) {
		this.commContent = commContent;
	}

	public OrderEntity(String orderId, String productId, String purchaserId,
			String productName, int productPrice, String productCompany,
			int orderQuantity, String categoryName, String orderDate,
			String orderConfirm) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.purchaserId = purchaserId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCompany = productCompany;
		this.orderQuantity = orderQuantity;
		this.categoryName = categoryName;
		this.orderDate = orderDate;
		this.orderConfirm = orderConfirm;

	}

	public OrderEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
