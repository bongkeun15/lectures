package work12.entity;

public class SellerEntity {
	
	private String sellerId;   // 판매자 아이디
	private String sellerPw;	// 판매자 비번
	private String sellerName;	// 판매자 이름
	private String sellerAddr;	// 판매자 주소
	private String sellerPhone;// 판매자 전화번호	
	private String sellerEmail;// 판매자 이메일
	private String sellerRegNum; // 판매자 사업 등록번호
	private String sellerAccount; // 판매자 계좌
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public String getSellerPw() {
		return sellerPw;
	}
	public void setSellerPw(String sellerPw) {
		this.sellerPw = sellerPw;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getSellerAddr() {
		return sellerAddr;
	}
	public void setSellerAddr(String sellerAddr) {
		this.sellerAddr = sellerAddr;
	}
	public String getSellerPhone() {
		return sellerPhone;
	}
	public void setSellerPhone(String sellerPhone) {
		this.sellerPhone = sellerPhone;
	}
	public String getSellerEmail() {
		return sellerEmail;
	}
	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}
	public String getSellerRegNum() {
		return sellerRegNum;
	}
	public void setSellerRegNum(String sellerRegNum) {
		this.sellerRegNum = sellerRegNum;
	}
	public String getSellerAccount() {
		return sellerAccount;
	}
	public void setSellerAccount(String sellerAccount) {
		this.sellerAccount = sellerAccount;
	}
	public SellerEntity(String sellerId, String sellerPw, String sellerName,
			String sellerAddr, String sellerPhone, String sellerEmail,
			String sellerRegNum, String sellerAccount) {
		super();
		this.sellerId = sellerId;
		this.sellerPw = sellerPw;
		this.sellerName = sellerName;
		this.sellerAddr = sellerAddr;
		this.sellerPhone = sellerPhone;
		this.sellerEmail = sellerEmail;
		this.sellerRegNum = sellerRegNum;
		this.sellerAccount = sellerAccount;
	}
	public SellerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
