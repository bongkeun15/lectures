/*
 *  - 우수고객 정보를 관리하는 entity 클래스.
 *  - PurchaserEntity 클래스를 상속받는다.
 * 
 */

package work12.entity;

public class BestPurchaserEntity extends PurchaserEntity {

	private int totalPrice;  // 구매 금액
	private String purchaserId;
	private String purchaserName;
	private int total;
	 
	public BestPurchaserEntity (String purchaserId, String purchaserName, int total) {
	    this.purchaserId = purchaserId;
	    this.purchaserName = purchaserName;
	    this.total = total;
	}
	
	
	
	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int total_price) {
		this.totalPrice = total_price;
	}



    public String getPurchaserId() {
        return purchaserId;
    }



    public void setPurchaserId( String purchaserId ) {
        this.purchaserId = purchaserId;
    }



    public String getPurchaserName() {
        return purchaserName;
    }



    public void setPurchaserName( String purchaserName ) {
        this.purchaserName = purchaserName;
    }



    public int getTotal() {
        return total;
    }



    public void setTotal( int total ) {
        this.total = total;
    }
 
	
    
}
