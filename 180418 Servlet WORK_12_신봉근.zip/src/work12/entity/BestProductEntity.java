/*
 *  - 우수상품 정보를 관리하는 entity 클래스.
 *  - ProductEntity 클래스를 상속받는다.
 * 
 */


package work12.entity;

public class BestProductEntity extends ProductEntity {

	private int saleQuantity; //판매수량



	  public BestProductEntity(String product_id,
				String product_name, int product_price, String product_company,
				String product_date,int sale_quantity) {
	      
	      
			super(product_id, 
			      null, 
			      product_name, 
			      product_price,
				  product_company, 
				  0, 
				  null, 
				  product_date,
				  null);
			this.saleQuantity = sale_quantity;
		}


	public int getSaleQuantity() {
		return saleQuantity;
	}


	public void setSaleQuantity(int saleQuantity) {
		this.saleQuantity = saleQuantity;
	}


    @Override
    public String getProductId() {
        // TODO Auto-generated method stub
        return super.getProductId();
    }


    @Override
    public void setProductId( String productId ) {
        // TODO Auto-generated method stub
        super.setProductId( productId );
    }


    @Override
    public String getCategoryId() {
        // TODO Auto-generated method stub
        return super.getCategoryId();
    }


    @Override
    public void setCategoryId( String categoryId ) {
        // TODO Auto-generated method stub
        super.setCategoryId( categoryId );
    }


    @Override
    public String getProductName() {
        // TODO Auto-generated method stub
        return super.getProductName();
    }


    @Override
    public void setProductName( String productName ) {
        // TODO Auto-generated method stub
        super.setProductName( productName );
    }


    @Override
    public int getProductPrice() {
        // TODO Auto-generated method stub
        return super.getProductPrice();
    }


    @Override
    public void setProductPrice( int productPrice ) {
        // TODO Auto-generated method stub
        super.setProductPrice( productPrice );
    }


    @Override
    public String getProductCompany() {
        // TODO Auto-generated method stub
        return super.getProductCompany();
    }


    @Override
    public void setProductCompany( String productCompany ) {
        // TODO Auto-generated method stub
        super.setProductCompany( productCompany );
    }


    @Override
    public int getProductQuantity() {
        // TODO Auto-generated method stub
        return super.getProductQuantity();
    }


    @Override
    public void setProductQuantity( int productQuantity ) {
        // TODO Auto-generated method stub
        super.setProductQuantity( productQuantity );
    }


    @Override
    public String getProductInfo() {
        // TODO Auto-generated method stub
        return super.getProductInfo();
    }


    @Override
    public void setProductInfo( String productInfo ) {
        // TODO Auto-generated method stub
        super.setProductInfo( productInfo );
    }


    @Override
    public String getProductDate() {
        // TODO Auto-generated method stub
        return super.getProductDate();
    }


    @Override
    public void setProductDate( String productDate ) {
        // TODO Auto-generated method stub
        super.setProductDate( productDate );
    }


    @Override
    public String getSellerId() {
        // TODO Auto-generated method stub
        return super.getSellerId();
    }


    @Override
    public void setSellerId( String sellerId ) {
        // TODO Auto-generated method stub
        super.setSellerId( sellerId );
    }


    @Override
    public String getCategoryName() {
        // TODO Auto-generated method stub
        return super.getCategoryName();
    }


    @Override
    public void setCategoryName( String categoryName ) {
        // TODO Auto-generated method stub
        super.setCategoryName( categoryName );
    }

	  
	
	
}
