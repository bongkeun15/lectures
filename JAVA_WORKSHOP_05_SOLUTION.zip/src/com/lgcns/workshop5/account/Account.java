package com.lgcns.workshop5.account;

public class Account {
	private String customerId;
	private String customerName;
	private String accountNumber;
	private int balance;

	public Account(){}

	public Account(String customerId, String customerName, String accountNumber) {
		System.out.println("[공지] 계좌를 개설합니다.");
		if(nameValidationCheck(customerName)){
			this.customerId = customerId;
			this.customerName = customerName;
			this.accountNumber = accountNumber;
			printAccountInfo();
		}
	}

	public void setCustomerName(String customerName) {
		if(isExistAccount() && nameValidationCheck(customerName)){
			this.customerName = customerName;
			printAccountInfo();
		}
	}

	public void withdraw(int money) {
		if(isExistAccount()){
			System.out.println( "\n[출금] " + money + "원을 출금합니다." );
			
			if(isPositiveNumber(money) && isWithdrawable(money) ) {
				this.balance -= money;
			}
			printAccountInfo();
		}
	}

	public void deposit(int money) {
		if(isExistAccount()){
			System.out.println( "\n[입금] " + money + "원을 입금합니다." );
			
			if(isPositiveNumber(money)) {
				this.balance += money;
			}
			printAccountInfo();
		}
	}

	private boolean isExistAccount() {
		if (this.customerId == null || "".equals(this.customerId)) {
			System.out.println("[공지] 계좌가 없습니다. 계좌를 생성해주시기 바랍니다.");
			return false;
		}
		return true;
	}

	private boolean isPositiveNumber(int money) {
		if (money > 0) {
			return true;
		} else {
			System.out.println( "[에러] 0보다 큰 숫자를 입력해주시기 바랍니다." );
			return false;
		}
	}

	private boolean nameValidationCheck(String name) {
		if(name.length() < 2){
			System.out.println( "[에러] 이름은 2글자 이상 입력해주시기 바랍니다." );
			return false;
		} else {
			return true;
		}
	}
	
	private boolean isWithdrawable(int money){
		if(money > this.balance){
			System.out.println( "[에러] 잔액이 부족합니다." );
			return false;
		} else {
			return true;
		}
	}
	
	private void printAccountInfo(){
		System.out.println( "=========================" );
		System.out.println( " 고객번호  : " + this.customerId );
		System.out.println( " 고객명  : " + this.customerName );
		System.out.println( " 계좌번호  : " + this.accountNumber );
		System.out.println( " 잔액  : " + this.balance );
		System.out.println( "=========================" );
	}
	
}