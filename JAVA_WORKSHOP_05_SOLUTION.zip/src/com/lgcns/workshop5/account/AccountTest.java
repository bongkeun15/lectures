package com.lgcns.workshop5.account;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class AccountTest {
	
	public static void main( String[] args ) {
		
		int input = 0; 
		Account account = new Account();
		
		while(input != 9){
			
			System.out.println("====== 통장 관리 ======");
			System.out.println(" 1. 계좌 신규 개설");
			System.out.println(" 2. 계좌 정보 수정");
			System.out.println(" 3. 입금");
			System.out.println(" 4. 출금");
			System.out.println(" 9. 종료");
			System.out.println("=====================");
			System.out.print("#메뉴를 입력하세요 >> ");
			
			input = getUserIntegerInput();
			
			if(input == 1){
				System.out.print("아이디을 입력하세요  >> ");
				String customerId = getCodeInput();
				System.out.print("이름을 입력하세요  >> ");
				String customerName = getCodeInput();
				System.out.print("계좌 번호를 입력하세요  >> ");
				String accountNumber = getCodeInput();
				
				account = new Account(customerId, customerName, accountNumber);
				
			}else if(input == 2){
				System.out.print("변경하실 이름을 입력하세요  >> ");
				String customerName = getCodeInput();
				
				account.setCustomerName(customerName);
				
			}else if(input == 3){
				System.out.print("입금하실 금액을 입력하세요  >> ");
				int money = getUserIntegerInput();
				
				account.deposit(money);
				
			}else if(input == 4){
				System.out.print("출금하실 금액을 입력하세요  >> ");
				int money = getUserIntegerInput();
				
				account.withdraw(money);
				
			}else if(input == 9){
				System.out.println("이용해주셔서 감사합니다.");
			}else {
				System.out.println("[에러] 메뉴를 다시 입력해 주세요.");
			}
		}
	}
	
    /**
     * 사용자로부터 정수를 입력 받는 메소드
     * 
     * @return 사용자가 입력한 숫자(정수)
     */
    public static int getUserIntegerInput() {
        
        BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
        String inputString = null;
        
        try {
            inputString = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return Integer.parseInt( inputString );
    }
    
    /**
     * 사용자로부터 코드(문자열)를 입력 받는 메소드
     * 
     * @return 사용자가 입력한 코드(문자열)
     */
    public static String getCodeInput() {
        
        BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
        String inputString = null;
        
        try {
            inputString = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return inputString;
    }
}