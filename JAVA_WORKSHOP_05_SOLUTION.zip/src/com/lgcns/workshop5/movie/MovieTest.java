package com.lgcns.workshop5.movie;

public class MovieTest {
	
	public static void main( String[] args ) {
		
		Movie roadOfRing   = new Movie( "반지의 제왕", "피터 잭슨", "판타지, 모험", "일라이저 우드", 2001, 178, "12세 관람가" );
		Movie transformer  = new Movie( "트랜스포머", "마이클 베이", "SF, 액션", "샤이아 라보프", 2009, 149 );
		Movie loveActually = new Movie( "러브 액츄얼리", "리처드 커티스", "멜로, 드라마", "앨런 릭맨 등", 2003, 134, "15세 관람가" );
		Movie kungfuPanda  = new Movie( "쿵푸 팬더", "마크 오스본", "애니메이션", "잭 블랙 등" );
		
		System.out.println( "<< 전체 영화 정보 조회 >>" );
		System.out.println( "-----------------------------------------------------------------------------------------------" );
		System.out.println( "     제목\t    감독\t    장르\t    주연       개봉년도 런타임\t   등급" );
		System.out.println( "-----------------------------------------------------------------------------------------------" );
		
		roadOfRing.printMovieInfo();
		transformer.printMovieInfo();
		loveActually.printMovieInfo();
		kungfuPanda.printMovieInfo();
		
		System.out.println( "-----------------------------------------------------------------------------------------------" );
	}
}