package com.lgcns.workshop5.movie;

public class Movie {
	
	private String title;
	private String director;
	private String genre;
	private String actor;
	private int releaseYear;
	private int runTime;
	private String rating;
	
	public Movie( String title, String director, String genre, String actor ) {
		this.title    = title;
		this.director = director;
		this.genre    = genre;
		this.actor    = actor;
	}
	
	public Movie( String title, String director, String genre, String actor, int releaseYear, int runTime ) {
		this( title, director, genre, actor );
		this.releaseYear = releaseYear;
		this.runTime     = runTime;
	}
	
	public Movie( String title, String director, String genre, String actor, int releaseYear, int runTime, String rating ) {
		this( title, director, genre, actor, releaseYear, runTime );
		this.rating = rating;
	}
	
	public void printMovieInfo() {
		
		System.out.print( title + "\t" + director + "\t" + genre + "\t" + actor + "\t" );
		
		if ( releaseYear > 0 ) {
			System.out.print( releaseYear + "년\t" );
		} else {
			System.out.print( "N/A\t" );
		}
		
		if ( runTime > 0 ) {
			System.out.print( runTime + "분\t" );
		} else {
			System.out.print( "N/A\t" );
		}
		
		if ( rating != null ) {
			System.out.println( rating );
		} else {
			System.out.println( "N/A" );
		}
	}
}