/*
 *    구매 처리 관련 DAO 클래스
 * 
 */

package work11.dao;

import java.sql.Connection;
import java.util.ArrayList;

import work11.entity.CommentEntity;
import work11.entity.OrderEntity;
import work11.exception.CommonException;

public class OrderDAO {

	// 구매
	public void productOrderBuy(Connection con, OrderEntity entity,
			int productQuantity) throws CommonException {

		/*
		 * 1. 재고수량보다 많은 수량을 구매할때는 예외가 발생된다.
		 * 
		 * 2. prodOrder 테이블에 해당 구매정보를 저장한다.
		 * 
		 * 3. 구매 아이디(o_id) 는 다음과 같이 처리한다
		 * 
		 *  Calendar cal = Calendar.getInstance(); 
		 *  String o_id =
		 *    String.format("%04d%02d%02d%05d", cal.get(Calendar.YEAR),
		 *    cal.get(Calendar.MONTH)+1,
		 *    cal.get(Calendar.DAY_OF_MONTH),cal.get(Calendar.MILLISECOND));
		 * 
		 * 4. 구매한 상품과 일치하는 제품을 장바구니에서 삭제한다.
		 * 
		 * 5. 구매한 상품의 수량만큼 Product 테이블 수량에서 뺀다.
		 * 
		 * 6. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 7. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

	}

	// 전체구매
	public void productOrderAllBuy(Connection con, String purchaserId)
			throws CommonException {

		/*
		 * 1. 재고수량보다 많은 수량을 구매할때는 예외가 발생된다.
		 * 
		 * 2. purchaserId 에 해당되는 목록을 Cart 테이블에서 검색하여 prodOrder 테이블에 저장한다.
		 * 
		 * 3. 구매 아이디(o_id) 는 다음과 같이 처리한다
		 * 
		 *  int i = 0 ;
		 *  ..
		 *  
		 *  Calendar cal = Calendar.getInstance(); 
		 *  String o_id =
		 *    String.format("%04d%02d%02d%05d", cal.get(Calendar.YEAR),
		 *    cal.get(Calendar.MONTH)+1,
		 *    cal.get(Calendar.DAY_OF_MONTH),cal.get(Calendar.MILLISECOND)+ i++);
		 *    
		 * 
		 * 4. 구매한 상품과 일치하는 제품을 장바구니에서 삭제한다.
		 * 
		 * 5. 구매한 상품의 수량만큼 Product 테이블 수량에서 뺀다.
		 * 
		 * 6. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 7. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		
		
	}

	// 구매 목록
	public ArrayList<OrderEntity> productOrderList(Connection con,
			String purchaserId) throws CommonException {

		/*
		 * 1. 해당 purchaserId에 해당하는 구매 정보를 리턴한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		
		return null;
	}

	// 구매확정
	public void productBuyConfirm(Connection con, OrderEntity entity)
			throws CommonException {

		/*
		 * 1. 구매자 회원 점수를 수정한다. 점수는 다음 공식을 이용한다.
		 *   : 점수 = 가격/1000
		 *   
		 * 2. 구매 테이블에서 구매 확정 컬럼을 'T'로 수정한다.
		 * 
		 * 3. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 4. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		
	}

	// 구매취소
	public void productBuyCancel(Connection con, OrderEntity entity)
			throws CommonException {

		/*
		 * 1. 상품 테이블에서 수량을 수정한다.
		 *  
		 *   
		 * 2. 구매 테이블에서 취소 상품을 삭제한다.
		 * 
		 * 3. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 4. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

	}

	// 구매후기 작성
	public void commentAdd(Connection con, CommentEntity entity, String orderId)
			throws CommonException {

		/*
		 * 1. 구매후기 테이블에 구매후기 정보를 저장한다.
	
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		

	}

}
