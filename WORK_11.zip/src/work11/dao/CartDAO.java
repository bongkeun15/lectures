/*
 *    장바구니 처리 관련 DAO 클래스
 * 
 */

package work11.dao;

import java.sql.Connection;
import java.util.ArrayList;

import work11.entity.CartEntity;
import work11.exception.CommonException;

public class CartDAO {

	// Cart에 존재여부 체크
	private boolean isExistCart(Connection con, CartEntity entity) {

		/*
		 * 1. cart 테이블에서 해당 상품이 있는지를 검사한다. 존재하면 true 값을 리턴하고 존재하지 않으면 false 값을
		 * 리턴한다.
		 * 
		 * 2. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		return false;
	}

	// 장바구니 담기
	public void productAddCart(Connection con, CartEntity entity)
			throws CommonException {
		/*
		 * 1. cart 테이블에서 해당 상품이 존재하면 상품 정보를 수정하고 존재하지 않으면 새로 추가한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

	}// end productCart

	// cart 목록
	public ArrayList<CartEntity> cartList(Connection con, String purchaser_id)
			throws CommonException {

		/*
		 * 1. 테이블에서 구매자 아이디에 해당되는 장바구니 정보를 얻는다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

		
		
		return null;
	}

	// 장바구니 수정
	public void productUpdateCart(Connection con, CartEntity entity)
			throws CommonException {


		/*
		 * 1. 해당하는 데이터로 장바구니 정보를 수정한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		
		
	}// end productCart

	// 장바구니 삭제
	public void productDeleteCart(Connection con, CartEntity entity)
			throws CommonException {

		/*
		 * 1. 해당하는 데이터로 장바구니 정보를 삭제한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		
	}// end productCart

}// end class
