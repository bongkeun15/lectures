/*
 *    상품 관련 DAO 클래스
 * 
 */

package work11.dao;

import java.sql.Connection;
import java.util.ArrayList;

import work11.entity.ProductDetailEntity;
import work11.entity.ProductEntity;
import work11.exception.CommonException;



public class ProductDAO {

	//상품 등록
	public void productAdd(Connection con, ProductEntity entity)throws CommonException {

		/*
		 * 1. 해당 상품 정보를 상품 테이블에 저장한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

	}

	// 모든 상품목록 보기
		public ArrayList<ProductEntity> productAllList(Connection con) throws CommonException{

			/*
			 * 1. 모든 상품 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
		

			return null;
		}
		
	// 특정 판매자 상품목록
	public ArrayList<ProductEntity> productList(Connection con,String sellId)throws CommonException {

		/*
		 * 1. sellId와 일치하는 판매자가 등록한 모든 상품 정보를 리턴한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

		return null;
	}


	// 구매자 상품 검색
		public ArrayList<ProductEntity> productPurchaserSearch( Connection con , String searchName,
				String searchValue) throws CommonException {
			
			/*
			 * 1. searchName, searchValue에 해당하는  모든 상품 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
		
			return null;
		}
		
		// 판매자 상품 검색
		public ArrayList<ProductEntity> productSellerSearch(Connection con ,  String sellerId, String searchName,
				String searchValue) throws CommonException {
			
			/*
			 * 1. sellId, searchName, searchValue에 해당하는  모든 상품 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
		
			return null;
		}
		
	//제품 상세보기
		public ArrayList<ProductDetailEntity> productDetail(Connection con,String productId)throws CommonException{
			
			/*
			 * 1. productId에 해당하는 상품 상세 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
			
	
			return null;
		}
}// end class
