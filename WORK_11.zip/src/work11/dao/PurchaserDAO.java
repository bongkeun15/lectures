/*
 *    구매자 DAO 클래스
 * 
 */


package work11.dao;

import java.sql.Connection;

import work11.entity.PurchaserEntity;
import work11.exception.CommonException;




public class PurchaserDAO {

	
	
	//구매자 회원 가입
    public void purchaserAdd(Connection con , PurchaserEntity entity) throws CommonException{
		

		/*
		 * 1. 해당 구매자 정보를 구매자 테이블에 저장한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */


	}//end consumerAdd
	
    //로그인
    public PurchaserEntity login(Connection con , String id, String pw) throws CommonException{

    	/*
		 * 1. id와 pw 이용하여 로그인 처리한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
	
    	
    	return entity;
    }//end login
    
    //회원수정화면보기
    public PurchaserEntity purchaserUpdateForm(Connection con ,String id)throws CommonException{
    	

		/*
		 * 1. 해당 id와 일치하는 구매자 정보를  리턴한다.
		 * 		 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

    	return null;
    	
    }
    
    
    //회원수정
    public void purchaserUpdate(Connection con , PurchaserEntity entity)throws CommonException{
    	
    	/*
		 * 1. 구매자 정보를  수정한다.
		 * 		 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

	

    	
    }//end 
}//end class
