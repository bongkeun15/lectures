/*
 *    판매자 DAO 클래스
 * 
 */

package work11.dao;

import java.sql.Connection;

import work11.entity.SellerEntity;
import work11.exception.CommonException;



public class SellerDAO {

	
    public void sellerAdd(Connection con, SellerEntity entity)  throws CommonException{

    	/*
		 * 1. 해당 판매자 정보를 판매자 테이블에 저장한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		

	}//end consumerAdd
	
    //로그인
    public SellerEntity login(Connection con , String id, String pw) throws CommonException{
    	
    	/*
		 * 1. id와 pw 이용하여 로그인 처리한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		
    	return null;
    }//end login
    
    //회원수정화면보기
    public SellerEntity sellerUpdateForm(Connection con , String id) throws CommonException{
    	
    	/*
		 * 1. 해당 id와 일치하는 판매자 정보를  리턴한다.
		 * 		 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
		
    	
    	return null;
    	
    }
    
    
    //회원수정
    public void sellerUpdate(Connection con, SellerEntity entity) throws CommonException{

    	/*
		 * 1. 판매자 정보를  수정한다.
		 * 		 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
	
    	
    }//end 
    
  
    
}//end class
