package work11.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work11.biz.ProductBiz;
import work11.entity.MessageEntity;
import work11.entity.ProductEntity;
import work11.entity.SellerEntity;
import work11.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work11.ProductList", urlPatterns = { "/work11/productList" })
public class ProductListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
			String member = (String) session.getAttribute("member");
			String sellerId = null;

			ProductBiz biz = new ProductBiz();
			ArrayList<ProductEntity> list = null;

			if ("purchaser".equals(member)) {
				try {
					list = biz.productAllList();
					request.setAttribute("productList", list);
					RequestDispatcher dis = request
							.getRequestDispatcher("product/productList.jsp");
					dis.forward(request, response);
				} catch (CommonException e) {
					request.setAttribute("message", e.getMessageEntity());
					RequestDispatcher dis = request
							.getRequestDispatcher("message.jsp");
					dis.forward(request, response);
				}

			} else {
				SellerEntity entity = (SellerEntity) session
						.getAttribute("sellerLogin");
				sellerId = entity.getSellerId();
				try {
					list = biz.productList(sellerId);
					request.setAttribute("productList", list);
					RequestDispatcher dis = request
							.getRequestDispatcher("product/productList.jsp");
					dis.forward(request, response);
				} catch (CommonException e) {
					request.setAttribute("message", e.getMessageEntity());
					RequestDispatcher dis = request
							.getRequestDispatcher("message.jsp");
					dis.forward(request, response);
				}
			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);
			RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
			dis.forward(request, response);
		}
	}

}
