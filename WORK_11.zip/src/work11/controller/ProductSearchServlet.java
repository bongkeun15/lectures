package work11.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work11.biz.ProductBiz;
import work11.entity.MessageEntity;
import work11.entity.ProductEntity;
import work11.entity.SellerEntity;
import work11.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work11.ProductSearch", urlPatterns = { "/work11/productSearch" })
public class ProductSearchServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
		
			String searchName = request.getParameter("searchName");
			String searchValue = request.getParameter("searchValue");


			String member = (String) session.getAttribute("member");
			session.setAttribute("searchValue", searchValue);
			session.setAttribute("searchName", searchName);

			ProductBiz biz = new ProductBiz();
			ArrayList<ProductEntity> list;
			String sellerId = null;

			try {

				if ("purchaser".equals(member)) {
					list = biz.productPurchaserSearch(searchName, searchValue);
				} else {
					SellerEntity entity = (SellerEntity) session
							.getAttribute("sellerLogin");
					sellerId = entity.getSellerId();
					list = biz.productSellerSearch(sellerId, searchName,
							searchValue);
				}

				request.setAttribute("productList", list);
				RequestDispatcher dis = request
						.getRequestDispatcher("product/productList.jsp");
				dis.forward(request, response);

			} catch (CommonException e) {
				request.setAttribute("message", e.getMessageEntity());
				RequestDispatcher dis = request
						.getRequestDispatcher("message.jsp");
				dis.forward(request, response);
			}

		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);
			RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
			dis.forward(request, response);
		}

	}

}
