package work11.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import work11.common.JdbcTemplate;
import work11.entity.MessageEntity;
import work11.entity.SellerEntity;
import work11.exception.CommonException;



public class SellerBiz {

	// 회원가입
	public void sellerAdd(SellerEntity entity)throws CommonException {
		

		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		try {

			
			String sql = "insert into sellerMember ( seller_id,seller_pw,seller_name,seller_addr,seller_phone,seller_email, seller_reg_num, seller_account )"
					+ " values ( ?, ?, ?, ?, ?, ?, ?, ? ) ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, entity.getSellerId());
			pstmt.setString(2, entity.getSellerPw());
			pstmt.setString(3, entity.getSellerName());
			pstmt.setString(4, entity.getSellerAddr());
			pstmt.setString(5, entity.getSellerPhone());
			pstmt.setString(6, entity.getSellerEmail());
			pstmt.setString(7, entity.getSellerRegNum());
			pstmt.setString(8, entity.getSellerAccount());
			
			
			int result  = pstmt.executeUpdate();
			  if(result == 0) {
					throw new Exception();
				}
			 JdbcTemplate.commit(con);
		}catch (Exception e) {
	    		 JdbcTemplate.rollback(con);
	    		 MessageEntity message = 
		 					new MessageEntity("error",9);
		 			message.setUrl("/work/work11/seller/sellerForm.html");
		 			message.setLinkTitle("회원 가입");
		 			throw new CommonException(message);
		} finally {
			
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(con);
		}
		
	}

	// 로그인
	public SellerEntity login(String id, String pw) throws CommonException{
	
		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SellerEntity entity = null;
		   try{
			 
			   String sql = "select * from sellerMember where seller_id = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				if(rs.next()){
					String seller_id = rs.getString("seller_id");
					String seller_pw = rs.getString("seller_pw");
					String seller_name = rs.getString("seller_name");
					String seller_addr = rs.getString("seller_addr");
					String seller_phone = rs.getString("seller_phone");
					String seller_email = rs.getString("seller_email");
					String seller_reg_num = rs.getString("seller_reg_num");
					String seller_account = rs.getString("seller_account");
					entity = new SellerEntity(seller_id, seller_pw, seller_name, seller_addr, seller_phone, seller_email , seller_reg_num, seller_account);
				}
		   }catch (Exception e) {
			   MessageEntity message = 
						new MessageEntity("error",0);
				message.setUrl("/work/work11/loginForm.html");
				message.setLinkTitle("로그인");
				throw new CommonException(message);
		   }finally{
			   
			   JdbcTemplate.close(rs);
			   JdbcTemplate.close(pstmt);
			   JdbcTemplate.close(con);
		   }
			return entity;
		
	}

	// 회원수정 화면
	public SellerEntity sellerUpdateForm(String id)throws CommonException {
		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SellerEntity entity = null;
		try {

			
			String sql = "select * from sellerMember where seller_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()){
				String seller_id = rs.getString("seller_id");
				String seller_pw = rs.getString("seller_pw");
				String seller_name = rs.getString("seller_name");
				String seller_addr = rs.getString("seller_addr");
				String seller_phone = rs.getString("seller_phone");
				String seller_email = rs.getString("seller_email");
				String seller_reg_num = rs.getString("seller_reg_num");
				String seller_account = rs.getString("seller_account");
				entity = new SellerEntity(seller_id, seller_pw, seller_name, seller_addr, seller_phone, seller_email , seller_reg_num, seller_account);
			}
		 }catch (Exception e) {
			 MessageEntity message = 
						new MessageEntity("error", 10);
			 message.setUrl("/work/work11/sellerUpdateForm");
				message.setLinkTitle("회원 수정");
				throw new CommonException(message);
		} finally {
			
			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(con);
		}
		return entity;
	
	}

	// 회원수정
	public void sellerUpdate(SellerEntity entity)throws CommonException {

		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		try {

			
			String sql = "update sellerMember set seller_pw = ? , seller_name=?, seller_addr = ? ,seller_phone = ? , seller_email = ? , seller_reg_num = ? , seller_account = ? "
					+ " where seller_id = ? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(8, entity.getSellerId());
			pstmt.setString(1, entity.getSellerPw());
			pstmt.setString(2, entity.getSellerName());
			pstmt.setString(3, entity.getSellerAddr());
			pstmt.setString(4, entity.getSellerPhone());
			pstmt.setString(5, entity.getSellerEmail());
			pstmt.setString(6, entity.getSellerRegNum());
			pstmt.setString(7, entity.getSellerAccount());
			
			
			int result  = pstmt.executeUpdate();
			  if(result == 0) {
					throw new Exception();
				}
			JdbcTemplate.commit(con);
		}catch (Exception e) {
			JdbcTemplate.rollback(con);
			MessageEntity message = 
					new MessageEntity("error",10);
			message.setUrl("/work/work11/sellerUpdateForm");
			message.setLinkTitle("회원 수정");
			throw new CommonException(message);
		} finally {
			
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(con);
		}
		
		
	}
	
	

}
