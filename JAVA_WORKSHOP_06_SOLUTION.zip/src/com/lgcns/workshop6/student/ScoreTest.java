package com.lgcns.workshop6.student;

import com.lgcns.workshop6.util.WorkshopUtil;

public class ScoreTest {
	
	public static void main( String[] args ) {
		
		int javaSum    = 0;
		int sqlSum     = 0;
		int mathSum    = 0;
		int chineseSum = 0;
		
		System.out.print( "이 반에는 몇 명의 학생이 있나요? : " );
		int students = WorkshopUtil.getUserIntegerInput();
		
		for ( int inx = 1 ; inx <= students ; inx++ ) {
			
			Student student = null;
			
			if ( inx < 10 ) {
				student = new Student( "STD0" + inx );
			} else {
				student = new Student( "STD" + inx );
			}
			
			System.out.print( "\n" + student.getId() + " 학생의 Java 점수 : " );
			int java = WorkshopUtil.getUserIntegerInput();
			javaSum += java;
			
			System.out.print( student.getId() + " 학생의 SQL 점수 : " );
			int sql = WorkshopUtil.getUserIntegerInput();
			sqlSum += sql;
			
			System.out.print( student.getId() + " 학생의 수학 점수 : " );
			int math = WorkshopUtil.getUserIntegerInput();
			mathSum += math;
			
			System.out.print( student.getId() + " 학생의 중국어 점수 : " );
			int chinese = WorkshopUtil.getUserIntegerInput();
			chineseSum += chinese;
			
			student.setScores( java, sql, math, chinese );
			
			student.printScoreInfo();
		}
		
		double javaAvg    = (double) javaSum / students;
		double sqlAvg     = (double) sqlSum / students;
		double mathAvg    = (double) mathSum / students;
		double chineseAvg = (double) chineseSum / students;
		
		System.out.println( "===========================================" );
		System.out.println( " Java 반 평균 : " + String.format("%.2f", javaAvg )  + "점" );
		System.out.println( " SQL 반 평균 : "  + String.format("%.2f", sqlAvg )    + "점" );
		System.out.println( " 수학 반 평균 : "   + String.format("%.2f", mathAvg )   + "점" );
		System.out.println( " 중국어 반 평균 : "  + String.format("%.2f", chineseAvg )+ "점" );
		System.out.println( "===========================================" );
	}
	
}