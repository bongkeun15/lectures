package com.lgcns.workshop6.student;

public class Student {
	
	private String id;
	private int java;
	private int sql;
	private int math;
	private int chinese;
	
	public Student( String id ) {
		this.id = id;
	}
	
	public String getId() {
		return id;
	}
	
	public void setScores( int java, int sql, int math, int chinese ) {
		this.java    = java;
		this.sql     = sql;
		this.math    = math;
		this.chinese = chinese;
	}
	
	private double calculateAverage() {
		return (double)( java + sql + math + chinese ) / 4;
	}
	
	public void printScoreInfo() {
		System.out.println( "----------------------------------------" );
		System.out.println( " [" + id + "] 학생의 점수 현황" );
		System.out.println( " Java " + java + "점, SQL " + sql + "점, 수학 " + math + "점, 중국어 " + chinese + "점" );
		System.out.println( "----------------------------------------" );
		System.out.println( "   => 평균 : " + String.format("%.2f", calculateAverage() ) + "점" );
		System.out.println( "----------------------------------------" );
	}
}