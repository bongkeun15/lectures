package com.lgcns.workshop6.movie;

public class Movie {
    
    private String title;
    private String genre;
    private String actor;
    private int releaseYear;
    private String rating;
    private double grade;
    
    public Movie( String title, String genre, String actor ) {
        this.title = title;
        this.genre = genre;
        this.actor = actor;
    }
    
    public Movie( String title, String genre, String actor, int releaseYear ) {
        this( title, genre, actor );
        this.releaseYear = releaseYear;
    }
    
    public Movie( String title, String genre, String actor, int releaseYear, String rating ) {
        this( title, genre, actor, releaseYear );
        this.rating = rating;
    }
    
    public String getGrade() {
        return String.format( "%.1f", grade );
    }
    
    public void setGrade( double grade ) {
        if ( grade < 0 || grade > 5 ) {
            System.out.println( "[에러] 평점은 0 ~ 5 사이의 숫자만 입력할 수 있습니다." );
        } else {
            this.grade = grade;
        }
    }
    
    public void printMovieInfo() {
        
        System.out.print( title + "\t" + genre + "\t" + actor + "\t" );
        
        if ( releaseYear == 0 ) {
            System.out.print( "N/A\t" );
        } else {
            System.out.print( releaseYear + "년\t" );
        }
        
        if ( rating == null ) {
            System.out.print( "N/A\t\t" );
        } else {
            System.out.print( rating + "\t" );
        }
        
        System.out.println( getGrade() + "점" );
    }
}