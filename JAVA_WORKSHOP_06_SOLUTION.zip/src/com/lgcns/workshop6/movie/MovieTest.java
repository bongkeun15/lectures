package com.lgcns.workshop6.movie;

import com.lgcns.workshop6.util.WorkshopUtil;

public class MovieTest {

	public static void main( String[] args ) {

		Movie[] movies = {
				new Movie( "반지의 제왕", "판타지, 모험", "일라이저 우드", 2001, "12세 관람가" ),
				new Movie( "트랜스포머", "SF, 액션", "샤이아 라보프", 2009 ),
				new Movie( "러브 액츄얼리", "멜로, 드라마", "앨런 릭맨 등", 2003, "15세 관람가" ),
				new Movie( "쿵푸 팬더", "애니메이션", "잭 블랙 등" )
		};

		System.out.println( "--------------------------------------------------------------------------------" );
		System.out.println( "    제목\t    장르\t    주연     개봉년도\t    등급\t평점" );
		System.out.println( "--------------------------------------------------------------------------------" );

		for ( int inx = 0 ; inx < movies.length ; inx++ ) {
			movies[inx].printMovieInfo();
		}

		System.out.println( "--------------------------------------------------------------------------------" );

		while ( true ) {

			System.out.println( "==================================" );
			System.out.println( "평점을 입력할 영화를 선택하세요." );
			System.out.println( " 1. 반지의 제왕" );
			System.out.println( " 2. 트랜스포머" );
			System.out.println( " 3. 러브 액츄얼리" );
			System.out.println( " 4. 쿵푸 팬더" );
			System.out.println( "==================================" );

			System.out.print( "영화 번호(종료:0) : " );
			int input = WorkshopUtil.getUserIntegerInput();

			if ( input == 0 ) {
				break;
			} else if(input > 4){
				System.out.println("[에러] 영화 선택은 1 ~ 4 사이의 숫자만 입력할 수 있습니다.");
				continue;
			}

			System.out.print( "선택한 영화의 평점을 입력하세요 : " );
			double grade = WorkshopUtil.getUserDoubleInput();

			movies[input-1].setGrade( grade );

		}

		System.out.println( "--------------------------------------------------------------------------------" );
		System.out.println( "    제목\t    장르\t    주연     개봉년도\t    등급\t평점" );
		System.out.println( "--------------------------------------------------------------------------------" );

		for ( int inx = 0 ; inx < movies.length ; inx++ ) {
			movies[inx].printMovieInfo();
		}

		System.out.println( "--------------------------------------------------------------------------------" );
	}
}