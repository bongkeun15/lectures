package work09.data;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import work09.entity.CartEntity;
import work09.entity.OrderEntity;
import work09.entity.ProductEntity;
import work09.entity.PurchaserEntity;



public class OrderCollection {
	private static OrderCollection instance;
	private HashMap<String, OrderEntity> orderList;

	private OrderCollection() {
		orderList = new HashMap<String, OrderEntity>();

		orderList.put("2015010700668", new OrderEntity("2015010700668", 
				"cns1419918190666", 
				"hong",
				"멀티미디어 슬림PC", 
				2200000,
				"LG전자", 
				3,
				"컴퓨터-데스크탑", 
				"2014년 12월 30일", 
				"F"));


		
		
	}

	public static OrderCollection getInstance() {
		if (instance == null) {
			instance = new OrderCollection();
		}
		return instance;
	}

	public HashMap<String, OrderEntity> getList() {
		return orderList;
	}

	// 구매
	public boolean productOrderBuy(String purchaserId, String pid, Integer amount) {
		HashMap<String, OrderEntity> orderList = OrderCollection.getInstance().getList();
		ProductEntity product = ProductCollection.getInstance().getProductList().get(pid);

		// 1. 구매수량과 재고수량 비교
		if (product.getProductQuantity() < amount) {
			return false;
		} else {
			Calendar cal = Calendar.getInstance();

			String orderId = String.format("%04d%02d%02d%05d",
					cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
					cal.get(Calendar.DAY_OF_MONTH),
					cal.get(Calendar.MILLISECOND));

			// OrderEntity orderEntity = null;
			orderList.put(
					orderId,
					/* orderEntity = */new OrderEntity(orderId, pid,
							purchaserId, product.getProductName(), product
									.getProductPrice(), product
									.getProductCompany(), amount, product
									.getCategoryName(), cal.get(Calendar.YEAR)
									+ "-" + (cal.get(Calendar.MONTH) + 1) + "-"
									+ cal.get(Calendar.DAY_OF_MONTH), "F"));
			/*
			 * 구매 처리시 구매수량과 재고 수량 비교하여 정상/오류(부족) 처리 재고수량 감소 시킬 것
			 */
			// 재고 감소
			product.setProductQuantity(product.getProductQuantity() - amount);

			// 카트에서 제거
			ArrayList<CartEntity> cartList = CartCollection.getInstance()
					.getCartList();
			CartEntity removeEntity = null;
			for (CartEntity temp : cartList) {
				if (temp.getProductId().equals(pid)
						&& temp.getPurchaserId().equals(purchaserId)) {
					removeEntity = temp;
					break;
				}
			}
			/*
			 * 구매 처리 완료 후 장바구니 에서 아이템 제거
			 */			
			return cartList.remove(removeEntity);
		}
	}

	// 전체구매
	public boolean productOrderAllBuy(String purchaserId) {

		HashMap<String, ProductEntity> productList=ProductCollection.getInstance().getProductList();
		ArrayList<CartEntity> cartList=CartCollection.getInstance().getCartList();
		HashMap<String, OrderEntity> orderList = OrderCollection.getInstance().getList();
		ArrayList<CartEntity> temp=new ArrayList<CartEntity>();
		ArrayList<String> ids = new ArrayList<String>();
		//카드에서 사용자 비교???????		
		int i=0;
		for(CartEntity cart : cartList){
			if(!cart.getPurchaserId().equals(purchaserId)){
				continue;
			}
			ProductEntity product=productList.get(cart.getProductId());
			if(cart.getCartQuantity()>product.getProductQuantity()){
				
				for(int x = 0 ; x < temp.size() ; x++){
					CartEntity entity = temp.get(x);
					ProductEntity tempProduct=productList.get(entity.getProductId());
					tempProduct.setProductQuantity(tempProduct.getProductQuantity()+entity.getCartQuantity());
					//cartList.add(entity);
					orderList.remove(ids.get(x));
					
				}
				
				return false;
			}
			Calendar cal = Calendar.getInstance();
			
			String orderId = String.format("%04d%02d%02d%05d",
					cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
					cal.get(Calendar.DAY_OF_MONTH),
					(cal.get(Calendar.MILLISECOND))+i++);

			ids.add(orderId);
			orderList.put(
					orderId,new OrderEntity(
											orderId, 
											product.getProductId(),
											purchaserId, 
											product.getProductName(), 
											product.getProductPrice(), 
											product.getProductCompany(), 
											cart.getCartQuantity(),
											product.getCategoryName(), 
											cal.get(Calendar.YEAR)+ "-" +(cal.get(Calendar.MONTH)+1) +"-"+ cal.get(Calendar.DAY_OF_MONTH),
											"F")
					);
			temp.add(cart);	
			// 재고 감소
			product.setProductQuantity(product.getProductQuantity() - cart.getCartQuantity());
		}	
		for(CartEntity removeEntity : temp){
			cartList.remove(removeEntity);
		}
		
		return true;
		
	}

	// 구매 목록
	public ArrayList<OrderEntity> productOrderList(String purchaserId) {
		ArrayList<OrderEntity> cList = new ArrayList<OrderEntity>();

		for (OrderEntity member : orderList.values()) {
			if (member.getPurchaserId().trim().equals(purchaserId.trim())) {
				cList.add(member);
			}
		}
		return cList;
	}

    public boolean productBuyConfirm(OrderEntity entity){
		
    	boolean result= false;
    	//1. 구매자 회원점수 수정
    	String purchaserID = entity.getPurchaserId();
    	PurchaserCollection collection = PurchaserCollection.getInstance();
    	HashMap<String, PurchaserEntity> purchasers = collection.getPurchasers();
    	for(PurchaserEntity pEntity : purchasers.values()){
    		if(purchaserID.equals(pEntity.getPurchaserId()) ){
    			pEntity.setPurchaserScore(pEntity.getPurchaserScore()+entity.getProductPrice()/1000);
    			result= true;
    		}
    	}
    	//2. 구매 테이블 구매확정여부 수정
    	for(OrderEntity oEntity : orderList.values()){
    		System.out.println("entity.getOrderId() > " + entity.getOrderId());
    		System.out.println("oEntity.getOrderId() > " + oEntity.getOrderId());
    		if(entity.getOrderId().equals(oEntity.getOrderId())){
    			oEntity.setOrderConfirm("T");
    			result= true;
    		}
    	}
    	
    	return result;
    	
	}
	public boolean productBuyCancel(OrderEntity entity){
		boolean result= false;
		//1. 재고 수정
		String purchaserID = entity.getPurchaserId();
		ProductCollection collection = ProductCollection.getInstance();
		HashMap<String, ProductEntity> products = collection.getProductList();
	  for(ProductEntity pEntity: products.values()){
		  if(entity.getProductId().equals(pEntity.getProductId())){
			  pEntity.setProductQuantity(entity.getOrderQuantity()+pEntity.getProductQuantity());
			  result= true;
		  }
	  }
		
		//2. 구매 테이블 삭제
	    for(OrderEntity oEntity : orderList.values()){
	    	if(entity.getOrderId().equals(oEntity.getOrderId())){
	    		orderList.remove(entity.getOrderId());
	    		result= true;
	    		break;
	    	}
	    }
	  
	  
	  
		return result;
	}

}
