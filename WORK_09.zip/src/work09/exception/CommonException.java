/*
 *   1. Biz 클래스에서 JDBC 연동시 사용하는 예외클래스
 *   
 *    - MessageEntity 클래스에 예러처리 정보를 저장하여 사용한다.
 * 
 * 
 */


package work09.exception;

import work09.entity.MessageEntity;



public class CommonException extends Exception {
	private MessageEntity entity;
	
	public CommonException() {}
	
	public CommonException(MessageEntity entity) {
		this.entity = entity;
	}
	
	public MessageEntity getMessageEntity() {
		return entity;
	}
}
