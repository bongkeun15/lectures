package work09.biz;

import java.util.ArrayList;

import work09.data.CartCollection;
import work09.entity.CartEntity;



public class CartBiz {
	
	public void productAddCart(CartEntity entity) {
		CartCollection collection = CartCollection.getInstance();
	    collection.productAddCart(entity);
	}
	public ArrayList<CartEntity> cartList(String purchaser_id){
		CartCollection collection = CartCollection.getInstance();
		return collection.cartList(purchaser_id);
	}
	
	public boolean productUpdateCart(CartEntity entity) {
		CartCollection collection = CartCollection.getInstance();
		return collection.productUpdateCart(entity);
	}
	
	public boolean productDeleteCart(CartEntity entity){
		CartCollection collection = CartCollection.getInstance();
		return collection.productDeleteCart(entity);
	}
}
