package work09.biz;



import work09.data.SellerCollection;
import work09.entity.SellerEntity;





public class SellerBiz {

	
	public boolean sellerAdd(SellerEntity entity){
		SellerCollection collection = SellerCollection.getInstance();
		return collection.sellerAdd(entity);
	}
	// 로그인
	public SellerEntity login(String id, String pw){
		SellerCollection collection = SellerCollection.getInstance();
		return collection.login(id, pw);
		
	}
	public SellerEntity sellerUpdateForm(String id){
		SellerCollection collection = SellerCollection.getInstance();
		return collection.sellerUpdateForm(id);
	}
	public boolean sellerUpdate(SellerEntity entity){
		SellerCollection collection = SellerCollection.getInstance();
		return collection.sellerUpdate(entity);
	}

}
