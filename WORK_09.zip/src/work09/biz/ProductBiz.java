package work09.biz;

import java.util.HashMap;

import work09.data.ProductCollection;
import work09.entity.ProductEntity;

public class ProductBiz {

	public HashMap<String, ProductEntity> getProductList() {
		// TODO Auto-generated method stub
		ProductCollection productCollection = ProductCollection.getInstance();
		return productCollection.getProductList();
	}

	public boolean productAdd(ProductEntity entity) {
		ProductCollection productCollection = ProductCollection.getInstance();
		return productCollection.productAdd(entity);
	}

	public HashMap<String, ProductEntity> getProductListById(String id) {

		ProductCollection productCollection = ProductCollection.getInstance();
		return productCollection.getProductListById(id);

	}

}
