package work09.biz;

import java.util.ArrayList;

import work09.data.OrderCollection;
import work09.entity.OrderEntity;

public class OrderBiz {

	public boolean productOrderBuy(String purchaserId, String pid, Integer amount) {
		OrderCollection collection = OrderCollection.getInstance();
		return collection.productOrderBuy(purchaserId, pid, amount);
	}

	public boolean productOrderAllBuy(String purchaserId) {
		OrderCollection collection = OrderCollection.getInstance();
		return collection.productOrderAllBuy(purchaserId);
	}
	
	public ArrayList<OrderEntity> productOrderList(String purchaserId) {
		
		OrderCollection collection = OrderCollection.getInstance();
		return collection.productOrderList(purchaserId);
	}
	
	public boolean productBuyConfirm(OrderEntity entity){
		OrderCollection collection = OrderCollection.getInstance();
		return collection.productBuyConfirm(entity);
	}
	public boolean productBuyCancel(OrderEntity entity){
		OrderCollection collection = OrderCollection.getInstance();
		return collection.productBuyCancel(entity);
	}
	
}
