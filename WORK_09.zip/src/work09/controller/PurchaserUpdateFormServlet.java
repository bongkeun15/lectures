package work09.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.PurchaserBiz;
import work09.entity.PurchaserEntity;






/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work09.PurchaserUpdateForm", urlPatterns = { "/work09/purchaserUpdateForm" })
public class PurchaserUpdateFormServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		// session 이용 가능.
		HttpSession session = request.getSession();


			PurchaserEntity entity = (PurchaserEntity)session.getAttribute("purchaserLogin");
		  	

			String purchaserId = entity.getPurchaserId();
	
		
			
			PurchaserBiz biz = new PurchaserBiz();
			entity = biz.purchaserUpdateForm(purchaserId);
		   
			session.setAttribute("purchaserUpdateEntity", entity);
			response.sendRedirect("/work/work09/purchaser/purchaserUpdateForm.jsp");
			
			
			
		
	}

}
