package work09.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.OrderBiz;
import work09.entity.MessageEntity;
import work09.entity.PurchaserEntity;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name = "work09.ProductOrderBuy", urlPatterns = "/work09/productOrderBuy")
public class ProductOrderBuyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		String productId = request.getParameter("productId");
		int cartQuantity = Integer.parseInt(request.getParameter("cartQuantity"));
		
		System.out.println(productId+" " + cartQuantity);
		if (session.getAttribute("purchaserLogin") != null) {
			
			String purchaserId = ((PurchaserEntity) session.getAttribute("purchaserLogin")).getPurchaserId();
			OrderBiz biz=new OrderBiz();
			
			boolean addResult=biz.productOrderBuy(purchaserId , productId , cartQuantity);
			
			MessageEntity message = null;
			if (addResult) {
				message = new MessageEntity("success", 5);

			} else {
				message = new MessageEntity("error", 10);
			}

			message.setUrl("/work/work09/productOrderList");
			message.setLinkTitle("주문 내역 보기");

			session.setAttribute("message", message);
			response.sendRedirect("message.jsp");
		
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");

			session.setAttribute("message", message);
			response.sendRedirect("message.jsp");
		}

	}
}
