package work09.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.SellerBiz;
import work09.entity.MessageEntity;
import work09.entity.SellerEntity;
import work09.util.ValidationUtil;



/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work09.SellerUpdate", urlPatterns = { "/work09/sellerUpdate" })
public class SellerUpdateServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
request.setCharacterEncoding("UTF-8");
		
		//파라미터 추출
		String sellerId = request.getParameter("sellerId");
		String sellerPw = request.getParameter("sellerPw");
		String sellerName = request.getParameter("sellerName");
		String sellerAddr = request.getParameter("sellerAddr");
		String sellerPhone1 = request.getParameter("sellerPhone1");
		String sellerPhone2 = request.getParameter("sellerPhone2");
		String sellerPhone3 = request.getParameter("sellerPhone3");
		String sellerEmail = request.getParameter("sellerEmail");
		String sellerRegNum1 = request.getParameter("sellerRegNum1");
		String sellerRegNum2 = request.getParameter("sellerRegNum2");
		String sellerRegNum3 = request.getParameter("sellerRegNum3");
		String sellerAccount = request.getParameter("sellerAccount");
		String sellerPhone = sellerPhone1 +"-"+ sellerPhone2 +"-"+sellerPhone2;
		String sellerRegNum = sellerRegNum1 +"-"+ sellerRegNum2 +"-"+sellerRegNum3;
		
		
		SellerEntity entity = new SellerEntity(sellerId, sellerPw, sellerName, sellerAddr, sellerPhone, sellerEmail, sellerRegNum, sellerAccount);
		
		HttpSession session = request.getSession();
		// 입력 데이터 validation 처리 작업
		if (! ValidationUtil.checkRequired(sellerId) || ! ValidationUtil.checkAlphaDigit(sellerId)
				|| ! ValidationUtil.lessLength(sellerId, 10)) {

			MessageEntity message = new MessageEntity("validation", 0);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("판매자 회원 등록");
			session.setAttribute("message", message);	

		} else if (! ValidationUtil.checkRequired(sellerPw) || ! ValidationUtil.checkRequired(sellerPw)
				|| ! ValidationUtil.lessLength(sellerPw, 10)) {
			MessageEntity message = new MessageEntity("validation", 1);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("판매자 회원 등록");
			session.setAttribute("message", message);	

		} else if (! ValidationUtil.checkRequired(sellerName)
				|| ! ValidationUtil.lessLength(sellerName, 10)) {

			MessageEntity message = new MessageEntity("validation", 2);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("판매자 회원 등록");
			session.setAttribute("message", message);	
		} else if (! ValidationUtil.checkRequired(sellerAddr)) {

			MessageEntity message = new MessageEntity("validation", 3);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);	

		} else if (! ValidationUtil.checkRequired(sellerPhone1)
				|| ! ValidationUtil.checkRequired(sellerPhone2)
				|| ! ValidationUtil.checkRequired(sellerPhone3)
				|| ! ValidationUtil.checkDigit(sellerPhone1)
				|| ! ValidationUtil.lessLength(sellerPhone1, 5)
				|| ! ValidationUtil.checkDigit(sellerPhone2)
				|| ! ValidationUtil.lessLength(sellerPhone2, 5)
				|| ! ValidationUtil.checkDigit(sellerPhone3)
				|| ! ValidationUtil.lessLength(sellerPhone3, 5)) {

			MessageEntity message = new MessageEntity("validation", 4);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);	

		} else if (!ValidationUtil.checkRequired(sellerEmail)) {

			MessageEntity message = new MessageEntity("validation", 5);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);	

		} else if (! ValidationUtil.checkRequired(sellerRegNum1)
				|| ! ValidationUtil.equalLength(sellerRegNum1 , 3)
				|| ! ValidationUtil.checkRequired(sellerRegNum2) 
				|| ! ValidationUtil.equalLength(sellerRegNum2 , 2)
				|| ! ValidationUtil.checkRequired(sellerRegNum3) 
				|| ! ValidationUtil.equalLength(sellerRegNum3 , 5)) {

			MessageEntity message = new MessageEntity("validation", 6);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);	
		} else if (! ValidationUtil.checkRequired(sellerAccount)) {

			MessageEntity message = new MessageEntity("validation", 7);
			message.setUrl("/work/work09/sellerUpdateForm");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);	
			
		} else {
			

			SellerBiz biz = new SellerBiz();
			boolean result = biz.sellerUpdate(entity);
			 
			if (result) {
			
					//성공
					MessageEntity message = new MessageEntity("success", 8);
					message.setUrl("/work/work09/productList");
					message.setLinkTitle("상품 목록보기");
					session.setAttribute("message", message);

				
			} else {
				
	
				MessageEntity message = new MessageEntity("error", 10 );
				message.setUrl("/work/work09/sellerUpdateForm");
				message.setLinkTitle("회원 수정");
				session.setAttribute("message", message);
			}

		}
		

		
				response.sendRedirect("message.jsp");
		
	}

}
