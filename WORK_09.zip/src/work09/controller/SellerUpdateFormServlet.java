package work09.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.SellerBiz;
import work09.entity.SellerEntity;



/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work09.SellerUpdateForm", urlPatterns = { "/work09/sellerUpdateForm" })
public class SellerUpdateFormServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		// session 이용 가능.
		HttpSession session = request.getSession();
		String id = null;
		
			SellerEntity entity = (SellerEntity) session
					.getAttribute("sellerLogin");
			id = entity.getSellerId();
		

			SellerBiz biz = new SellerBiz();
	
		
			 entity = biz.sellerUpdateForm(id);
		
			  String sellerId = entity.getSellerId();
			   String sellerPw = entity.getSellerPw();
			   String sellerName = entity.getSellerName();
			   String sellerAddr = entity.getSellerAddr();
			   String sellerPhone = entity.getSellerPhone();
			 System.out.println("seller_phone >> " + sellerPhone);
			   String sellerPhone1 = sellerPhone.split("-")[1];
			   String sellerPhone2 = sellerPhone.split("-")[2];
			   
			   String sellerEmail = entity.getSellerEmail();
			   String sellerRegNum = entity.getSellerRegNum();
			   String sellerRegNum1 = sellerRegNum.split("-")[0];
			   String sellerRegNum2 = sellerRegNum.split("-")[1];
			   String sellerRegNum3 = sellerRegNum.split("-")[2];
			   
			   
			   String sellerAccount = entity.getSellerAccount();
			   

				session.setAttribute("sellerUpdateEntity", entity);
				response.sendRedirect("/work/work09/seller/sellerUpdateForm.jsp");
	}

}
