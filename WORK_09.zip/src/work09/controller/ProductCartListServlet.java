package work09.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.CartBiz;
import work09.entity.CartEntity;
import work09.entity.PurchaserEntity;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name = "work09.ProductCartList", urlPatterns = "/work09/productCartList")
public class ProductCartListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {	
		HttpSession session = request.getSession();

		
			
			String purchaserId=((PurchaserEntity)session.getAttribute("purchaserLogin")).getPurchaserId();			
		
			CartBiz biz = new CartBiz();
			
			ArrayList<CartEntity> cart = biz.cartList(purchaserId);

			session.setAttribute("cartList", cart);
			response.sendRedirect("/work/work09/product/productCartList.jsp");
	

	}

}
