package work09.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.OrderBiz;
import work09.entity.MessageEntity;
import work09.entity.OrderEntity;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work09.ProductBuyCancel", urlPatterns = { "/work09/productBuyCancel" })
public class ProductBuyCancelServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
			String purchaserId = request.getParameter("purchaserId");
			String orderId = request.getParameter("orderId");
			String productId = request.getParameter("productId"); // 구매자 아이디
			int orderQuantity = Integer.parseInt(request
					.getParameter("orderQuantity"));

			OrderBiz biz = new OrderBiz();

			OrderEntity entity = new OrderEntity();
			entity.setProductId(productId);
			entity.setOrderQuantity(orderQuantity);
			entity.setOrderId(orderId);
			boolean result = biz.productBuyCancel(entity);
			if (result) {
				MessageEntity message = new MessageEntity("success", 10);
				message.setUrl("/work/work09/productOrderList");
				message.setLinkTitle("구매 목록");
				session.setAttribute("message", message);

			} else {

				MessageEntity message = new MessageEntity("error", 13);
				message.setUrl("/work/work09/productOrderList");
				message.setLinkTitle("구매 목록");
				session.setAttribute("message", message);
			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			session.setAttribute("message", message);

		}
		response.sendRedirect("message.jsp");

	}

}
