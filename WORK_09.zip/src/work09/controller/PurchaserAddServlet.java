package work09.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.PurchaserBiz;
import work09.entity.MessageEntity;
import work09.entity.PurchaserEntity;
import work09.util.ValidationUtil;

//서블릿 이름 설정 및 urlPattern을 이용한 서블릿 맵핑처리
@WebServlet(name = "work09.PurchaserAdd", urlPatterns = { "/work09/purchaserAdd" })
public class PurchaserAddServlet extends HttpServlet {


	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// 입력 데이터의 한글처리를 위한 인코딩 처리 작업
		request.setCharacterEncoding("UTF-8");

		// 입력 데이터를 얻는 처리 작업
		String purchaserId = request.getParameter("purchaserId");
		String purchaserPw = request.getParameter("purchaserPw");
		String purchaserName = request.getParameter("purchaserName");
		String purchaserAddr = request.getParameter("purchaserAddr");
		String purchaserPhone1 = request.getParameter("purchaserPhone1");
		String purchaserPhone2 = request.getParameter("purchaserPhone2");
		String purchaserPhone3 = request.getParameter("purchaserPhone3");
		String purchaserEmail = request.getParameter("purchaserEmail");
		String purchaserPhone = purchaserPhone1 + "-" + purchaserPhone2
				+ "-" + purchaserPhone3;


	
		
		HttpSession session = request.getSession();
		
		if (! ValidationUtil.checkRequired(purchaserId) || ! ValidationUtil.checkAlphaDigit(purchaserId)
				|| ! ValidationUtil.lessLength(purchaserId, 10)) {

			MessageEntity message = new MessageEntity("validation", 0);
			message.setUrl("/work/work09/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserPw) || ! ValidationUtil.checkRequired(purchaserPw)
				|| ! ValidationUtil.lessLength(purchaserPw, 10)) {
			MessageEntity message = new MessageEntity("validation", 1); 
			message.setUrl("/work/work09/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserName)
				|| ! ValidationUtil.lessLength(purchaserName, 10)) {

			MessageEntity message = new MessageEntity("validation", 2);
			message.setUrl("/work/work09/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);
		} else if (! ValidationUtil.checkRequired(purchaserAddr)) {

			MessageEntity message = new MessageEntity("validation", 3);
			message.setUrl("/work/work09/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserPhone1)
				|| ! ValidationUtil.checkRequired(purchaserPhone2)
				|| ! ValidationUtil.checkRequired(purchaserPhone3)
				|| ! ValidationUtil.checkDigit(purchaserPhone1)
				|| ! ValidationUtil.lessLength(purchaserPhone1, 5)
				|| ! ValidationUtil.checkDigit(purchaserPhone2)
				|| ! ValidationUtil.lessLength(purchaserPhone2, 5)
				|| ! ValidationUtil.checkDigit(purchaserPhone3)
				|| ! ValidationUtil.lessLength(purchaserPhone3, 5)) {

			MessageEntity message = new MessageEntity("validation", 4);
			message.setUrl("/work/work09/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);

		} else if (! ValidationUtil.checkRequired(purchaserEmail)) {

			MessageEntity message = new MessageEntity("validation", 5);
			message.setUrl("/work/work09/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 등록");
			session.setAttribute("message", message);

		} else {

			
			
			PurchaserEntity entity =
					new PurchaserEntity(purchaserId, purchaserPw, purchaserName, purchaserAddr, purchaserPhone, purchaserEmail,0 ,"E");
			
		
			PurchaserBiz biz = new PurchaserBiz();
			boolean result = biz.purchaserAdd(entity);
			
	
		   if(result){
			   // 성공
				MessageEntity message = new MessageEntity("success", 7);
				message.setUrl("/work/work09/loginForm.html");
				message.setLinkTitle("로그인");
				session.setAttribute("message", message);
				
				
		   }else{
				MessageEntity message = new MessageEntity("error", 9);
				message.setUrl("/work/work09/purchaser/purchaserForm.html");
				message.setLinkTitle("구매자 등록");
				session.setAttribute("message", message);
		   }
		   

		}
		response.sendRedirect("message.jsp");

	}

	
}// end class
