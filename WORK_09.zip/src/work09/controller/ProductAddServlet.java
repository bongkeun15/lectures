package work09.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.ProductBiz;
import work09.entity.MessageEntity;
import work09.entity.ProductEntity;
import work09.entity.SellerEntity;
import work09.util.ValidationUtil;





// 서블릿 이름 설정 및 urlPattern을 이용한 서블릿 맵핑처리
@WebServlet(name="work09.ProductAdd" , urlPatterns={"/work09/productAdd"})
public class ProductAddServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 입력 데이터의 한글처리를 위한 인코딩 처리 작업
		request.setCharacterEncoding("UTF-8");
		
		// 입력 데이터를 얻는 처리 작업
		String categoryId = request.getParameter("categoryId");
		String productName = request.getParameter("productName");
		String productPrice = request.getParameter("productPrice");
		String productCompany = request.getParameter("productCompany");
		String productQuantity = request.getParameter("productQuantity");
		String productInfo = request.getParameter("productInfo");

		HttpSession session = request.getSession();
		//입력 데이터 validation 처리 작업
		// 입력 데이터 validation 처리 작업
				if (! ValidationUtil.checkRequired(categoryId)) {
					MessageEntity message = new MessageEntity("validation", 9); 
					message.setUrl("/work/work09/product/productAddForm.html");
					message.setLinkTitle("상품 등록");
					session.setAttribute("message", message);

				} else if (! ValidationUtil.checkRequired(productName)) {

					MessageEntity message = new MessageEntity("validation", 10); 
					message.setUrl("/work/work09/product/productAddForm.html");
					message.setLinkTitle("상품 등록");
					session.setAttribute("message", message);

				} else if (! ValidationUtil.checkRequired(productPrice) || ! ValidationUtil.checkDigit(productPrice)) {
					MessageEntity message = new MessageEntity("validation", 11); 
					message.setUrl("/work/work09/product/productAddForm.html");
					message.setLinkTitle("상품 등록");
					session.setAttribute("message", message);

				} else if (! ValidationUtil.checkRequired(productCompany)) {
					MessageEntity message = new MessageEntity("validation", 12); 
					message.setUrl("/work/work09/product/productAddForm.html");
					message.setLinkTitle("상품 등록");
					session.setAttribute("message", message);
				} else if (! ValidationUtil.checkRequired(productQuantity)
						|| ! ValidationUtil.checkDigit(productQuantity) || ! ValidationUtil.lessLength(productQuantity, 4)) {
					MessageEntity message = new MessageEntity("validation", 13); 
					message.setUrl("/work/work09/product/productAddForm.html");
					message.setLinkTitle("상품 등록");
					session.setAttribute("message", message);

				} else if (! ValidationUtil.checkRequired(productInfo)) {
					MessageEntity message = new MessageEntity("validation", 14);
					message.setUrl("/work/work09/product/productAddForm.html");
					message.setLinkTitle("상품 등록");
					session.setAttribute("message", message);

				} else {
		
			
			//현재 시간 구하기
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일");
			String productDate = sdf.format(new Date());
			

			HttpSession sess = request.getSession();

				SellerEntity xxx = (SellerEntity)sess.getAttribute("sellerLogin");
				String sellerId = xxx.getSellerId();
		
			// 상품아이디 = 판매자아이디+시간
			String product_id = sellerId+System.currentTimeMillis();
			
			ProductEntity entity = 
					new ProductEntity(product_id, categoryId, productName, Integer.parseInt(productPrice), productCompany, Integer.parseInt(productQuantity), productInfo, productDate, sellerId);
			
			
			//상품 저장
			ProductBiz biz = new ProductBiz();
			boolean result = biz.productAdd(entity);
		   if(result){
			   
				MessageEntity message = new MessageEntity("success", 6);
				message.setUrl("/work/work09/productList");
				message.setLinkTitle("상품 목록");
				session.setAttribute("message", message);
	
		   }else{
			   
			// 성공
				MessageEntity message = new MessageEntity("error", 7);
				message.setUrl("/work/work09/productList");
				message.setLinkTitle("상품 목록");
				session.setAttribute("message", message);
			   session.setAttribute("message", message);
	
		   }
		   
		
		}//end if

				response.sendRedirect("message.jsp");
	}

}
