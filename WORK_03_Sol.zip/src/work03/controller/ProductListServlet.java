package work03.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work03.data.ProductCollection;
import work03.entity.ProductEntity;

@WebServlet(name = "work03.ProductList", urlPatterns = { "/work03/productList" })
public class ProductListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		ProductCollection productCollection = ProductCollection.getInstance();
		HashMap<String, ProductEntity> list = productCollection
				.getProductList();

		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		out.println("<h1>[상품 목록]</h1>");
		out.println("<table border=1>");
		out.println("<tr>");

		out.println("<td>상품명</td>");
		out.println("<td>카테고리명</td>");
		out.println("<td>가격</td>");
		out.println("<td>제조사</td>");
		out.println("<td>재고</td>");
		out.println("<td>등록일자</td>");
		out.println("</tr>");


      if(list.size() != 0 ){
			Set<String> keys = list.keySet();
			for (String key : keys) {
				ProductEntity entity = list.get(key);
				out.println("<tr>");
				out.println("<td>" + entity.getProductName() + "</td>");
				out.println("<td>" + entity.getCategoryName() + "</td>");
				out.println("<td>" + entity.getProductPrice() + "</td>");
				out.println("<td>" + entity.getProductCompany() + "</td>");
				out.println("<td>" + entity.getProductQuantity() + "</td>");
				out.println("<td>" + entity.getProductDate() + "</td>");
				out.println("</tr>");
			}
      }else{
    	  
    	  out.println("<tr>");
			out.println("<td colspan='6'>등록된 상품이 없습니다.</td>");
			out.println("</tr>");
      }

		out.println("</table>");

		out.println("</body></html>");
	}

}
