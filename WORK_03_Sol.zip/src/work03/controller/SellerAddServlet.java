package work03.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import work03.util.ValidationUtil;

@WebServlet(name = "work03.SellerAdd", urlPatterns = { "/work03/sellerAdd" })
public class SellerAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String sellerId = request.getParameter("sellerId");
		String sellerPw = request.getParameter("sellerPw");
		String sellerName = request.getParameter("sellerName");
		String sellerAddr = request.getParameter("sellerAddr");
		String sellerPhone1 = request.getParameter("sellerPhone1");
		String sellerPhone2 = request.getParameter("sellerPhone2");
		String sellerPhone3 = request.getParameter("sellerPhone3");
		String sellerEmail = request.getParameter("sellerEmail");
		String sellerRegNum1 = request.getParameter("sellerRegNum1");
		String sellerRegNum2 = request.getParameter("sellerRegNum2");
		String sellerRegNum3 = request.getParameter("sellerRegNum3");
		String sellerAccount = request.getParameter("sellerAccount");
		String sellerPhone = sellerPhone1 + "-" + sellerPhone2 + "-"
				+ sellerPhone3;
		String sellerRegNum = sellerRegNum1 + "-" + sellerRegNum2 + "-"
				+ sellerRegNum3;

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		if (!ValidationUtil.checkRequired(sellerId)
				|| !ValidationUtil.checkAlphaDigit(sellerId)
				|| !ValidationUtil.lessLength(sellerId, 10)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[아이디 정보 오류].");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(sellerPw)
				|| !ValidationUtil.checkAlphaDigit(sellerPw)
				|| !ValidationUtil.lessLength(sellerPw, 10)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[비밀번호 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(sellerName)
				|| !ValidationUtil.lessLength(sellerName, 10)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[이름 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(sellerAddr)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[주소 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(sellerPhone1)
				|| !ValidationUtil.checkRequired(sellerPhone2)
				|| !ValidationUtil.checkRequired(sellerPhone2)
				|| !ValidationUtil.checkDigit(sellerPhone1)
				|| !ValidationUtil.lessLength(sellerPhone1, 5)
				|| !ValidationUtil.checkDigit(sellerPhone2)
				|| !ValidationUtil.lessLength(sellerPhone2, 5)
				|| !ValidationUtil.checkDigit(sellerPhone3)
				|| !ValidationUtil.lessLength(sellerPhone3, 5)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[전화번호 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(sellerEmail)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[이메일 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(sellerRegNum1)
				|| !ValidationUtil.equalLength(sellerRegNum1, 3)
				|| !ValidationUtil.checkRequired(sellerRegNum2)
				|| !ValidationUtil.equalLength(sellerRegNum2, 2)
				|| !ValidationUtil.checkRequired(sellerRegNum3)
				|| !ValidationUtil.equalLength(sellerRegNum3, 5)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[사업자등록번호 정보 오류] ");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(sellerAccount)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[계좌번호 정보 오류] ");
			out.println("<hr>");
			out.println("<a href='/work/work03/seller/sellerForm.html'>판매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else {

			out.println("아이디: " + sellerId + "<br>");
			out.println("비밀번호: " + sellerPw + "<br>");
			out.println("이름: " + sellerName + "<br>");
			out.println("주소: " + sellerAddr + "<br>");
			out.println("전화번호: " + sellerPhone + "<br>");
			out.println("이메일: " + sellerEmail + "<br>");
			out.println("사업자등록번호: " + sellerRegNum + "<br>");
			out.println("계좌번호: " + sellerAccount + "<br>");
			out.println("</body></html>");
		}
	}

}
