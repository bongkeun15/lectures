package work03.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import work03.data.ProductCollection;
import work03.entity.ProductEntity;
import work03.util.ValidationUtil;

@WebServlet(name = "work03.ProductAdd", urlPatterns = { "/work03/productAdd" })
public class ProductAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String categoryId = request.getParameter("categoryId");
		String productName = request.getParameter("productName");
		String productPrice = request.getParameter("productPrice");
		String productCompany = request.getParameter("productCompany");
		String productQuantity = request.getParameter("productQuantity");
		String productInfo = request.getParameter("productInfo");

		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		if (!ValidationUtil.checkRequired(categoryId)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[카테고리 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productName)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[상품명 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");
			
		} else if (!ValidationUtil.checkRequired(productPrice)
				|| !ValidationUtil.checkDigit(productPrice)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[가격 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productCompany)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[제조사 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");
			
		} else if (!ValidationUtil.checkRequired(productQuantity)
				|| !ValidationUtil.checkDigit(productQuantity)
				|| !ValidationUtil.lessLength(productQuantity, 4)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[수량 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productInfo)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[상품 소개 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work03/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else {

	
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일");
			String productDate = sdf.format(new Date());

			ProductEntity entity = new ProductEntity(categoryId, productName,
					Integer.parseInt(productPrice), productCompany,
					Integer.parseInt(productQuantity), productInfo, productDate);

			ProductCollection productCollection = ProductCollection
					.getInstance();
			boolean result = productCollection.productAdd(entity);
			
			if (result) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[상품 등록 성공]");
				out.print("</font>");
				out.println("<hr>");
				out.println("<a href='/work/work03/productList'>상품 목록 보기</a>");

			} else {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[상품 등록 실패]");
				out.print("</font>");
				out.println("<hr>");
				out.println(productName + " 상품명이 중복 되었습니다.<br>");
				out.println("<a href='/work/work03/product/productAddForm.html'>상품 등록하기</a>");
				out.print("<center>");

			}

		}

		out.println("</body></html>");

	}

}
