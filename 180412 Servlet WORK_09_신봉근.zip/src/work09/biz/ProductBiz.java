package work09.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;

import work09.common.JdbcTemplate;
import work09.data.ProductCollection;
import work09.entity.MessageEntity;
import work09.entity.ProductEntity;
import work09.exception.CommonException;

public class ProductBiz {

	public HashMap<String, ProductEntity> getProductList() throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
	    Statement stmt = null;
	    ResultSet rset = null;
	    
	    ProductEntity entity = null;
	    HashMap<String, ProductEntity> map = null;
	    System.out.println( "1" );
	    try{
	        System.out.println( "11" );
	        String sql = "SELECT PRODUCT_ID, CATEGORY_LARGE||'-'||CATEGORY_MIDDLE CTGR, PRODUCT_NAME, PRODUCT_PRICE, "
	                   + "PRODUCT_INFO, PRODUCT_COMPANY, TO_CHAR(PRODUCT_DATE, 'YYYY-MM-DD'),                        "
	                   + "PRODUCT_QUANTITY, SELLER_ID, A.CATEGORY_ID                                                 "
	                   + "FROM PRODUCT A, CATEGORY B WHERE A.CATEGORY_ID = B.CATEGORY_ID                             ";
	        
	        System.out.println( "111" );
	        
	        stmt = con.createStatement();
	        System.out.println( "1111" + con );
	        System.out.println( "1111" + stmt );
	        
	        rset = stmt.executeQuery( sql );
	        
	        System.out.println( "11111" + rset);
	        
	        
	        map = new HashMap<String, ProductEntity>();
	        
	        int count = 1;
	        
	        System.out.println( "rset1" + rset );
	        
	        while(rset.next()) {
	            
	            System.out.println( "rset2" + rset );
	            String product_id = rset.getString( 1 );
	            String category_name = rset.getString( "ctgr" );
	            String product_name = rset.getString( 3 );
	            int product_price = rset.getInt( 4 );
	            String product_info = rset.getString( 5 );
	            String product_company = rset.getString( 6 );
	            String product_date = rset.getString( 7 );
	            int product_quantity = rset.getInt( 8 );
	            String seller_id = rset.getString( 9);
	            String category_id = rset.getString( 10 );
	            count++;
	            
	            entity = new ProductEntity (
	                    product_id, category_id, product_name, product_price, product_company,
	                    product_quantity, product_info, product_date, seller_id
	                    );
	            System.out.println( "3" );
	            entity.setCategoryName(category_name);
	            map.put(product_id, entity);
	        }
	        
	        
	    } catch (Exception e) {
	        MessageEntity msg = new MessageEntity("error", 8);
            msg.setUrl( "/work/work09/productOrderList" );
            msg.setLinkTitle( "상품 목록" );
            throw new CommonException(msg);
	    } finally {
	        
	        JdbcTemplate.close( rset );
	        JdbcTemplate.close( stmt );
	        JdbcTemplate.close( con );
	    }
	    return map;
	}

	
	
	
	
	public void productAdd(ProductEntity entity) throws CommonException {
		Connection con = JdbcTemplate.getConnection();
		PreparedStatement preStmt = null;
		
		try {
		    String sql = "INSERT INTO PRODUCT "
		               + "(PRODUCT_ID, "              // 1
		               + "CATEGORY_ID, "              // 2
		               + "PRODUCT_NAME, "             // 3
		               + "PRODUCT_PRICE, "            // 4
		               + "PRODUCT_INFO, "             // 5
		               + "PRODUCT_COMPANY, "          // 6
		               + "PRODUCT_DATE, "             // 7
		               + "PRODUCT_QUANTITY, "         // 8
		               + "SELLER_ID) "                // 9
		               
		               + "VALUES(?,?,?,?,?,?, TO_DATE(?, 'RR/MM/DD'), ?,? )";
		               //        1 2 3 4 5 6  7                       8 9
		    
		    preStmt = con.prepareStatement(sql);
		    
		    preStmt.setString( 1, entity.getProductId()        );
		    preStmt.setString( 2, entity.getCategoryId()       );
		    preStmt.setString( 3, entity.getProductName()      );
		    preStmt.setInt   ( 4, entity.getProductPrice()     );
		    preStmt.setString( 5, entity.getProductInfo()      );
		    preStmt.setString( 6, entity.getProductCompany()   );
		    preStmt.setString( 7, entity.getProductDate()      );
		    preStmt.setInt   ( 8, entity.getProductQuantity()  );
		    preStmt.setString( 9, entity.getSellerId()         );
		    
		    int result = preStmt.executeUpdate();
		    
		    if(result == 0){
		        throw new Exception();
		    }
		    JdbcTemplate.rollback( con );
		    
		} catch (Exception e) {
		    MessageEntity msg = new MessageEntity("error", 7);
            msg.setUrl( "/work/work09/productOrderList" );
            msg.setLinkTitle( "상품 목록" );
            throw new CommonException(msg);
		} finally {
		    JdbcTemplate.close( preStmt );
		    JdbcTemplate.close( con);
		}
	}

	
	
	
	
	public HashMap<String, ProductEntity> getProductListById(String id) throws CommonException{
	    
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    ResultSet rset = null;
	    
	    ProductEntity entity = null;
	    HashMap<String, ProductEntity> map = new HashMap<String, ProductEntity>();
	    
	    try{
	        String sql = "SELECT "
	                   + "PRODUCT_ID, "                           // 1
	                   + "CATEGORY_LARGH||'-'||CATEGORY_MIDDLE CTGR, "   // 2
	                   + "PRODUCT_NAME, "                                // 3
	                   + "PRODUCT_PRICE, "                               // 4
	                   + "PRODUCT_INFO, "                                // 5
	                   + "PRODUCT_COMPANY, "                             // 6
	                   + "PRODUCT_DATE, "                                // 7
	                   + "PRODUCT_QUANTITY, "                            // 8
	                   + "SELLER_ID, "                                   // 9
	                   + "P.CATEGORY_ID "                                // 10
	                   
	                   + "FROM "
	                   + "PRODUCT P, "                              
	                   + "CATEGORY C "                                   
	                   
	                   + "WHERE "
	                   + "P.CATEGORY_ID = C.CATEGORY_ID "
	                   + "AND SELLER_ID = ? ";
	    
	        
	    preStmt = con.prepareStatement( sql );
	    preStmt.setString( 1,  id  );
	    rset = preStmt.executeQuery();
	    
	    while(rset.next()) { 
	            String product_id       = rset.getString( 1  );
	            String category_name    = rset.getString("ctgr");
	            String product_name     = rset.getString( 3  );
	            int    product_price    = rset.getInt   ( 4  );
	            String product_info     = rset.getString( 5  );
	            String product_company  = rset.getString( 6  );
	            String product_date     = rset.getString( 7  );
	            int    product_quantity = rset.getInt   ( 8  );
	            String seller_id        = rset.getString( 9  );
	            String category_id      = rset.getString( 10 );
	            
	            
	            entity = new ProductEntity (
	                    product_id, category_id, product_name, product_price, product_company,
	                    product_quantity, product_info, product_date, seller_id  );
	            entity.setCategoryName( category_name );
	            
	            map.put( product_id, entity );
	        } 
	    } catch (Exception e) {
	        MessageEntity msg = new MessageEntity("error", 8);
            msg.setUrl( "/work/work09/productList" );
            msg.setLinkTitle( "상품 목록" );
            throw new CommonException(msg);
	    } finally {
	        JdbcTemplate.close( rset );
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	    return map;
	}

}
