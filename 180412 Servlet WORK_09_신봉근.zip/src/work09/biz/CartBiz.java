package work09.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import work09.common.JdbcTemplate;
import work09.data.CartCollection;
import work09.entity.CartEntity;
import work09.entity.MessageEntity;
import work09.exception.CommonException;



public class CartBiz {
	
	public void productAddCart(CartEntity entity) throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    ResultSet rset = null;
	    
	    
	    try{
	        System.out.println( "cartbiz select 시작" );
	       String sql = "SELECT * "
	                  + "FROM CART "
	                  + "WHERE CART.PRODUCT_ID = ? ";
	       
            preStmt = con.prepareStatement( sql );
            preStmt.setString( 1, entity.getProductId() );
            rset = preStmt.executeQuery();
            
           
            System.out.println( "cartbiz select 끝" );
            if(rset.next()){
                System.out.println( "cartbiz UPDATE 진입" );
                sql = "UPDATE CART C SET C.CART_QUANTITY = (C.CART_QUANTITY + ?) WHERE C.PRODUCT_ID = ?";
                
//                preStmt = con.prepareStatement( sql );
                preStmt.setInt(  1, entity.getCartQuantity());
                preStmt.setString( 2, entity.getProductId() );
                int result = preStmt.executeUpdate();
                
                if(result == 0 ){
                    throw new Exception();
                }
                JdbcTemplate.commit( con );
                
                
            } else {
                System.out.println( "cartbiz, INSERT 쿼리 진입" );
                
                sql = "INSERT INTO CART (PRODUCT_ID, PURCHASER_ID, CART_QUANTITY)"
                    + "VALUES           (         ?,            ?,             ?) ";
                
                preStmt = con.prepareStatement( sql );
                preStmt.setString( 1, entity.getProductId() );
                preStmt.setString( 2,  entity.getPurchaserId() );
                preStmt.setInt( 3  , entity.getCartQuantity() );
                int result = preStmt.executeUpdate();
                
                if(result == 0 ){
                    throw new Exception();
                }
                JdbcTemplate.commit( con );
            }
	        
	    } catch (Exception e) {
	        System.out.println( "cartbiz,  catch 오류문" );
	        JdbcTemplate.rollback(con);
	        MessageEntity msg = new MessageEntity ("error", 2);
	        msg.setUrl( "/work/work09/product/productList" );
	        msg.setLinkTitle( "상품목록 보기" );
	        throw new CommonException(msg);
	        
	    } finally {
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );;
	    }
	}
	
	
	
	public ArrayList<CartEntity> cartList(String purchaserId) throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    ResultSet rset = null;
	    
	    CartEntity entity = null;
	    ArrayList<CartEntity> list = new ArrayList<CartEntity>();
	    
	    
	    
	    try {
	        String sql = "SELECT "                                            
	                   + "CA.PRODUCT_ID, "                                    // 1
	                   + "P.PRODUCT_NAME, "                                   // 2
	                   + "CATEGORY_LARGE||'-'||CATEGORY_MIDDLE CTGR, "        // 3
	                   + "P.PRODUCT_PRICE, "                                  // 4
	                   + "P.PRODUCT_COMPANY, "                                // 5
	                   + "CA.CART_QUANTITY, "                                 // 6
	                   + "(P.PRODUCT_PRICE * CA.CART_QUANTITY) TOTALPRICE, "  // 7
	                   + "P.PRODUCT_QUANTITY "                                // 8
	                   
	                   + "FROM "
	                   + "CART CA, PRODUCT P, CATEGORY C "
	                   
	                   + "WHERE "
	                   + "CA.PRODUCT_ID = P.PRODUCT_ID "
	                   + "AND P.CATEGORY_ID = C.CATEGORY_ID "
	                   + "AND CA.PURCHASER_ID = ? " ;
	        
	        
	        preStmt = con.prepareStatement(sql);
	        preStmt.setString(1, purchaserId);
	        
	        rset = preStmt.executeQuery();
	        
	        while(rset.next()){
	            entity = new CartEntity();
	            
	            String productId       = rset.getString( 1 );
	            String productName     = rset.getString( 2 );
	            String categoryName    = rset.getString( 3 );
	            int    productPrice    = rset.getInt   ( 4 );
	            String productCompany  = rset.getString( 5 );
	            int    cartQuantity    = rset.getInt   ( 6 );
	            int    totalPrice      = rset.getInt   ( 7 );
	            int    productQuantity = rset.getInt   ( 8 );	            
	            
	            entity = new CartEntity (
	                    productId, purchaserId, productName, productPrice, productCompany,
	                    cartQuantity, categoryName, productQuantity 
	                    );
	            list.add( entity );
	        } 
	    } catch (Exception e) {
	        MessageEntity msg = new MessageEntity("error", 0);
	        msg.setUrl( "/work/work09/loginForm.html" );
	        msg.setLinkTitle( "로그인" );
	        throw new CommonException(msg);
	        
	        
	    } finally {
	        JdbcTemplate.close( rset );
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	    
	    return list;
	    
	}
	

	
	
	
	public void productUpdateCart(CartEntity entity) throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    
	    try {
	        String sql = "UPDATE CART SET CART_QUANTITY = ? "
	                   + "WHERE PRODUCT_ID = ? AND PURCHASER_ID = ? ";
	        
	        preStmt = con.prepareStatement( sql );
	        preStmt.setInt( 1, entity.getCartQuantity());
	        preStmt.setString(2, entity.getProductId());
	        preStmt.setString( 3,  entity.getPurchaserId());
	        
	        int result = preStmt.executeUpdate();
	        
	        if(result == 0) {
	            throw new Exception();
	        }
	        
	        JdbcTemplate.commit(con);
	        
	    } catch (Exception e) {
	        JdbcTemplate.rollback(con);
	        MessageEntity msg = new MessageEntity("error", 10);
	        msg.setUrl( "/work/work09/purchaserUpdateForm" );
	        msg.setLinkTitle("회원수정");
	        throw new CommonException (msg);
	    }
	    
	    finally {
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	}
	
	
	
	
	
	public void productDeleteCart(CartEntity entity) throws CommonException {
		
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    
	    try {
	        String sql = "DELETE FROM CART WHERE PRODUCT_ID = ? AND PURCHASER_ID = ? ";
	        
	        preStmt = con.prepareStatement(sql);
	        preStmt.setString( 1, entity.getProductId() );
	        preStmt.setString( 2, entity.getPurchaserId() );
	        
	        int result = preStmt.executeUpdate();
	        
	        if(result == 0) {
	            throw new Exception();
	        } JdbcTemplate.commit( con );
	        
	        
	    } catch (Exception e) {
	        JdbcTemplate.rollback(con);
	        MessageEntity msg = new MessageEntity("error", 4);
	        msg.setUrl("/work/work09/productCartList");
	        msg.setLinkTitle( "장바구니 목록 보기" );
	        throw new CommonException (msg);
	        
	    } finally {
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	}
}
