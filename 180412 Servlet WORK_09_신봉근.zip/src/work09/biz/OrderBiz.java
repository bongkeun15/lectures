package work09.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;

import work09.common.JdbcTemplate;
import work09.data.OrderCollection;
import work09.entity.MessageEntity;
import work09.entity.OrderEntity;
import work09.exception.CommonException;

public class OrderBiz {

	public void productOrderBuy(String purchaserId, String pid, Integer amount) throws CommonException {
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    ResultSet rset = null;
	    int result = 0;
	    
	    try {
	       System.out.println( "1번 쿼리 진입" );
	       String sql = "SELECT PRODUCT_QUANTITY FROM PRODUCT WHERE PRODUCT_ID = ? ";
	       
	       preStmt = con.prepareStatement(sql);
	       preStmt.setString(1, pid);
	       rset = preStmt.executeQuery();
	       
	       int quantity = 0;
	       
	       
	       if(rset.next()){
	           quantity = rset.getInt( 1 );
	       } JdbcTemplate.close( preStmt );
	       
	       
	       System.out.println( "1번 쿼리 종료" );
	       if(quantity < amount) {
	           throw new Exception();
	       } JdbcTemplate.close( rset );
	       
	       
	       System.out.println( "2번 쿼리 진입" );
	       sql = "INSERT INTO PRODORDER (ORDER_ID, PRODUCT_ID, PURCHASER_ID, ORDER_QUANTITY, ORDER_CONFIRM,                  ORDER_DATE)  "
	           + "VALUES (                      ?,           ?,            ?,              ?,           'F', TO_DATE(SYSDATE, 'RR/MM/DD'))";
	       
	       Calendar cal = Calendar.getInstance();
	       String orderId = String.format( "%04d%02d%02d%05d",
	                        cal.get(Calendar.YEAR),
	                        cal.get(Calendar.MONTH) + 1,
	                        cal.get(Calendar.DAY_OF_MONTH),
	                        cal.get(Calendar.MILLISECOND)
	                        );
	       System.out.println( "2번 쿼리 중간1" );
	       preStmt = con.prepareStatement( sql );
	       
	       System.out.println( "↓↓↓↓↓↓↓↓들어가는 값↓↓↓↓↓↓↓↓" );
	       System.out.println(  orderId      );
	       System.out.println(  pid          );
	       System.out.println(  purchaserId  );
	       System.out.println(  amount       );
	       System.out.println( "↑↑↑↑↑↑↑↑들어가는 값↑↑↑↑↑↑↑↑" );

	       preStmt.setString( 1,  orderId     );
	       preStmt.setString( 2,  pid         );
	       preStmt.setString( 3,  purchaserId );
	       preStmt.setInt   ( 4,  amount      );
	       System.out.println( "2번 쿼리 중 2" );
	       
	       result = preStmt.executeUpdate();
	       System.out.println( "2번 쿼리 중 3" );
	       
	       JdbcTemplate.close( preStmt );
	       JdbcTemplate.close( rset );
	       
	       System.out.println( "2번 쿼리 종료" );
	       if(result == 0) {
	           throw new Exception(); 
	       } 
	       
	       System.out.println( "3번 쿼리 진입" );
	       sql = "UPDATE PRODUCT A SET A.PRODUCT_QUANTITY = (A.PRODUCT_QUANTITY - ?) WHERE A.PRODUCT_ID = ?  " ;
	       
	       preStmt = con.prepareStatement( sql );
	       preStmt.setInt( 1,  amount );
	       preStmt.setString( 2,  pid );
	       
	       result = preStmt.executeUpdate();
	       JdbcTemplate.close( preStmt );
	       
           System.out.println( "3번 쿼리 종료" );
	       if(result == 0){
	           throw new Exception();
	       }
	       
	       
           System.out.println( "4번 쿼리 진입" );
	       sql = "DELETE FROM CART WHERE CART.PRODUCT_ID  = ? AND CART.PURCHASER_ID = ? ";
	       
	       preStmt = con.prepareStatement( sql );
	       preStmt.setString( 1,  pid );
	       preStmt.setString( 2,  purchaserId );
	       
	       result = preStmt.executeUpdate();
	        System.out.println( "4번 쿼리 종료" );
	       if(result == 0) {
	           throw new Exception();
	       } JdbcTemplate.commit( con );
	       
	    } catch (Exception e){
	        System.out.println( "구매 catch 진입" );
	        MessageEntity msg = new MessageEntity("error", 6);
	        msg.setUrl( "/work/work09/productOrderList" );
	        msg.setLinkTitle( " 구매리스트 " );
	        throw new CommonException(msg);
	        
	    } finally {
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
 	}

	
	
	
	public boolean productOrderAllBuy(String purchaserId) {
		OrderCollection collection = OrderCollection.getInstance();
		return collection.productOrderAllBuy(purchaserId);
	}
	
	
	
	
	public ArrayList<OrderEntity> productOrderList(String purchaserId) throws CommonException {
	
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    ResultSet rset = null;
	    OrderEntity entity = null;
	    ArrayList<OrderEntity> list = new ArrayList<OrderEntity>();
	    
	    try{
	        String sql = "SELECT P.ORDER_ID, "                                      // 1 
	                   + "P.PRODUCT_ID, "                                           // 2
	                   + "PR.PRODUCT_NAME, "                                        // 3 
	                   + "CATEGORY_LARGE||'-'||CATEGORY_MIDDLE CTGR, "              // 4
	                   + "PR.PRODUCT_PRICE, "                                       // 5
	                   + "PR.PRODUCT_COMPANY, "                                     // 6
	                   + "P.ORDER_QUANTITY, "                                       // 7
	                   + "(P.ORDER_QUANTITY * PR.PRODUCT_PRICE) TOTAL, "            // 8
	                   + "TO_CHAR(P.ORDER_DATE, 'YYYY-MM-DD'), P.ORDER_CONFIRM "    // 9
	                   
	                   + "FROM PRODORDER P, PRODUCT PR, CATEGORY C "
	                   
	                   + "WHERE P.PRODUCT_ID = PR.PRODUCT_ID "
	                   + "AND PR.CATEGORY_ID = C.CATEGORY_ID "
	                   + "AND P.PURCHASER_ID = ? ";
	        
	        preStmt = con.prepareStatement( sql );
	        preStmt.setString( 1, purchaserId );
	        
	        rset = preStmt.executeQuery();
	        
	        while(rset.next()) {
	            String orderId        = rset.getString( 1 );
	            String productId      = rset.getString( 2 );
	            String productName    = rset.getString( 3 );
	            String categoryName   = rset.getString( 4 );
	            int    productPrice   = rset.getInt   ( 5 );
	            String productCompany = rset.getString( 6 );
	            int    orderQuantity  = rset.getInt   ( 7 );
	            String orderDate      = rset.getString( 8 );
	            String orderConfirm   = rset.getString( 9 );
	            
	            entity = new OrderEntity
	                    (
	                            orderId, productId, purchaserId, productName, productPrice, productCompany,
	                            orderQuantity, categoryName, orderDate, orderConfirm
	                    );
	            
	            entity.setCategoryName(categoryName);
	            list.add( entity );
	        }
	         
	    } catch (Exception e) {
	        MessageEntity msg = new MessageEntity("error", 11);
	        msg.setUrl( "/work/work09/productOrderList" );
	        msg.setLinkTitle( "구매 리스트" );
	        throw new CommonException(msg);
	        
	    } finally {
	        JdbcTemplate.close( rset );
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	    
	    return list;
	    }
	
	
	
	
	
	
	public void productBuyConfirm(OrderEntity entity) throws CommonException{
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    
	    try {
	        String sql = "UPDATE PRODORDER P SET P.ORDER_CONFIRM = 'T' "
	                   + "WHERE ORDER_ID = ? ";
	        
	        preStmt = con.prepareStatement(sql);
	        preStmt.setString( 1,  entity.getOrderId() );
	        
	        int result = preStmt.executeUpdate();
	        
	        if(result == 0){
	            throw new Exception();
	        }
	        JdbcTemplate.commit(con);
	    } catch (Exception e) {
	        JdbcTemplate.rollback( con );
	        MessageEntity msg = new MessageEntity("error", 10);
            msg.setUrl( "/work/work09/productOrderList" );
            msg.setLinkTitle( "구매 리스트" );
            throw new CommonException(msg);
	    } finally {
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	}
	
	
	
	public void productBuyCancel(OrderEntity entity) throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    
	    try {
	        String sql1 = "UPDATE PRODUCT P SET P.PRODUCT_QUANTITY = (P.PRODUCT_QUANTITY + ? ) "
	                    + "WHERE P.PRODUCT_ID = (SELECT SC.PRODUCT_ID FROM PRODORDER SC WHERE SC.ORDER_ID = ? ";
	        
	        String sql2 = "DELETE FROM PRODORDER A WHERE A.ORDER_ID = ? ";
	        
	        preStmt = con.prepareStatement( sql1 );
	        preStmt.setInt( 1, entity.getOrderQuantity() );
	        preStmt.setString( 2, entity.getOrderId() );
	        
	        int result = preStmt.executeUpdate();
	        
	        if(result == 0){
	            throw new Exception();
	        } preStmt = con.prepareStatement(sql2);
	        preStmt.setString( 1, entity.getOrderId() );
	        result = preStmt.executeUpdate();
	        
	        if(result == 0){
	            throw new Exception();
	        } 
	        JdbcTemplate.commit(con);
	      
	    } catch (Exception e) {
	        JdbcTemplate.rollback(con);
	        MessageEntity msg = new MessageEntity("error", 10);
            msg.setUrl( "/work/work09/productOrderList" );
            msg.setLinkTitle( "구매 리스트" );
            throw new CommonException(msg);
	    }
	}
}
