package work09.biz;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import work09.common.JdbcTemplate;
import work09.data.SellerCollection;
import work09.entity.MessageEntity;
import work09.entity.SellerEntity;
import work09.exception.CommonException;





public class SellerBiz {

	
	public void sellerAdd(SellerEntity entity) throws CommonException{
        Connection con = JdbcTemplate.getConnection();
        PreparedStatement preStmt = null;

        try {
            String sql = "INSERT INTO SELLERMEMBER "
                       + "(SELLER_ID, "     // 1
                       + "SELLER_PW, "      // 2
                       + "SELLER_NAME, "    // 3
                       + "SELLER_ADDR, "    // 4
                       + "SELLER_PHONE, "   // 5
                       + "SELLER_EMAIL, "   // 6
                       + "SELLER_REG_NUM, " // 7
                       + "SELLER_ACCOUNT) " // 8
                       + "VALUES(?,?,?,?,?, "
                       + "       ?,?,?     )";

            preStmt = con.prepareStatement( sql );

            preStmt.setString( 1, entity.getSellerId() );
            preStmt.setString( 2, entity.getSellerPw() );
            preStmt.setString( 3, entity.getSellerName() );
            preStmt.setString( 4, entity.getSellerAddr() );
            preStmt.setString( 5, entity.getSellerPhone() );
            preStmt.setString( 6, entity.getSellerEmail() );
            preStmt.setString( 7, entity.getSellerRegNum() );
            preStmt.setString( 8, entity.getSellerAccount() );

            int result = preStmt.executeUpdate();

            if ( result == 0 ) {
                throw new Exception();
            }
            JdbcTemplate.commit( con );
        } catch ( Exception e ) {
            JdbcTemplate.rollback( con );
            MessageEntity message = new MessageEntity( "error", 9 );
            message.setUrl( "/work/work09/purchaser/purchaserForm.html" );
            message.setLinkTitle( "회원 가입" );
            throw new CommonException( message );
        } finally {
            JdbcTemplate.close( preStmt );
            JdbcTemplate.close( con );
        }

    }

	// 로그인
	public SellerEntity login(String id, String pw) throws CommonException {
		
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    ResultSet rset = null;
	    
	    SellerEntity entity = null;
	    
	    try {
	        System.out.println( "seller login try 진입 " ); /////////////////////
	        
	        String sql = "SELECT * FROM SELLERMEMBER           "
	                   + "WHERE SELLER_ID = ? AND SELLER_PW = ?";
	        
	        System.out.println( "seller login try 중간 1 " ); /////////////////////
	        preStmt = con.prepareStatement(sql);
	        preStmt.setString( 1, id );
	        preStmt.setString( 2, pw );
	        
	        rset = preStmt.executeQuery();
	        
	        System.out.println( "seller login try 중간 2 " ); /////////////////////
	        
	        if(rset.next()){
	            String sellerId      = rset.getString( "seller_id" );
	            String sellerPw      = rset.getString( "seller_pw" );
	            String sellerName    = rset.getString( "seller_name" );
	            String sellerAddr    = rset.getString( "seller_addr" );
	            String sellerPhone   = rset.getString( "seller_phone" );
	            String sellerEmail   = rset.getString( "seller_email" );
	            String sellerRegnum  = rset.getString( "seller_reg_num" );
	            String sellerAccount = rset.getString( "seller_account" );
	            
	            entity = new SellerEntity (
	                    sellerId, sellerPw, sellerName, sellerAddr, sellerPhone, 
	                    sellerEmail, sellerRegnum, sellerAccount
	                    );
	            System.out.println( "seller login try 종료 " ); /////////////////////
	        }
	    } catch (Exception e){
	        MessageEntity message = new MessageEntity( "error", 0 );
            message.setUrl( "/work/work09/loginForm.html" );
            message.setLinkTitle( "로그인" );
            throw new CommonException( message );
	    } finally {
	        JdbcTemplate.close( rset );
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	    
	    return entity;
	}
	
	
	
	
	
	public SellerEntity sellerUpdateForm(String id) throws CommonException{
		
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    ResultSet rset = null;
	    
	    SellerEntity entity = null;
	    
	    try{
	        String sql = "SELECT "
	                   + "SELLER_ID, "            // 1
	                   + "SELLER_PW, "            // 2
	                   + "SELLER_NAME, "          // 3
	                   + "SELLER_ADDR, "          // 4
	                   + "SELLER_PHONE, "         // 5
	                   + "SELLER_EMAIL, "         // 6
	                   + "SELLER_REG_NUM, "       // 7
	                   + "SELLER_ACCOUNT "        // 8
	                   
	                   + "FROM "
	                   + "SELLERMEMBER WHERE SELLER_ID = ? ";
	                
	        preStmt = con.prepareStatement( sql );
	        preStmt.setString( 1,  id );
	        rset = preStmt.executeQuery();
	        
	        if(rset.next()){
                String sellerId      = rset.getString( "seller_id" );
                String sellerPw      = rset.getString( "seller_pw" );
                String sellerName    = rset.getString( "seller_name" );
                String sellerAddr    = rset.getString( "seller_addr" );
                String sellerPhone   = rset.getString( "seller_phone" );
                String sellerEmail   = rset.getString( "seller_email" );
                String sellerRegnum  = rset.getString( "seller_regNum" );
                String sellerAccount = rset.getString( "seller_account" );
                
                entity = new SellerEntity (
                        sellerId, sellerPw, sellerName, sellerAddr, sellerPhone, 
                        sellerEmail, sellerRegnum, sellerAccount);
	        }
	                
	    } catch(Exception e) {
	        MessageEntity message = new MessageEntity( "error", 10 );
            message.setUrl( "/work/work09/purchaserUpdateForm" );
            message.setLinkTitle( "회원수정" );
            throw new CommonException( message );
	    } finally {
	        JdbcTemplate.close( rset );
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	    return entity;
	}
	
	
	
	
	public void sellerUpdate(SellerEntity entity) throws CommonException{
		
	    Connection con = JdbcTemplate.getConnection();
	    PreparedStatement preStmt = null;
	    
	    try {
	        String sql = "UPDATE SELLERMEMBER SET "
	                   + "SELLER_PW = ?, "         // 1
	                   + "SELLER_NAME = ?, "       // 2
	                   + "SELLER_ADDR = ?, "       // 3
	                   + "SELLER_PHONE = ?, "      // 4
	                   + "SELLER_EMAIL = ?, "      // 5
	                   + "SELLER_REG_NUM = ?, "    // 6
	                   + "SELLER_ACCOUNT = ? "     // 7
	                   + "WHERE SELLER_ID = ? ";   // 8
	        
	        preStmt = con.prepareStatement( sql );
	        
	        preStmt.setString(1, entity.getSellerPw());
	        preStmt.setString(2, entity.getSellerName());
	        preStmt.setString(3, entity.getSellerAddr());
	        preStmt.setString(4, entity.getSellerPhone());
	        preStmt.setString(5, entity.getSellerEmail());
	        preStmt.setString(6, entity.getSellerRegNum());
	        preStmt.setString(7, entity.getSellerAccount());
	        preStmt.setString(8, entity.getSellerId());
	        
	        int result = preStmt.executeUpdate();
	        if(result == 0) {
	            throw new Exception();
	        }
	        JdbcTemplate.rollback( con );
	    } catch (Exception e) {
	        JdbcTemplate.rollback( con );
	        MessageEntity message = new MessageEntity( "error", 10 );
            message.setUrl( "/work/work09/purchaserUpdateForm" );
            message.setLinkTitle( "회원수정" );
            throw new CommonException( message );
	    } finally {
	        JdbcTemplate.close( preStmt );
	        JdbcTemplate.close( con );
	    }
	}
}
