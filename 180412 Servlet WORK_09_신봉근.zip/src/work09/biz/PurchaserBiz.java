package work09.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import work09.common.JdbcTemplate;
import work09.entity.MessageEntity;
import work09.entity.PurchaserEntity;
import work09.exception.CommonException;

public class PurchaserBiz {
	
	//회원가입
	public void purchaserAdd(PurchaserEntity entity) throws CommonException{

		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
	   try{
		
		   String sql = "INSERT INTO PURCHASERMEMBER"
		              + "(PURCHASER_ID, "
		              + "PURCHASER_PW, "
		              + "PURCHASER_NAME, "
		              + "PURCHASER_ADDR, "
		              + "PURCHASER_PHONE, "
		              + "PURCHASER_EMAIL ) "
					  + " VALUES ( ? , ? , ?, ?, ?, ? ) ";
		   
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, entity.getPurchaserId());
			pstmt.setString(2, entity.getPurchaserPw());
			pstmt.setString(3, entity.getPurchaserName());
			pstmt.setString(4, entity.getPurchaserAddr());
			pstmt.setString(5, entity.getPurchaserPhone());
			pstmt.setString(6, entity.getPurchaserEmail());
		 
			int result  = pstmt.executeUpdate();
			  if(result == 0) {
					throw new Exception();
				}
		JdbcTemplate.commit(con);
	   } catch (Exception e) {
		   JdbcTemplate.rollback(con);
		   MessageEntity message = 
					new MessageEntity("error", 9);
		   
			message.setUrl("/work/work09/purchaser/purchaserForm.html");
			message.setLinkTitle("회원 가입");
			throw new CommonException(message);
	   }finally{
		   JdbcTemplate.close(pstmt);
		   JdbcTemplate.close(con);
	   }
	}
	
	//로그인
	public PurchaserEntity login(String id, String pw)throws CommonException{

		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		PurchaserEntity entity = null;
		try{
	
			//return dao.login(con , id, pw);
			
			String sql = "SELECT * FROM PURCHASERMEMBER WHERE PURCHASER_ID = ? AND PURCHASER_PW = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			
			rs = pstmt.executeQuery();
			if(rs.next()){
				String purchaser_id    = rs.getString("purchaser_id"   );
				String purchaser_pw    = rs.getString("purchaser_pw"   );
				String purchaser_name  = rs.getString("purchaser_name" );
				String purchaser_addr  = rs.getString("purchaser_addr" );
				String purchaser_phone = rs.getString("purchaser_phone");
				String purchaser_email = rs.getString("purchaser_email");
				int purchaser_score = rs.getInt("purchaser_score");
				entity = new PurchaserEntity(purchaser_id, purchaser_pw, purchaser_name, purchaser_addr, purchaser_phone,
				                             purchaser_email, purchaser_score );
			}
			
		} catch (Exception e) {
			MessageEntity message = new MessageEntity("error",0);
			message.setUrl("/work/work09/loginForm.html");
			message.setLinkTitle("로그인");
			throw new CommonException(message);
		   }finally{
			   JdbcTemplate.close(rs);
			   JdbcTemplate.close(pstmt);
			   JdbcTemplate.close(con);
		   }
		
		return entity;
	}

	 //회원수정화면보기
    public PurchaserEntity purchaserUpdateForm(String id)throws CommonException{
    	Connection con = JdbcTemplate.getConnection();
    	PreparedStatement pstmt = null;
		ResultSet rs = null;
		PurchaserEntity entity = null;
 	   try{
 		
 		  String sql = "SELECT PURCHASER_ID, "
 		             + "PURCHASER_PW, "
 		             + "PURCHASER_NAME, "
 		             + "PURCHASER_ADDR, "
 		             + "PURCHASER_PHONE, "
 		             + "PURCHASER_EMAIL, "
 		             + "P.PURCHASER_SCORE, "
 		             + "GRADE_ID "
 		          
					 + "FROM PURCHASERMEMBER P, "
					 + "GRADE G "
					
					 + "WHERE P.PURCHASER_SCORE BETWEEN G.GRADE_MIN AND G.GRADE_MAX "
					 + "AND PURCHASER_ID = ?";
 		  
 		  
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				String purchaser_id     = rs.getString("purchaser_id"   );
				String purchaser_pw     = rs.getString("purchaser_pw"   );
				String purchaser_name   = rs.getString("purchaser_name" );
				String purchaser_addr   = rs.getString("purchaser_addr" );
				String purchaser_phone  = rs.getString("purchaser_phone");
				String purchaser_email  = rs.getString("purchaser_email");
				int purchaser_score     = rs.getInt   ("purchaser_score");
				String purchaser_grade  = rs.getString("grade_id");
				entity = new PurchaserEntity(purchaser_id, purchaser_pw, purchaser_name, purchaser_addr, purchaser_phone,
				                            purchaser_email, purchaser_score);
				entity.setPurchaserGrade(purchaser_grade);
			}
 	  } catch (Exception e) {
 		     MessageEntity message = new MessageEntity("error", 10);
			message.setUrl("/work/work09/purchaserUpdateForm");
			message.setLinkTitle("회원수정");
			throw new CommonException(message);
 	   }finally{
 		   
 		  JdbcTemplate.close(rs);
		  JdbcTemplate.close(pstmt);
 		  JdbcTemplate.close(con);
 	   }
    	return entity;
    }
    
    //회원수정
    public void purchaserUpdate(PurchaserEntity entity)throws CommonException{
 
    	Connection con = JdbcTemplate.getConnection();
    	PreparedStatement pstmt = null;
    	 try{
    		 
    		 String sql = "UPDATE PURCHASERMEMBER SET "
    		            + "PURCHASER_PW = ?,"
    		            + "PURCHASER_NAME=?, "
    		            + "PURCHASER_ADDR = ?, "
    		            + "PURCHASER_PHONE = ?, "
    		            + "PURCHASER_EMAIL = ? "
    		         
 					   + " WHERE PURCHASER_ID = ? ";
    		 
 			pstmt = con.prepareStatement(sql);
 		
 			pstmt.setString(1, entity.getPurchaserPw());
 			pstmt.setString(2, entity.getPurchaserName());
 			pstmt.setString(3, entity.getPurchaserAddr());
 			pstmt.setString(4, entity.getPurchaserPhone());
 			pstmt.setString(5, entity.getPurchaserEmail());
 			pstmt.setString(6, entity.getPurchaserId());
 			
 			
 			int result  = pstmt.executeUpdate();
 			  if(result == 0) {
 					throw new Exception();
 				}
    	       JdbcTemplate.commit(con);
    	 } catch (Exception e) {
    		 JdbcTemplate.rollback(con);
    		 MessageEntity message = 
 					new MessageEntity("error",10);
    		 message.setUrl("/work/work09/purchaserUpdateForm");
 			message.setLinkTitle("회원수정");
 			throw new CommonException(message);
    	   }finally{
    		   
    		   JdbcTemplate.close(pstmt);
    		   JdbcTemplate.close(con);
    	   }
    	 
    	
    }
}
