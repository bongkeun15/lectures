package work09.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.ProductBiz;
import work09.entity.ProductEntity;
import work09.entity.SellerEntity;
import work09.exception.CommonException;


/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work09.ProductList", urlPatterns = { "/work09/productList" })
public class ProductListServlet extends HttpServlet {
	

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

request.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher( "/work09/message.jsp" );
		String member = (String)session.getAttribute("member");
		String sellerId = null;
	
		ProductBiz biz = new ProductBiz();
		HashMap<String, ProductEntity> list = null;
		System.out.println("member>>> " + member);
		
		if("purchaser".equals(member)){

			try{
			    System.out.println( "member ????????????? " + member );
			    System.out.println( "biz ????????????? " + biz );
			    
			    list = biz.getProductList();
			    
			    System.out.println( "list ????????????? " + list );
			    
			    request.setAttribute( "productList", list );
			    
			    rd = request.getRequestDispatcher("/work09/product/productList.jsp");
			    
			} catch (CommonException e) {
			    request.setAttribute( "message", e.getMessageEntity() );
			}
		    
		}else{
			 SellerEntity entity = (SellerEntity)session.getAttribute("sellerLogin");
			 sellerId = entity.getSellerId();
	
			try {
			    list = biz.getProductListById( sellerId );
			    request.setAttribute( "productList", list );
			    rd = request.getRequestDispatcher( "/work09/product/productList.jsp" );
			    
			} catch (CommonException e){
			    request.setAttribute( "message", e.getMessageEntity() );
			}
			 
		}
		rd.forward( request, response );
	}
}
