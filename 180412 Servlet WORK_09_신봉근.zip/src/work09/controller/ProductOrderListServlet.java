package work09.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.OrderBiz;
import work09.entity.MessageEntity;
import work09.entity.OrderEntity;
import work09.entity.PurchaserEntity;
import work09.exception.CommonException;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name="work09.ProductOrderList", urlPatterns="/work09/productOrderList")
public class ProductOrderListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		
		HttpSession session = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher( "/work09/message.jsp" );
		
		System.out.println( "pols 2" );
		if (session.getAttribute("purchaserLogin") != null) {
			String purchaserId=((PurchaserEntity)session.getAttribute("purchaserLogin")).getPurchaserId();
			OrderBiz biz=new OrderBiz();
			ArrayList<OrderEntity> orders = null;
			System.out.println( "pols 1" );
			
			try {
			    System.out.println( "pols 2" );
			    orders = biz.productOrderList( purchaserId );
			    request.setAttribute( "orderList", orders );
			    rd = request.getRequestDispatcher( "/work09/product/productOrderList.jsp" );
			    
			} catch (CommonException e) {
			    System.out.println( "pols 3" );
			    request.setAttribute( "message", e.getMessageEntity() );
			}
			rd.forward( request, response );
					
		} else {
		    System.out.println( "pols 4" );
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			
			request.setAttribute( "message", message );
			rd.forward( request, response );
		}
	}
}
