package work09.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.CartBiz;
import work09.entity.CartEntity;
import work09.entity.MessageEntity;
import work09.entity.PurchaserEntity;
import work09.exception.CommonException;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name="work09.ProductCartUpdate", urlPatterns="/work09/productCartUpdate")
public class ProductCartUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {	
		String productId = request.getParameter("productId");
		Integer cartQuantity = Integer.parseInt(request.getParameter("cartQuantity"));

		HttpSession session = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher( "/work09/message.jsp" );
		
			String purchaserId=((PurchaserEntity)session.getAttribute("purchaserLogin")).getPurchaserId();		
					
			
			
			CartBiz biz = new CartBiz();
			CartEntity entity = new CartEntity();
			entity.setPurchaserId(purchaserId);
			entity.setProductId(productId);
			entity.setCartQuantity(cartQuantity);
		
			
			try{
			    biz.productUpdateCart( entity );
			    MessageEntity msg = new MessageEntity("success", 3);
			    msg.setUrl( "productCartList" );
			    msg.setLinkTitle( "장바구니 보기" );
			    request.setAttribute( "message", msg );
			} catch (CommonException e){
			    request.setAttribute( "message", e.getMessageEntity() );
			}
			
			rd.forward(request, response);
	}

}
