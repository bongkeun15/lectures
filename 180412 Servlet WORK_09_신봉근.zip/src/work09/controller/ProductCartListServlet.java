package work09.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work09.biz.CartBiz;
import work09.entity.CartEntity;
import work09.entity.PurchaserEntity;
import work09.exception.CommonException;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name = "work09.ProductCartList", urlPatterns = "/work09/productCartList")
public class ProductCartListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
	        HttpServletResponse response) throws ServletException, IOException {	
	    
		    HttpSession session = request.getSession();
		    RequestDispatcher rd = request.getRequestDispatcher( "/work09/message.jsp" );

		    
			String purchaserId = ((PurchaserEntity)session.getAttribute("purchaserLogin")).getPurchaserId();			
		
			CartBiz biz = new CartBiz();
			
			ArrayList<CartEntity> cart = null;
			
			System.out.println( "ProductCartListServlet try 직전" );
			
			try {
			    cart = biz.cartList( purchaserId );
			    request.setAttribute( "cartList", cart );
			    rd = request.getRequestDispatcher( "/work09/product/productCartList.jsp" );
			    
			    System.out.println( "ProductCartListServlet try 끝" );
			    
			} catch (CommonException e) {
			    System.out.println( "ProductCartListServlet catch" );
			    request.setAttribute( "message", e.getMessageEntity() );
			}
			
			rd.forward( request, response );
	}
}
