package work09.entity;

public class CartEntity {

	private String productId;			//상품아이디
	private String purchaserId;   			//구매자 아이디
	private String productName;		//상품명
	private int productPrice;			//가격
	private String productCompany;		//제조사
	private int cartQuantity;			//수량
	private String categoryName;      //카테고리 아이디 예> VCC01_100에 해당하는 가전-영상
	private int productQuantity; 		//재고수량
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getPurchaserId() {
		return purchaserId;
	}
	public void setPurchaserId(String purchaserId) {
		this.purchaserId = purchaserId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductCompany() {
		return productCompany;
	}
	public void setProductCompany(String productCompany) {
		this.productCompany = productCompany;
	}
	public int getCartQuantity() {
		return cartQuantity;
	}
	public void setCartQuantity(int cartQuantity) {
		this.cartQuantity = cartQuantity;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public CartEntity(String productId, String purchaserId, String productName,
			int productPrice, String productCompany, int cartQuantity,
			String categoryName, int productQuantity) {
		super();
		this.productId = productId;
		this.purchaserId = purchaserId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCompany = productCompany;
		this.cartQuantity = cartQuantity;
		this.categoryName = categoryName;
		this.productQuantity = productQuantity;
	}
	public CartEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
    
	
}
