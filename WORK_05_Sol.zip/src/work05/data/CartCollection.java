package work05.data;

import java.util.ArrayList;
import java.util.HashMap;

import work05.entity.CartEntity;
import work05.entity.ProductEntity;
import work05.entity.PurchaserEntity;

public class CartCollection {
	private static CartCollection instance;
	private ArrayList<CartEntity> cartList;

	private CartCollection() {
		cartList = new ArrayList<CartEntity>();
		cartList.add(new CartEntity("cns1419918190666", 
				"hong",
				"멀티미디어 슬림PC", 
				2200000, 
				"LG전자", 
				1, 
				"컴퓨터-데스크탑"));

	}

	public static CartCollection getInstance() {
		if (instance == null) {
			instance = new CartCollection();
		}
		return instance;
	}

	// 카트 목록보기
	public ArrayList<CartEntity> cartList(String purchaserId) {

		ArrayList<CartEntity> cList = new ArrayList<CartEntity>();

		for (CartEntity member : cartList) {
			if (member.getPurchaserId().trim().equals(purchaserId.trim())) {
				cList.add(member);
			}
		}
		return cList;

	}

	// 회원 중복 검사
	private boolean isExistCart(CartEntity entity) {

		for (CartEntity member : cartList) {
			if (member.getPurchaserId().equals(entity.getPurchaserId())
					&& member.getProductId().equals(entity.getProductId())) {
				return true;
			}
		}
		return false;
	}

	public boolean productAddCart(CartEntity entity) {
		boolean result = false;
		ProductEntity product = ProductCollection.getInstance()
				.getProductList().get(entity.getProductId());
		entity.setCategoryName(product.getCategoryName());
		entity.setProductCompany(product.getProductCompany());
		entity.setProductName(product.getProductName());
		entity.setProductPrice(product.getProductPrice());
		
		//카트에 존재하지 않으면 새로 추가
		if( ! isExistCart(entity)){
			cartList.add(entity);
			result = true;
		}else{
			for (int i = 0; i < cartList.size(); i++) {
				CartEntity member = cartList.get(i);
				if (member.getPurchaserId().equals(entity.getPurchaserId())
						&& member.getProductId().equals(entity.getProductId())) {
					entity.setCartQuantity(member.getCartQuantity()+ entity.getCartQuantity());
					cartList.set(i, entity);
					result = true;
				}
			}
			
		}
		return result;
	}

	public boolean productUpdateCart(CartEntity entity) {
		for (int i = 0; i < cartList.size(); i++) {
			CartEntity member = cartList.get(i);
			if (member.getPurchaserId().equals(entity.getPurchaserId())
					&& member.getProductId().equals(entity.getProductId())) {
				entity.setCategoryName(member.getCategoryName());
				entity.setProductCompany(member.getProductCompany());
				entity.setProductName(member.getProductName());
				entity.setProductPrice(member.getProductPrice());
				cartList.set(i, entity);
				return true;
			}
		}
		return false;
	}

	public boolean productDeleteCart(CartEntity entity) {
		for (int i = 0; i < cartList.size(); i++) {
			CartEntity member = cartList.get(i);
			System.out.println("member.getPurchaserId() > " + member.getPurchaserId());
			System.out.println("entity.getPurchaserId() > "  +entity.getPurchaserId());
			System.out.println("member.getProductId() > " + member.getProductId());
			System.out.println("entity.getProductId() > " + entity.getProductId());
			if (member.getPurchaserId().equals(entity.getPurchaserId())
					&& member.getProductId().equals(entity.getProductId())) {
				System.out.println("삭제" + i);
				cartList.remove(i);
				return true;
			}
		}
		return false;
	}
}
