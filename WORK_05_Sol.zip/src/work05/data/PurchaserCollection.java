package work05.data;

import java.util.HashMap;

import work05.entity.PurchaserEntity;


public class PurchaserCollection {
	
	private static PurchaserCollection instance;
	private HashMap<String, PurchaserEntity> purchasers;

	public HashMap<String, PurchaserEntity> getPurchasers() {
		return purchasers;
	}

	private PurchaserCollection() {
		purchasers = new HashMap<String, PurchaserEntity>();
		
		purchasers.put("hong", new PurchaserEntity("hong", "1234", "홍기동",
				"인천광역시 남구 주안동 19-28", "010-2288-9080", "hongs@gmail.com"));
		purchasers.put("man", new PurchaserEntity("man", "1111", "김엘지", 
				"서울특별시 마포구 상암동 019", "010-1111-11111", "lgkim@gmail.com"));
		purchasers.put("kims", new PurchaserEntity("kims", "1234", "김사람",
				"경기도 파주시 ", "010-334-9988", "kims@lgcns.com"));
		
	}

	public static PurchaserCollection getInstance() {
		if (instance == null) {
			instance = new PurchaserCollection();
		}
		return instance; 
	}

	// 구매자 회원 등록
	public  boolean  purchaserAdd(PurchaserEntity entity){
	
		if(! isExistPurchaser(entity)){
			purchasers.put(entity.getPurchaserId(), entity);
			return true;
		}
		return false;
	}
	
	//회원 중복 검사
	private boolean isExistPurchaser(PurchaserEntity entity){

		for(PurchaserEntity member : purchasers.values()){
			if(member.getPurchaserId().equals(entity.getPurchaserId())){
				return true;
			}
		}
		
		return false;
	}
	
	//로그인
	public PurchaserEntity login(String purchaserId, String pwd) {
		for(PurchaserEntity member : purchasers.values()){
			if(member.getPurchaserId().equals(purchaserId) && member.getPurchaserPw().equals(pwd)){
				return member;
			}
		}
		return null;
	}
	
	//회원 수정폼
	public PurchaserEntity purchaserUpdateForm(String id){
		
		for(PurchaserEntity member : purchasers.values()){
			if(member.getPurchaserId().equals(id)){
				return member;
			}
		}
		return null;
	}
	
	//회원수정
		public boolean purchaserUpdate(PurchaserEntity entity){
			
			for(PurchaserEntity member : purchasers.values()){
				if(member.getPurchaserId().equals(entity.getPurchaserId())){
					purchasers.put(entity.getPurchaserId(), entity);
					return true;
				}
			}
			return false;
		}
		
	
}
