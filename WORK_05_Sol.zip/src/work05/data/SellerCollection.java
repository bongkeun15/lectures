package work05.data;

import java.util.HashMap;
import java.util.Set;

import work05.entity.SellerEntity;


public class SellerCollection {
	
	private static SellerCollection instance;
	private HashMap<String, SellerEntity> sellers;

	public HashMap<String, SellerEntity> getSellers() {
		return sellers;
	}

	private SellerCollection() {
		sellers = new HashMap<String, SellerEntity>();	
		
		sellers.put("cns", new SellerEntity("cns", "1111", "판매왕", "서울시", 
				"010-1111-2222", "cns@lgcns.com", "123-45-67890", "987654321"));
		sellers.put("dapanda",new SellerEntity("dapanda", "1111", "다판다", "경기도", 
					"010-3333-4444", "dapanda@gmail.com", "999-12-12345", "123456789"));
		
	}

	public static SellerCollection getInstance() {
		if (instance == null) {
			instance = new SellerCollection();
		}
		return instance; 
	}
	// 구매자 회원 등록
		public  boolean  sellerAdd(SellerEntity entity){
		
			if(! isExistSeller(entity)){
				sellers.put(entity.getSellerId(), entity);
				return true;
			}
			return false;
		}
		
		//회원 중복 검사
		private boolean isExistSeller(SellerEntity entity){
			
			for(int i = 0 ; i < sellers.size(); i++ ){
				
				Set<String> keys = sellers.keySet();
			    for (String key : keys) {
			    	SellerEntity xxx = sellers.get(key);
					if(entity.getSellerId().equals(xxx.getSellerId())){
						return true;
					}
				}
				
			}
			return false;
		}
		
	//로그인
	public SellerEntity login(String purchaserId, String pwd) {
		for(SellerEntity member : sellers.values()){
			if(member.getSellerId().equals(purchaserId) && member.getSellerPw().equals(pwd)){
				return member;
			}
		}
		return null;
	}
	
	//회원수정폼
		public SellerEntity sellerUpdateForm(String id){
			
			for(SellerEntity member : sellers.values()){
				if(member.getSellerId().equals(id)){
					return member;
				}
			}
			return null;
		}
		
		//회원수정
			public boolean sellerUpdate(SellerEntity entity){
				
				for(SellerEntity member : sellers.values()){
					if(member.getSellerId().equals(entity.getSellerId())){
						sellers.put(entity.getSellerId(), entity);
						return true;
					}
				}
				return false;
			}
}
