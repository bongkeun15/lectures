package work05.entity;

public class ProductEntity {

	private String productId; // 상품아이디
	private String categoryId; // 카테고리 아이디 예> CNS01_100
	private String productName; // 상품명
	private int productPrice; // 가격
	private String productCompany; // 제조사
	private int productQuantity; // 재고수량
	private String productInfo; // 상품소개
	private String productDate; // 상품등록일
	private String sellerId; // 판매자 아이
	private String categoryName; // 카테고리 아이디 예> CNS01_100에 해당하는 가전-영상

	public ProductEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductEntity(String productId, String categoryId,
			String productName, int productPrice, String productCompany,
			int productQuantity, String productInfo, String productDate,
			String sellerId) {
		super();
		this.productId = productId;
		this.categoryId = categoryId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCompany = productCompany;
		this.productQuantity = productQuantity;
		this.productInfo = productInfo;
		this.productDate = productDate;
		this.sellerId = sellerId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCompany() {
		return productCompany;
	}

	public void setProductCompany(String productCompany) {
		this.productCompany = productCompany;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductInfo() {
		return productInfo;
	}

	public void setProductInfo(String productInfo) {
		this.productInfo = productInfo;
	}

	public String getProductDate() {
		return productDate;
	}

	public void setProductDate(String productDate) {
		this.productDate = productDate;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

}
