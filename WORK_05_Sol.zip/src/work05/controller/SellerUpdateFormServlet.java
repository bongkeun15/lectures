package work05.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work05.data.SellerCollection;
import work05.entity.MessageEntity;
import work05.entity.SellerEntity;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work05.SellerUpdateForm", urlPatterns = { "/work05/sellerUpdateForm" })
public class SellerUpdateFormServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			SellerEntity entity = (SellerEntity) session
					.getAttribute("sellerLogin");
			String id = entity.getSellerId();

			SellerCollection data = SellerCollection.getInstance();

			entity = data.sellerUpdateForm(id);

			session.setAttribute("sellerUpdateEntity", entity);
			response.sendRedirect("/work/work05/seller/sellerUpdateForm.jsp");
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			session.setAttribute("message", message);
			response.sendRedirect("message.jsp");
		}
	}

}
