package work05.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work05.data.ProductCollection;
import work05.entity.MessageEntity;
import work05.entity.ProductEntity;
import work05.entity.SellerEntity;
import work05.util.ValidationUtil;

@WebServlet(name = "work05.ProductAdd", urlPatterns = { "/work05/productAdd" })
public class ProductAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			String categoryId = request.getParameter("categoryId");
			String productName = request.getParameter("productName");
			String productPrice = request.getParameter("productPrice");
			String productCompany = request.getParameter("productCompany");
			String productQuantity = request.getParameter("productQuantity");
			String productInfo = request.getParameter("productInfo");

			if (!ValidationUtil.checkRequired(categoryId)) {
				MessageEntity message = new MessageEntity("validation", 9);
				message.setUrl("/work/work05/product/productAddForm.html");
				message.setLinkTitle("상품 등록");
				session.setAttribute("message", message);

			} else if (!ValidationUtil.checkRequired(productName)) {

				MessageEntity message = new MessageEntity("validation", 10);
				message.setUrl("/work/work05/product/productAddForm.html");
				message.setLinkTitle("상품 등록");
				session.setAttribute("message", message);

			} else if (!ValidationUtil.checkRequired(productPrice)
					|| !ValidationUtil.checkDigit(productPrice)) {

				MessageEntity message = new MessageEntity("validation", 11);
				message.setUrl("/work/work05/product/productAddForm.html");
				message.setLinkTitle("상품 등록");
				session.setAttribute("message", message);

			} else if (!ValidationUtil.checkRequired(productCompany)) {

				MessageEntity message = new MessageEntity("validation", 12);
				message.setUrl("/work/work05/product/productAddForm.html");
				message.setLinkTitle("상품 등록");
				session.setAttribute("message", message);

			} else if (!ValidationUtil.checkRequired(productQuantity)
					|| !ValidationUtil.checkDigit(productQuantity)
					|| !ValidationUtil.lessLength(productQuantity, 4)) {

				MessageEntity message = new MessageEntity("validation", 13);
				message.setUrl("/work/work05/product/productAddForm.html");
				message.setLinkTitle("상품 등록");
				session.setAttribute("message", message);

			} else if (!ValidationUtil.checkRequired(productInfo)) {

				MessageEntity message = new MessageEntity("validation", 14);
				message.setUrl("/work/work05/product/productAddForm.html");
				message.setLinkTitle("상품 등록");
				session.setAttribute("message", message);

			} else {

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일");
				String productDate = sdf.format(new Date());

				HttpSession sess = request.getSession();

				SellerEntity xxx = (SellerEntity) sess
						.getAttribute("sellerLogin");
				String sellerId = xxx.getSellerId();

				// 상품아이디 = 판매자아이디+시간
				String product_id = sellerId + System.currentTimeMillis();

				ProductEntity entity = new ProductEntity(product_id,
						categoryId, productName,
						Integer.parseInt(productPrice), productCompany,
						Integer.parseInt(productQuantity), productInfo,
						productDate, sellerId);

				// 상품 저장
				ProductCollection productCollection = ProductCollection
						.getInstance();
				boolean result = productCollection.productAdd(entity);
				if (result) {

					MessageEntity message = new MessageEntity("success", 6);
					message.setUrl("/work/work05/productList");
					message.setLinkTitle("상품 목록");
					session.setAttribute("message", message);

				} else {

					// 성공
					MessageEntity message = new MessageEntity("error", 7);
					message.setUrl("/work/work05/productList");
					message.setLinkTitle("상품 목록");
					session.setAttribute("message", message);
					session.setAttribute("message", message);

				}

			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			session.setAttribute("message", message);

		}
		response.sendRedirect("message.jsp");

	}

}
