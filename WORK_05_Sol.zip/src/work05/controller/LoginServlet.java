package work05.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work05.data.PurchaserCollection;
import work05.data.SellerCollection;
import work05.entity.MessageEntity;
import work05.entity.PurchaserEntity;
import work05.entity.SellerEntity;

/**
 * Servlet implementation class ConsumerServlet
 */

@WebServlet(name = "work05.Login", urlPatterns = { "/work05/login" })
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		request.getSession().invalidate();
		HttpSession session = request.getSession();
	

			String id = request.getParameter("id");
			String pw = request.getParameter("pw");
			String member = request.getParameter("member");

			

			if ("purchaser".equals(member)) {

				PurchaserCollection data = PurchaserCollection.getInstance();

				PurchaserEntity entity;

				entity = data.login(id, pw);

				if (entity != null) {
					session.setAttribute("purchaserLogin", entity);
					session.setAttribute("member", "purchaser");

					response.sendRedirect("purchaser/purchaserLoginSuccess.jsp");

				} else {
					MessageEntity message = new MessageEntity("error", 0);
					message.setUrl("/work/work05/loginForm.html");
					message.setLinkTitle("로그인");

					session.setAttribute("message", message);
					response.sendRedirect("/work//work05/message.jsp");

				}

			} else {

				SellerCollection data = SellerCollection.getInstance();

				SellerEntity entity;

				entity = data.login(id, pw);
				if (entity != null) {
					session.setAttribute("sellerLogin", entity);
					session.setAttribute("member", "seller");

					response.sendRedirect("seller/sellerLoginSuccess.jsp");

				} else {
					MessageEntity message = new MessageEntity("error", 0);
					message.setUrl("/work/work05/loginForm.html");
					message.setLinkTitle("로그인");
					session.setAttribute("message", message);
					response.sendRedirect("/work//work05/message.jsp");
				}

			}
		
	}
}// end class
