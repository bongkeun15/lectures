package work05.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work05.data.CartCollection;
import work05.entity.CartEntity;
import work05.entity.MessageEntity;
import work05.entity.PurchaserEntity;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name = "work05.ProductCartDelete", urlPatterns = "/work05/productCartDelete")
public class ProductCartDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			String productId = request.getParameter("productId");

			String purchaserId = ((PurchaserEntity) session
					.getAttribute("purchaserLogin")).getPurchaserId();
			CartCollection cartCollection = CartCollection.getInstance();
			CartEntity entity = new CartEntity();
			entity.setPurchaserId(purchaserId);
			entity.setProductId(productId);

			boolean result = cartCollection.productDeleteCart(entity);

			if (result) {
				MessageEntity message = new MessageEntity("success", 4);
				message.setUrl("productCartList");
				message.setLinkTitle("장바구니 보기");
				session.setAttribute("message", message);
				response.sendRedirect("message.jsp");
			} else {
				MessageEntity message = new MessageEntity("error", 4);
				message.setUrl("productCartList");
				message.setLinkTitle("장바구니 보기");
				session.setAttribute("message", message);
				response.sendRedirect("message.jsp");
			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			session.setAttribute("message", message);
			response.sendRedirect("message.jsp");
		}

	}
}
