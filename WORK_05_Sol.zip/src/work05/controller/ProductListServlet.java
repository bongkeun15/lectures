package work05.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work05.data.ProductCollection;
import work05.entity.MessageEntity;
import work05.entity.ProductEntity;
import work05.entity.SellerEntity;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work05.ProductList", urlPatterns = { "/work05/productList" })
public class ProductListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
			String member = (String) session.getAttribute("member");
			String sellerId = null;
			ProductCollection productCollection = ProductCollection
					.getInstance();
			HashMap<String, ProductEntity> list = null;

			if ("purchaser".equals(member)) {

				list = productCollection.getProductList();
				session.setAttribute("productList", list);
				response.sendRedirect("/work/work05/product/productList.jsp");

			} else {
				SellerEntity entity = (SellerEntity) session
						.getAttribute("sellerLogin");
				sellerId = entity.getSellerId();

				list = productCollection.getProductListById(sellerId);
				session.setAttribute("productList", list);
				response.sendRedirect("/work/work05/product/productList.jsp");

			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			session.setAttribute("message", message);
			response.sendRedirect("message.jsp");
		}
	}

}
