package work10.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work10.biz.PurchaserBiz;
import work10.entity.MessageEntity;
import work10.entity.PurchaserEntity;
import work10.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work10.PurchaserUpdateForm", urlPatterns = { "/work10/purchaserUpdateForm" })
public class PurchaserUpdateFormServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			PurchaserEntity entity = (PurchaserEntity) session
					.getAttribute("purchaserLogin");

			String purchaserId = entity.getPurchaserId();

			PurchaserBiz biz = new PurchaserBiz();

			try {
				entity = biz.purchaserUpdateForm(purchaserId);
				session.setAttribute("purchaserUpdateEntity", entity);
				response.sendRedirect("/work/work10/purchaser/purchaserUpdateForm.jsp");
			} catch (CommonException e) {
				session.setAttribute("message", e.getMessageEntity());
				response.sendRedirect("message.jsp");

			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			session.setAttribute("message", message);
			response.sendRedirect("message.jsp");
		}
	}

}
