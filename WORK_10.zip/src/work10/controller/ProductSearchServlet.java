/*
 *  1. 상품 검색 서블릿
 *   - 로그인이 성공후에 사용 가능하다.
 */

package work10.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class ProductSearchServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		
		/*
		 *  1. productList.jsp의 파라미터 값을 얻는다.
		 *  
		 *  2. 구매자가 상품 검색한 경우에는 ProductBiz의 productPurchaserSearch()메소드를 요청하고
		 *     판매자가 상품 검색한 경우에는 ProductBiz의 productSellerSearch() 메소드를 요청한다.
		 *     
		 *  3. 실행결과를 저장하고 productList.jsp로 RequestDispatcher 처리하여 상품검색 목록을 
		 *     출력한다.
		 *   
		 *  4. 로그인이 되지 않은 상황에서 요청이 된 경우에는 다음 방법으로 메시지를 출력한다.
		 *   
		 *     MessageEntity message = new MessageEntity("message", 0);
			   message.setUrl("loginForm.html");
			   message.setLinkTitle("로그인");
			   session.setAttribute("message", message);
			   response.sendRedirect("message.jsp");
		 *   
		 */


	}

}
