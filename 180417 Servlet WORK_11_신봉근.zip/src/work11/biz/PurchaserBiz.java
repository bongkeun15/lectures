package work11.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import work11.common.JdbcTemplate;
import work11.dao.PurchaserDAO;
import work11.entity.MessageEntity;
import work11.entity.PurchaserEntity;
import work11.exception.CommonException;


public class PurchaserBiz {
	
	//회원가입
	public void purchaserAdd(PurchaserEntity entity) throws CommonException{

	    Connection con = JdbcTemplate.getConnection();
	    PurchaserDAO dao = new PurchaserDAO();
        dao.purchaserAdd( con, entity );
	    
//		Connection con = JdbcTemplate.getConnection();
//		PreparedStatement pstmt = null;
//	   try{
//		
//		   String sql = "insert into purchaserMember ( purchaser_id,purchaser_pw,purchaser_name,purchaser_addr,purchaser_phone,purchaser_email ) "
//					+ " values ( ? , ? , ?, ?, ?, ? ) ";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, entity.getPurchaserId());
//			pstmt.setString(2, entity.getPurchaserPw());
//			pstmt.setString(3, entity.getPurchaserName());
//			pstmt.setString(4, entity.getPurchaserAddr());
//			pstmt.setString(5, entity.getPurchaserPhone());
//			pstmt.setString(6, entity.getPurchaserEmail());
//		 
//			int result  = pstmt.executeUpdate();
//			  if(result == 0) {
//					throw new Exception();
//				}
//		JdbcTemplate.commit(con);
//	   } catch (Exception e) {
//		   JdbcTemplate.rollback(con);
//		   MessageEntity message = 
//					new MessageEntity("error", 9);
//		   
//			message.setUrl("/work/work11/purchaser/purchaserForm.html");
//			message.setLinkTitle("회원 가입");
//			throw new CommonException(message);
//	   }finally{
//		   JdbcTemplate.close(pstmt);
//		   JdbcTemplate.close(con);
//	   }
	}
	
	//로그인
	public PurchaserEntity login(String id, String pw)throws CommonException{

	    Connection con = JdbcTemplate.getConnection();
        PurchaserDAO dao = new PurchaserDAO();
        return dao.login( con, id, pw );
        
//		Connection con = JdbcTemplate.getConnection();
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		PurchaserEntity entity = null;
//		try{
//	
//			//return dao.login(con , id, pw);
//			
//			String sql = "select * from purchaserMember where purchaser_id = ? and purchaser_pw = ?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, id);
//			pstmt.setString(2, pw);
//			
//			
//			rs = pstmt.executeQuery();
//			if(rs.next()){
//				String purchaser_id = rs.getString("purchaser_id");
//				String purchaser_pw = rs.getString("purchaser_pw");
//				String purchaser_name = rs.getString("purchaser_name");
//				String purchaser_addr = rs.getString("purchaser_addr");
//				String purchaser_phone = rs.getString("purchaser_phone");
//				String purchaser_email = rs.getString("purchaser_email");
//				int purchaser_score = rs.getInt("purchaser_score");
//				entity = new PurchaserEntity(purchaser_id, purchaser_pw, purchaser_name, purchaser_addr, purchaser_phone, purchaser_email , purchaser_score );
//			}
//			
//		} catch (Exception e) {
//			MessageEntity message = new MessageEntity("error",0);
//			message.setUrl("/work/work11/loginForm.html");
//			message.setLinkTitle("로그인");
//			throw new CommonException(message);
//		   }finally{
//			   JdbcTemplate.close(rs);
//			   JdbcTemplate.close(pstmt);
//			   JdbcTemplate.close(con);
//		   }
//		
//		return entity;
	}

	 //회원수정화면보기
    public PurchaserEntity purchaserUpdateForm(String id)throws CommonException{

        Connection con = JdbcTemplate.getConnection();
        PurchaserDAO dao = new PurchaserDAO();
        return dao.purchaserUpdateForm( con, id );
        
//    	Connection con = JdbcTemplate.getConnection();
//    	PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		PurchaserEntity entity = null;
// 	   try{
// 		
// 		  String sql = "select purchaser_id,purchaser_pw, purchaser_name, purchaser_addr,purchaser_phone, purchaser_email, p.purchaser_score, grade_id"
//					+ "  from purchasermember  p, grade g  where p.purchaser_score between g.grade_min and g.grade_max and purchaser_id = ?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, id);
//			rs = pstmt.executeQuery();
//			if(rs.next()){
//				String purchaser_id = rs.getString("purchaser_id");
//				String purchaser_pw = rs.getString("purchaser_pw");
//				String purchaser_name = rs.getString("purchaser_name");
//				String purchaser_addr = rs.getString("purchaser_addr");
//				String purchaser_phone = rs.getString("purchaser_phone");
//				String purchaser_email =  rs.getString("purchaser_email");
//				int purchaser_score = rs.getInt("purchaser_score");
//				String purchaser_grade = rs.getString("grade_id");
//				entity = new PurchaserEntity(purchaser_id, purchaser_pw, purchaser_name, purchaser_addr, purchaser_phone, purchaser_email , purchaser_score);
//				entity.setPurchaserGrade(purchaser_grade);
//			}
// 	  } catch (Exception e) {
// 		     MessageEntity message = new MessageEntity("error", 10);
//			message.setUrl("/work/work11/purchaserUpdateForm");
//			message.setLinkTitle("회원수정");
//			throw new CommonException(message);
// 	   }finally{
// 		   
// 		  JdbcTemplate.close(rs);
//		  JdbcTemplate.close(pstmt);
// 		  JdbcTemplate.close(con);
// 	   }
//    	return entity;
    }
    
    //회원수정
    public void purchaserUpdate(PurchaserEntity entity)throws CommonException{
 
        Connection con = JdbcTemplate.getConnection();
        PurchaserDAO dao = new PurchaserDAO();
        dao.purchaserUpdate( con, entity );
        
//    	Connection con = JdbcTemplate.getConnection();
//    	PreparedStatement pstmt = null;
//    	 try{
//    		 
//    		 String sql = "update purchaserMember set purchaser_pw = ? , purchaser_name=?, purchaser_addr = ? , purchaser_phone = ? , purchaser_email = ?  "
// 					+ " where purchaser_id = ? ";
// 			pstmt = con.prepareStatement(sql);
// 		
// 			pstmt.setString(1, entity.getPurchaserPw());
// 			pstmt.setString(2, entity.getPurchaserName());
// 			pstmt.setString(3, entity.getPurchaserAddr());
// 			pstmt.setString(4, entity.getPurchaserPhone());
// 			pstmt.setString(5, entity.getPurchaserEmail());
// 			pstmt.setString(6, entity.getPurchaserId());
// 			
// 			
// 			int result  = pstmt.executeUpdate();
// 			  if(result == 0) {
// 					throw new Exception();
// 				}
//    	       JdbcTemplate.commit(con);
//    	 } catch (Exception e) {
//    		 JdbcTemplate.rollback(con);
//    		 MessageEntity message = 
//  					new MessageEntity("error",10);
//     		 message.setUrl("/work/work11/purchaserUpdateForm");
//  			message.setLinkTitle("회원수정");
//  			throw new CommonException(message);
//    	   }finally{
//    		   
//    		   JdbcTemplate.close(pstmt);
//    		   JdbcTemplate.close(con);
//    	   }
//    	 
//    	
   }
}
