package work11.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import work11.common.JdbcTemplate;
import work11.dao.ProductDAO;
import work11.entity.MessageEntity;
import work11.entity.ProductDetailEntity;
import work11.entity.ProductEntity;
import work11.exception.CommonException;

public class ProductBiz {

	// 상품등록
	public void productAdd(ProductEntity entity) throws CommonException {

	    
	    Connection con = JdbcTemplate.getConnection();
	    ProductDAO dao = new ProductDAO();
        dao.productAdd( con, entity );
        
//		Connection con = JdbcTemplate.getConnection();
//		PreparedStatement pstmt = null;
//		try {
//
//			String sql = "insert into product ( product_id,category_id,product_name,product_price,product_info,product_company,product_quantity,seller_id )"
//					+ " values ( ? , ? , ?, ? ,? ,? ,? , ?) ";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, entity.getProductId());
//			pstmt.setString(2, entity.getCategoryId());
//			pstmt.setString(3, entity.getProductName());
//			pstmt.setInt(4, entity.getProductPrice());
//			pstmt.setString(5, entity.getProductInfo());
//			pstmt.setString(6, entity.getProductCompany());
//			pstmt.setInt(7, entity.getProductQuantity());
//			pstmt.setString(8, entity.getSellerId());
//
//			int result = pstmt.executeUpdate();
//
//			if (result == 0) {
//				throw new Exception();
//			}
//			JdbcTemplate.commit(con);
//		} catch (Exception e) {
//			JdbcTemplate.rollback(con);
//			MessageEntity message = new MessageEntity("error", 7);
//			message.setUrl("/work/work11/product/productAddForm.html");
//			message.setLinkTitle("상품 등록");
//			throw new CommonException(message);
//		} finally {
//
//			JdbcTemplate.close(pstmt);
//			JdbcTemplate.close(con);
//		}

	}

	// 상품 목록
	public ArrayList<ProductEntity> productAllList() throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
        ProductDAO dao = new ProductDAO();
        return dao.productAllList( con );
        
//		Connection con = JdbcTemplate.getConnection();
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
//		try {
//
//			String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date ,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id";
//			pstmt = con.prepareStatement(sql);
//			rs = pstmt.executeQuery();
//			while (rs.next()) {
//
//				String product_id = rs.getString("product_id");
//				String category_id = rs.getString("category_id");
//				String product_name = rs.getString("product_name");
//				int product_price = rs.getInt("product_price");
//				String product_info = rs.getString("product_info");
//				String product_company = rs.getString("product_company");
//				String product_date = rs.getString("product_date");
//				int product_quantity = rs.getInt("product_quantity");
//				String seller_id = rs.getString("seller_id");
//				String category_name = rs.getString("large") + "-"
//						+ rs.getString("middle");
//				ProductEntity entity = new ProductEntity(product_id,
//						category_id, product_name, product_price,
//						product_company, product_quantity, product_info,
//						product_date, seller_id);
//				entity.setCategoryName(category_name);
//				list.add(entity);
//			}
//		} catch (Exception e) {
//			MessageEntity message = new MessageEntity("error", 8);
//			message.setUrl("/work/work11/login");
//			message.setLinkTitle("로그인");
//			throw new CommonException(message);
//		} finally {
//
//			JdbcTemplate.close(rs);
//			JdbcTemplate.close(pstmt);
//			JdbcTemplate.close(con);
//		}
//		return list;
	}

	public ArrayList<ProductEntity> productList(String id) throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
        ProductDAO dao = new ProductDAO();
        return dao.productList( con, id );
        
//		Connection con = JdbcTemplate.getConnection();
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
//		try {
//			String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id and seller_id = ?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, id);
//			rs = pstmt.executeQuery();
//			while (rs.next()) {
//
//				String product_id = rs.getString("product_id");
//				String category_id = rs.getString("category_id");
//				String product_name = rs.getString("product_name");
//				int product_price = rs.getInt("product_price");
//				String product_info = rs.getString("product_info");
//				String product_company = rs.getString("product_company");
//				String product_date = rs.getString("product_date");
//				int product_quantity = rs.getInt("product_quantity");
//				String seller_id = rs.getString("seller_id");
//				String category_name = rs.getString("large") + "-"
//						+ rs.getString("middle");
//				ProductEntity entity = new ProductEntity(product_id,
//						category_id, product_name, product_price,
//						product_company, product_quantity, product_info,
//						product_date, seller_id);
//				entity.setCategoryName(category_name);
//				list.add(entity);
//			}
//		} catch (Exception e) {
//			MessageEntity message = new MessageEntity("error", 8);
//			message.setUrl("/work/work11/login");
//			message.setLinkTitle("로그인");
//			throw new CommonException(message);
//		} finally {
//
//			JdbcTemplate.close(rs);
//			JdbcTemplate.close(pstmt);
//			JdbcTemplate.close(con);
//		}
//
//		return list;
	}

	// 구매자 상품 검색
	public ArrayList<ProductEntity> productPurchaserSearch(String searchName,
			String searchValue) throws CommonException {

	    Connection con = JdbcTemplate.getConnection();
        ProductDAO dao = new ProductDAO();
        return dao.productPurchaserSearch( con, searchName, searchValue );
	    
//		ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
//
//		Connection con = JdbcTemplate.getConnection();
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//
//		try {
//
//			String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id ";
//			if ("productName".equals(searchName)) {
//				sql += " and product_name LIKE ?";
//			} else {
//				sql += " and product_company LIKE ?";
//			}
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, "%" + searchValue + "%");
//			rs = pstmt.executeQuery();
//			while (rs.next()) {
//
//				String product_id = rs.getString("product_id");
//				String category_id = rs.getString("category_id");
//				String product_name = rs.getString("product_name");
//				int product_price = rs.getInt("product_price");
//				String product_info = rs.getString("product_info");
//				String product_company = rs.getString("product_company");
//				String product_date = rs.getString("product_date");
//				int product_quantity = rs.getInt("product_quantity");
//				String seller_id = rs.getString("seller_id");
//				String category_name = rs.getString("large") + "-"
//						+ rs.getString("middle");
//				ProductEntity entity = new ProductEntity(product_id,
//						category_id, product_name, product_price,
//						product_company, product_quantity, product_info,
//						product_date, seller_id);
//				entity.setCategoryName(category_name);
//				list.add(entity);
//			}
//		} catch (Exception e) {
//			MessageEntity message = new MessageEntity("error", 8);
//			message.setUrl("/work/work11/productList");
//			message.setLinkTitle("상품 목록");
//			throw new CommonException(message);
//		} finally {
//
//			JdbcTemplate.close(rs);
//			JdbcTemplate.close(pstmt);
//			JdbcTemplate.close(con);
//		}
//		return list;
	}

	// 판매자 상품 검색
	public ArrayList<ProductEntity> productSellerSearch(String sellerId,
			String searchName, String searchValue) throws CommonException {

	    
	    Connection con = JdbcTemplate.getConnection();
        ProductDAO dao = new ProductDAO();
        return dao.productSellerSearch( con, sellerId, searchName, searchValue );
        
//		ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
//
//		Connection con = JdbcTemplate.getConnection();
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//
//		try {
//
//			String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id ";
//			if ("productName".equals(searchName)) {
//				sql += " and product_name LIKE ? and seller_id = ?";
//			} else {
//				sql += " and product_company LIKE ? and seller_id = ?";
//			}
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, "%" + searchValue + "%");
//			pstmt.setString(2, sellerId);
//			rs = pstmt.executeQuery();
//			while (rs.next()) {
//
//				String product_id = rs.getString("product_id");
//				String category_id = rs.getString("category_id");
//				String product_name = rs.getString("product_name");
//				int product_price = rs.getInt("product_price");
//				String product_info = rs.getString("product_info");
//				String product_company = rs.getString("product_company");
//				String product_date = rs.getString("product_date");
//				int product_quantity = rs.getInt("product_quantity");
//				String seller_id = rs.getString("seller_id");
//				String category_name = rs.getString("large") + "-"
//						+ rs.getString("middle");
//				ProductEntity entity = new ProductEntity(product_id,
//						category_id, product_name, product_price,
//						product_company, product_quantity, product_info,
//						product_date, seller_id);
//				entity.setCategoryName(category_name);
//				list.add(entity);
//			}
//		} catch (Exception e) {
//			MessageEntity message = new MessageEntity("error", 8);
//			message.setUrl("/work/work11/productList");
//			message.setLinkTitle("상품 목록");
//			throw new CommonException(message);
//		} finally {
//
//			JdbcTemplate.close(rs);
//			JdbcTemplate.close(pstmt);
//			JdbcTemplate.close(con);
//		}
//		return list;
	}
	
	   public ArrayList<ProductDetailEntity> productDetailList( String productId ) throws CommonException {
	        
	        Connection con = JdbcTemplate.getConnection();
	        ProductDAO dao = new ProductDAO();
	        ArrayList<ProductDetailEntity> list = dao.productDetail( con, productId );
	        return list;
	
	   }
}// end class