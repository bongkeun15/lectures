package work11.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work11.biz.OrderBiz;
import work11.entity.MessageEntity;
import work11.entity.OrderEntity;
import work11.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work11.ProductBuyCancel", urlPatterns = { "/work11/productBuyCancel" })
public class ProductBuyCancelServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			String orderId = request.getParameter("orderId");
			String productId = request.getParameter("productId"); // 구매자 아이디
			int orderQuantity = Integer.parseInt(request
					.getParameter("orderQuantity"));

			OrderBiz biz = new OrderBiz();
			try {
				OrderEntity entity = new OrderEntity();
				entity.setProductId(productId);
				entity.setOrderQuantity(orderQuantity);
				entity.setOrderId(orderId);
				biz.productBuyCancel(entity);

				MessageEntity message = new MessageEntity("success", 10);
				message.setUrl("/work/work11/productOrderList");
				message.setLinkTitle("구매 목록");
				request.setAttribute("message", message);

			} catch (CommonException e) {
				request.setAttribute("message", e.getMessageEntity());

			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);

		}
		RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
		dis.forward(request, response);

	}

}
