package work11.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work11.biz.CartBiz;
import work11.entity.CartEntity;
import work11.entity.MessageEntity;
import work11.entity.PurchaserEntity;
import work11.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work11.ProductCartList", urlPatterns = { "/work11/productCartList" })
public class ProductCartListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			PurchaserEntity entity = (PurchaserEntity) session
					.getAttribute("purchaserLogin");
			String purchaserId = entity.getPurchaserId();

			CartBiz biz = new CartBiz();

			ArrayList<CartEntity> list;
			try {
				list = biz.cartList(purchaserId);
				request.setAttribute("cartList", list);
				request.setAttribute("purchaserId", purchaserId);

				RequestDispatcher dis = request
						.getRequestDispatcher("product/productCartList.jsp");
				dis.forward(request, response);

			} catch (CommonException e) {
				request.setAttribute("message", e.getMessageEntity());
				RequestDispatcher dis = request
						.getRequestDispatcher("message.jsp");
				dis.forward(request, response);
			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);
			RequestDispatcher dis = request.getRequestDispatcher("message.jsp");
			dis.forward(request, response);
		}
	}

}
