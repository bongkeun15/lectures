/*
 *  1. 상품 상세 처리 서블릿
 *   - 로그인이 성공후에 사용 가능하다.
 */

package work11.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work11.biz.ProductBiz;
import work11.entity.MessageEntity;
import work11.entity.ProductDetailEntity;
import work11.exception.CommonException;

@WebServlet(name = "work11.ProductDetail", urlPatterns = { "/work11/productDetail" })
public class ProductDetailServlet extends HttpServlet {

    protected void doGet( HttpServletRequest request, HttpServletResponse response )
            throws ServletException, IOException {

        /*
         * 
         * 1. ProductBiz의 productDetail() 메소드를 사용하여 상품의 상세정보를 얻는다.
         * 
         * 
         * 2. 성공시 productDetailList.jsp로 RequestDispatcher 처리하고 실패시
         * MessageEntity 클래스를 참고하여 메시지를 작성하고 RequestDispatcher로 처리한다.
         * 
         * 
         * 3. 로그인이 되지 않은 상황에서 요청이 된 경우에는 다음 방법으로 메시지를 출력한다.
         * 
         * MessageEntity message = new MessageEntity("message", 0);
         * message.setUrl("loginForm.html"); message.setLinkTitle("로그인");
         * request.setAttribute("message", message); RequestDispatcher dis =
         * request.getRequestDispatcher("message.jsp"); dis.forward(request,
         * response);
         * 
         */

        request.setCharacterEncoding( "UTF-8" );
        response.setContentType( "text/html;charset=UTF-8" );
        HttpSession session = request.getSession();

        RequestDispatcher rd = request.getRequestDispatcher( "/product/productDetailList.jsp" );

        String productId = request.getParameter( "productId" );
        System.out.println( "링크야 이리오너라\n" + productId + " productId도 오너라 " );

        ProductBiz pb = new ProductBiz();

        if ( session.getAttribute( "member" ) != null ) {

            try {
                System.out.println( "product detail servley 진입1" );
                ArrayList<ProductDetailEntity> list = pb.productDetailList( productId );
                System.out.println( "product detail servley 진입2" );
                request.setAttribute( "list", list );
                System.out.println( "product detail servley 진입3" );
                rd = request.getRequestDispatcher( "/work11/product/productDetailList.jsp" );
                System.out.println( "product detail servley 진입4" );
                rd.forward( request, response );
                System.out.println( "product detail servley 진입5" );

            } catch ( CommonException e ) {
                System.out.println( "프로덕트딭테일써블릣 오류 !!!!" );
                e.printStackTrace();

                rd = request.getRequestDispatcher( "message.jsp" );
                request.setAttribute( "message", e.getMessageEntity() );
                rd.forward( request, response );

            }
        }

        else {
            MessageEntity msg = new MessageEntity( "message", 8 );
            msg.setUrl( "loginForm.html" );
            msg.setLinkTitle( "로그인" );
            request.setAttribute( "message", msg );

        }
    }
}
