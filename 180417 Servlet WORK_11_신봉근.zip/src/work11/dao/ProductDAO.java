/*
 *    상품 관련 DAO 클래스
 * 
 */

package work11.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import work11.common.JdbcTemplate;
import work11.entity.CommentEntity;
import work11.entity.MessageEntity;
import work11.entity.ProductDetailEntity;
import work11.entity.ProductEntity;
import work11.exception.CommonException;



public class ProductDAO {

	//상품 등록
	public void productAdd(Connection con, ProductEntity entity)throws CommonException {

		/*
		 * 1. 해당 상품 정보를 상품 테이블에 저장한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
	    
        PreparedStatement pstmt = null;
        try {

            String sql = "insert into product ( product_id,category_id,product_name,product_price,product_info,product_company,product_quantity,seller_id )"
                    + " values ( ? , ? , ?, ? ,? ,? ,? , ?) ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, entity.getProductId());
            pstmt.setString(2, entity.getCategoryId());
            pstmt.setString(3, entity.getProductName());
            pstmt.setInt(4, entity.getProductPrice());
            pstmt.setString(5, entity.getProductInfo());
            pstmt.setString(6, entity.getProductCompany());
            pstmt.setInt(7, entity.getProductQuantity());
            pstmt.setString(8, entity.getSellerId());

            int result = pstmt.executeUpdate();

            if (result == 0) {
                throw new Exception();
            }
            JdbcTemplate.commit(con);
        } catch (Exception e) {
            JdbcTemplate.rollback(con);
            MessageEntity message = new MessageEntity("error", 7);
            message.setUrl("/work/work11/product/productAddForm.html");
            message.setLinkTitle("상품 등록");
            throw new CommonException(message);
        } finally {

            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }
	}

	// 모든 상품목록 보기
		public ArrayList<ProductEntity> productAllList(Connection con) throws CommonException{

			/*
			 * 1. 모든 상품 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
		
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
	        try {

	            String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date ,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id";
	            pstmt = con.prepareStatement(sql);
	            rs = pstmt.executeQuery();
	            while (rs.next()) {

	                String product_id       = rs.getString("product_id");
	                String category_id      = rs.getString("category_id");
	                String product_name     = rs.getString("product_name");
	                int    product_price    = rs.getInt("product_price");
	                String product_info     = rs.getString("product_info");
	                String product_company  = rs.getString("product_company");
	                String product_date     = rs.getString("product_date");
	                int    product_quantity = rs.getInt("product_quantity");
	                String seller_id        = rs.getString("seller_id");
	                String category_name    = rs.getString("large") + "-" + rs.getString("middle");
	                ProductEntity entity    = new ProductEntity(product_id,
	                        category_id, product_name, product_price,
	                        product_company, product_quantity, product_info,
	                        product_date, seller_id);
	                entity.setCategoryName(category_name);
	                list.add(entity);
	            }
	        } catch (Exception e) {
	            MessageEntity message = new MessageEntity("error", 8);
	            message.setUrl("/work/work11/login");
	            message.setLinkTitle("로그인");
	            throw new CommonException(message);
	        } finally {

	            JdbcTemplate.close(rs);
	            JdbcTemplate.close(pstmt);
	            JdbcTemplate.close(con);
	        }
	        return list;
		}
		
	// 특정 판매자 상품목록
	public ArrayList<ProductEntity> productList(Connection con,String id)throws CommonException {

		/*
		 * 1. sellId와 일치하는 판매자가 등록한 모든 상품 정보를 리턴한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
        try {
            String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id and seller_id = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                String product_id = rs.getString("product_id");
                String category_id = rs.getString("category_id");
                String product_name = rs.getString("product_name");
                int product_price = rs.getInt("product_price");
                String product_info = rs.getString("product_info");
                String product_company = rs.getString("product_company");
                String product_date = rs.getString("product_date");
                int product_quantity = rs.getInt("product_quantity");
                String seller_id = rs.getString("seller_id");
                String category_name = rs.getString("large") + "-"
                        + rs.getString("middle");
                ProductEntity entity = new ProductEntity(product_id,
                        category_id, product_name, product_price,
                        product_company, product_quantity, product_info,
                        product_date, seller_id);
                entity.setCategoryName(category_name);
                list.add(entity);
            }
        } catch (Exception e) {
            MessageEntity message = new MessageEntity("error", 8);
            message.setUrl("/work/work11/login");
            message.setLinkTitle("로그인");
            throw new CommonException(message);
        } finally {

            JdbcTemplate.close(rs);
            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }

        return list;
	}


	// 구매자 상품 검색
		public ArrayList<ProductEntity> productPurchaserSearch( Connection con , String searchName,
				String searchValue) throws CommonException {
			
			/*
			 * 1. searchName, searchValue에 해당하는  모든 상품 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
		
		    ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();

	        PreparedStatement pstmt = null;
	        ResultSet rs = null;

	        try {

	            String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id ";
	            if ("productName".equals(searchName)) {
	                sql += " and product_name LIKE ?";
	            } else {
	                sql += " and product_company LIKE ?";
	            }
	            pstmt = con.prepareStatement(sql);
	            pstmt.setString(1, "%" + searchValue + "%");
	            rs = pstmt.executeQuery();
	            while (rs.next()) {

	                String product_id = rs.getString("product_id");
	                String category_id = rs.getString("category_id");
	                String product_name = rs.getString("product_name");
	                int product_price = rs.getInt("product_price");
	                String product_info = rs.getString("product_info");
	                String product_company = rs.getString("product_company");
	                String product_date = rs.getString("product_date");
	                int product_quantity = rs.getInt("product_quantity");
	                String seller_id = rs.getString("seller_id");
	                String category_name = rs.getString("large") + "-"
	                        + rs.getString("middle");
	                
	                ProductEntity entity = new ProductEntity(product_id,
	                        category_id, product_name, product_price,
	                        product_company, product_quantity, product_info,
	                        product_date, seller_id);
	                
	                entity.setCategoryName(category_name);
	                list.add(entity);
	            }
	        } catch (Exception e) {
	            MessageEntity message = new MessageEntity("error", 8);
	            message.setUrl("/work/work11/productList");
	            message.setLinkTitle("상품 목록");
	            throw new CommonException(message);
	        } finally {

	            JdbcTemplate.close(rs);
	            JdbcTemplate.close(pstmt);
	            JdbcTemplate.close(con);
	        }
	        return list;
		}
		
		// 판매자 상품 검색
		public ArrayList<ProductEntity> productSellerSearch(Connection con ,  String sellerId, String searchName,
				String searchValue) throws CommonException {
			
			/*
			 * 1. sellId, searchName, searchValue에 해당하는  모든 상품 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
		
		    ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();

	        PreparedStatement pstmt = null;
	        ResultSet rs = null;

	        try {

	            String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id ";
	            
	            if ("productName".equals(searchName)) {
	                sql += " and product_name LIKE ? and seller_id = ?";
	                
	            } else {
	                sql += " and product_company LIKE ? and seller_id = ?";
	            }
	            
	            pstmt = con.prepareStatement(sql);
	            pstmt.setString(1, "%" + searchValue + "%");
	            pstmt.setString(2, sellerId);
	            rs = pstmt.executeQuery();
	            
	            while (rs.next()) {

	                String product_id       = rs.getString("product_id");
	                String category_id      = rs.getString("category_id");
	                String product_name     = rs.getString("product_name");
	                int    product_price    = rs.getInt   ("product_price");
	                String product_info     = rs.getString("product_info");
	                String product_company  = rs.getString("product_company");
	                String product_date     = rs.getString("product_date");
	                int    product_quantity = rs.getInt   ("product_quantity");
	                String seller_id        = rs.getString("seller_id");
	                String category_name    = rs.getString("large") + "-"  + rs.getString("middle");
	                
	                ProductEntity entity = new ProductEntity(product_id,
	                        category_id, product_name, product_price,
	                        product_company, product_quantity, product_info,
	                        product_date, seller_id);
	                
	                entity.setCategoryName(category_name);
	                
	                list.add(entity);
	            }
	            
	        } catch (Exception e) {
	            MessageEntity message = new MessageEntity("error", 8);
	            message.setUrl("/work/work11/productList");
	            message.setLinkTitle("상품 목록");
	            throw new CommonException(message);
	            
	        } finally {

	            JdbcTemplate.close(rs);
	            JdbcTemplate.close(pstmt);
	            JdbcTemplate.close(con);
	        }
	        return list;
		}
		
	//제품 상세보기
		public ArrayList<ProductDetailEntity> productDetail(Connection con, String productId)throws CommonException{
			
			/*
			 * 1. productId에 해당하는 상품 상세 정보를 리턴한다.
			 * 
			 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
			 * 
			 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
			 * 현재 메소드에서 close 처리한다.
			 */
		    
			//TODO 크앙ㅋ으크아 !!! 제품 상세보기 !
		    
		    ArrayList<ProductDetailEntity> list = new ArrayList<ProductDetailEntity>();
		    
		    PreparedStatement pstmt = null;
            ResultSet rs = null;

            System.out.println( "productDAO try 직전" );
            try {
                System.out.println( "productDAO try 시작" );
            
                String sql = "SELECT "
                           + "PRODUCT_ID, "
                           + "P.CATEGORY_ID, "
                           + "PRODUCT_NAME, "
                           + "PRODUCT_PRICE, "
                           + "PRODUCT_INFO, "
                           + "PRODUCT_COMPANY, "
                           + "TO_CHAR(PRODUCT_DATE, 'YYYY-MM-DD'), "
                           + "PRODUCT_DATE, "
                           + "PRODUCT_QUANTITY, "
                           + "SELLER_ID, "
                           + "C.CATEGORY_LARGE AS LARGE, "
                           + "C.CATEGORY_MIDDLE AS MIDDLE "
                          
                           + "FROM PRODUCT P, CATEGORY C "
                           
                           + "WHERE P.CATEGORY_ID = C.CATEGORY_ID "
                           + "AND PRODUCT_ID = ? ";
                
                
//		    String sql = "SELECT " +
//                         "P.PRODUCT_NAME," +                                 // 1
//                         "C.CATEGORY_LARGE||'-'||C.CATEGORY_MIDDLE CTGR," +  // 2
//                         "P.PRODUCT_COMPANY," +                              // 3
//                         "P.PRODUCT_QUANTITY, " +                            // 4
//                         "P.PRODUCT_INFO," +                                 // 5
//                         "PC.COMM_CONTENT," +                                // 6
//                         "PC.COMM_SCORE " +                                  // 7
//       
//                         "FROM" +
//                         "CATEGORY C, PRODUCT P, PRODCOMMENT PC, PRODORDER PO " +
//       
//                         "WHERE C.CATEGORY_ID = P.CATEGORY_ID " +
//                         "AND PO.ORDER_ID = PC.ORDER_ID " +
//                         "AND P.PRODUCT_ID = PO.PRODUCT_ID          " +  
//		                 "AND P.PRODUCT_ID = ?  ";
                System.out.println( "productDAO try 중 111111111111" );		    
		    pstmt = con.prepareStatement(sql);
		    System.out.println( "productDAO try 중 2222222222222" );		    
		    pstmt.setString(1, productId);
		    System.out.println( "productDAO try 중 333333333333" );		    
            rs = pstmt.executeQuery();
            System.out.println( "productDAO try 중 444444444444" );		    
            System.out.println( rs + "===================================" );
            while (rs.next()) {

                System.out.println( "productDAO while 진입" );
                
                String product_id           = rs.getString( "product_id" );
                String category_id              = rs.getString( "category_id" );
                String product_name         = rs.getString( "product_name" );
                int    product_price            = rs.getInt( "product_price" );
                String product_info             = rs.getString( "product_info" );
                String product_company           = rs.getString( "product_company" );
                String product_date              = rs.getString( "product_date" );
                int    product_quantity              = rs.getInt( "product_quantity" );
                String seller_id             = rs.getString( "seller_id" );
                String category_name            = rs.getString( "large") + "-" + rs.getString( "middle" );
                
                
                System.out.println( "1      / "  + product_id      );
                System.out.println( "2      / "  + category_id     );
                System.out.println( "3      / "  + product_name    );
                System.out.println( "4      / "  + product_price   );
                System.out.println( "5      / "  + product_info    );
                System.out.println( "6      / "  + product_company );
                System.out.println( "7      / "  + product_date    );
                System.out.println( "8      / "  + product_quantity);
                System.out.println( "9      / "  + seller_id       );
                System.out.println( "10     / "  + category_name   );
                
                ProductDetailEntity entity = new ProductDetailEntity(
                        product_id, category_id,product_name, product_price,
                        product_company, product_quantity, product_info, seller_id,
                        category_name, null);
                
                System.out.println( "productDAO entity 아래 " );
                
                list.add(entity);
                System.out.println( "productDAO entity를 list에 담음 " );
            }
            
            System.out.println( "productDAO 두번째 sql 진행" );
            sql = "SELECT *                                 "
                + "FROM PRODORDER PO, PRODCOMMENT PC            "
                + "WHERE PO.ORDER_ID = PC.ORDER_ID           "
                + "AND PO.PRODUCT_ID = ?                         ";
            
            
            System.out.println( "productDAO 두번째 sql 진행 1111" );
            pstmt = con.prepareStatement( sql );
            System.out.println( "productDAO 두번째 sql 진행 2222" );
            pstmt.setString( 1, productId );
            System.out.println( "productDAO 두번째 sql 진행 3333" );
            rs = pstmt.executeQuery();
            System.out.println( "productDAO 두번째 sql 진행 44444" );
            System.out.println( rs + "-------------------------------------------" );
            
            
            while(rs.next()){
                System.out.println( "productDAO 두번째 while 진입" );
                
                System.out.println( rs.getString( "comm_content"     ) );
                System.out.println( rs.getString( "purchaser_id"   )   );
                System.out.println( rs.getInt   ( "comm_score"     )  );
                
                String purchaser_id =    rs.getString( "purchaser_id"   );
                String commContent  =    rs.getString( "comm_content"     );
                int    commScore       = rs.getInt   ( "comm_score"     );
                
                System.out.println( purchaser_id );
                System.out.println( commContent  );
                System.out.println( commScore    );
                
                
                System.out.println( "productDAO 두번째 while 진입 2" );
                
                CommentEntity commentEntity = new CommentEntity(purchaser_id, commContent, commScore + "");
                System.out.println( "commentEntity, productDAO" );
                
                ProductDetailEntity pEntity = new ProductDetailEntity("","","",0,"",0,"","","",commentEntity);
                System.out.println( "ProductDetailEntity, productDAO" );
                
                list.add( pEntity );
                
            }
            
        } catch (Exception e) {
            MessageEntity message = new MessageEntity("error", 15);
            message.setUrl("/work/work11/productList");
            message.setLinkTitle("상품 목록 보기");
            throw new CommonException(message);
            
        } finally {

            JdbcTemplate.close(rs);
            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }
			return list;
		}
}// end class
