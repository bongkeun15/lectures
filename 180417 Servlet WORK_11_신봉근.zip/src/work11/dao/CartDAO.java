/*
 *    장바구니 처리 관련 DAO 클래스
 * 
 */

package work11.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import work11.common.JdbcTemplate;
import work11.entity.CartEntity;
import work11.entity.MessageEntity;
import work11.exception.CommonException;

public class CartDAO {

	// Cart에 존재여부 체크
	private boolean isExistCart( Connection con, CartEntity entity) {

		/*
		 * 1. cart 테이블에서 해당 상품이 있는지를 검사한다. 존재하면 true 값을 리턴하고 존재하지 않으면 false 값을
		 * 리턴한다.
		 * 
		 * 2. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
	    
	    con = JdbcTemplate.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean result = false;
        try {

            String sql = "select * from cart where product_id = ? and purchaser_id = ? ";

            System.out.println("sql > " + sql);
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, entity.getProductId());
            pstmt.setString(2, entity.getPurchaserId());
            rs = pstmt.executeQuery();
            while (rs.next()) {
                result = true;
            }
        } catch (Exception e) {

        } finally {

            JdbcTemplate.close(rs);
            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }
        return result;
	}

	// 장바구니 담기
	public void productAddCart(Connection con, CartEntity entity)
			throws CommonException {
		/*
		 * 1. cart 테이블에서 해당 상품이 존재하면 상품 정보를 수정하고 존재하지 않으면 새로 추가한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
//	    Connection con = JdbcTemplate.getConnection();
	    
	    
        PreparedStatement pstmt = null;
        try {


            if (isExistCart(con, entity)) {
                String sql = "update cart set cart_quantity = cart_quantity + ? where product_id = ? and purchaser_id = ? ";
                pstmt = con.prepareStatement(sql);
                
                pstmt.setInt   (1, entity.getCartQuantity());
                pstmt.setString(2, entity.getProductId());
                pstmt.setString(3, entity.getPurchaserId());
                int result = pstmt.executeUpdate();
                
                if(result == 0 ){
                    throw new Exception();
                }
            } else {
                String sql = "insert into cart ( product_id, purchaser_id, cart_quantity )"
                        + " values ( ? , ? , ? ) ";
                pstmt = con.prepareStatement(sql);
                
                pstmt.setString(1, entity.getProductId());
                pstmt.setString(2, entity.getPurchaserId());
                pstmt.setInt   (3, entity.getCartQuantity());
                int result = pstmt.executeUpdate();
                
                if(result == 0 ){
                    throw new Exception();
                }
            }
            JdbcTemplate.commit(con);
            
        } catch (Exception e) {
            JdbcTemplate.rollback(con);
            MessageEntity message = 
                    new MessageEntity("error",2);
            message.setUrl("/work/work11/productList");
            message.setLinkTitle("장바구니");
            throw new CommonException(message);
            
        } finally {
            
            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }   
	}// end productCart

	// cart 목록
	public ArrayList<CartEntity> cartList(String purchaser_id)
			throws CommonException {

		/*
		 * 1. 테이블에서 구매자 아이디에 해당되는 장바구니 정보를 얻는다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
	    ArrayList<CartEntity> list = new ArrayList<CartEntity>();
        
        Connection con = JdbcTemplate.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            String sql = "select p.product_id, p.product_name, p.product_price, p.product_company, p.product_quantity, cart_quantity, cart.purchaser_id, c.category_large as large , c.category_middle as middle from product p, category c , cart  where p.category_id = c.category_id and p.product_id = cart.product_id and  cart.purchaser_id = ? ";

            System.out.println("sql > " + sql);
            pstmt = con.prepareStatement(sql);
            // pstmt.setString(1, product_id);
            pstmt.setString(1, purchaser_id);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                String p_id             = rs.getString("product_id"      );
                String product_name     = rs.getString("product_name"    );
                int    product_price    = rs.getInt   ("product_price"   );
                String product_company  = rs.getString("product_company" );
                int    cart_quantity    = rs.getInt   ("cart_quantity"   );
                int    product_quantity = rs.getInt   ("product_quantity");
                String c_id             = rs.getString("purchaser_id"    );
                String category_name    = rs.getString("large") + "-" + rs.getString("middle");

                CartEntity entity = new CartEntity(p_id, c_id, product_name,
                        product_price, product_company, cart_quantity,
                        category_name , product_quantity);
                
                list.add(entity);
            }
        } catch (Exception e) {
            MessageEntity message = 
                    new MessageEntity("error",5);
            message.setUrl("/work/work11/productList");
            message.setLinkTitle("상품 목록");
            throw new CommonException(message);
        } finally {
            JdbcTemplate.close(rs);
            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }
        return list;
	}

	// 장바구니 수정
	public void productUpdateCart(CartEntity entity)
			throws CommonException {


		/*
		 * 1. 해당하는 데이터로 장바구니 정보를 수정한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */
	    Connection con = JdbcTemplate.getConnection();
        PreparedStatement pstmt = null;
        try {

            String sql = "update cart set cart_quantity = ? where product_id = ? and purchaser_id = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(2, entity.getProductId());
            pstmt.setString(3, entity.getPurchaserId());
            pstmt.setInt(1, entity.getCartQuantity());
            int result = pstmt.executeUpdate();
            if(result == 0) {
                throw new Exception();
            }
            JdbcTemplate.commit(con);
        } catch (Exception e) {
            JdbcTemplate.rollback(con);
            MessageEntity message = 
                    new MessageEntity("error",3);
            message.setUrl("/work/work11/productCartList");
            message.setLinkTitle("장바구니");
            throw new CommonException(message);
        } finally {
            
            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }
    }// end productCart

	// 장바구니 삭제
	public void productDeleteCart(CartEntity entity)
			throws CommonException {

		/*
		 * 1. 해당하는 데이터로 장바구니 정보를 삭제한다.
		 * 
		 * 2. 실행중에 에러가 발생되면 MessageEntity 클래스와 CommonException 클래스로 예외를 처리한다.
		 * 
		 * 3. Connection은 biz 클래스에서 close 하고 나머지(ResultSet, PreparedStatement)는
		 * 현재 메소드에서 close 처리한다.
		 */

        Connection con = JdbcTemplate.getConnection();
        PreparedStatement pstmt = null;

        try {

            String sql = "delete from cart where product_id = ? and purchaser_id = ? ";
            pstmt = con.prepareStatement(sql);
            
            pstmt.setString(1, entity.getProductId());
            pstmt.setString(2, entity.getPurchaserId());
            int result = pstmt.executeUpdate();
            
            if(result == 0) {
                throw new Exception();
            }
            JdbcTemplate.commit(con);
            
        } catch (Exception e) {
            MessageEntity message = 
                    new MessageEntity("error",4);
            message.setUrl("/work/work11/productCartList");
            message.setLinkTitle("장바구니");
            throw new CommonException(message);
            
        } finally {
            
            JdbcTemplate.close(pstmt);
            JdbcTemplate.close(con);
        }
    }// end productCart
}// end class
