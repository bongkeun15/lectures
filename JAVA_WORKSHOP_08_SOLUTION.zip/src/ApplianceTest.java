
public class ApplianceTest {
	
	public static void main(String[] args) {
		Laptop laptop = new Laptop();
		laptop.brand = "LG";
		laptop.model = "13Z940-GT50K";
		laptop.year = 2014;
		laptop.price = 1200000;
		
		laptop.cpu = "Intel i5";
		laptop.memory = 4;
		
		laptop.laptopPrintInfo();
		
		laptop.laptopPowerOn();
		laptop.powerStatus();		
		laptop.laptopPowerOff();
		laptop.powerStatus();
		
		System.out.println("----------------------------------\n");
		
		Television tv = new Television();
		tv.brand = "LG";
		tv.model = "55LB5650";
		tv.year = 2014;
		tv.price = 1500000;
		
		tv.size = 55;
		tv.color = "�ǹ�";
		
		tv.televisionPrintInfo();
		
		tv.televisionPowerOn();
		tv.powerStatus();		
		tv.televisionPowerOff();
		tv.powerStatus();
	}
}
