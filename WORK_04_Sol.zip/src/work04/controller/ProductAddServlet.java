package work04.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work04.data.ProductCollection;
import work04.entity.ProductEntity;
import work04.entity.SellerEntity;
import work04.util.ValidationUtil;

@WebServlet(name = "work04.ProductAdd", urlPatterns = { "/work04/productAdd" })
public class ProductAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
			request.setCharacterEncoding("UTF-8");

			String categoryId = request.getParameter("categoryId");
			String productName = request.getParameter("productName");
			String productPrice = request.getParameter("productPrice");
			String productCompany = request.getParameter("productCompany");
			String productQuantity = request.getParameter("productQuantity");
			String productInfo = request.getParameter("productInfo");

			if (!ValidationUtil.checkRequired(categoryId)) {
				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[카테고리 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(productName)) {
				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[상품명 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(productPrice)
					|| !ValidationUtil.checkDigit(productPrice)) {
				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[가격 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(productCompany)) {
				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[제조사 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(productQuantity)
					|| !ValidationUtil.checkDigit(productQuantity)
					|| !ValidationUtil.lessLength(productQuantity, 4)) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[수량 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(productInfo)) {
				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[상품 소개 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록</a>");
				out.print("</font>");
				out.print("<center>");

			} else {

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일");
				String productDate = sdf.format(new Date());

				HttpSession sess = request.getSession();

				SellerEntity xxx = (SellerEntity) sess
						.getAttribute("sellerLogin");
				String sellerId = xxx.getSellerId();

				// 상품아이디 = 판매자아이디+시간
				String product_id = sellerId + System.currentTimeMillis();

				ProductEntity entity = new ProductEntity(product_id,
						categoryId, productName,
						Integer.parseInt(productPrice), productCompany,
						Integer.parseInt(productQuantity), productInfo,
						productDate, sellerId);

				ProductCollection productCollection = ProductCollection
						.getInstance();
				boolean result = productCollection.productAdd(entity);
				if (result) {

					out.print("<center>");
					out.print("<font color='red'>");
					out.println("[상품 등록 성공]");
					out.print("</font>");
					out.println("<hr>");
					out.println("<a href='/work/work04/productList'>상품 목록 보기</a>");

				} else {

					out.print("<center>");
					out.print("<font color='red'>");
					out.println("[상품 등록 실패]");
					out.print("</font>");
					out.println("<hr>");
					out.println(productName + " 상품명이 중복 되었습니다.<br>");
					out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록하기</a>");
					out.print("<center>");

				}

			}

		} else {

			out.print("<center>");
			out.print("<font color='red'>[ 로그인이 필요한 페이지 입니다.]</font>");
			out.println("<hr />");
			out.print("<a href='loginForm.html'>로그인</a>");
			out.print("<center>");
		}
		out.println("</body></html>");
	}

}
