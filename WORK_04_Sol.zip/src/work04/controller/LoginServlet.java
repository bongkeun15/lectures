package work04.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work04.data.PurchaserCollection;
import work04.data.SellerCollection;
import work04.entity.PurchaserEntity;
import work04.entity.SellerEntity;

/**
 * Servlet implementation class ConsumerServlet
 */

@WebServlet(name = "work04.Login", urlPatterns = { "/work04/login" })
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		request.getSession().invalidate();
		HttpSession session = request.getSession();

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String member = request.getParameter("member");

		if ("purchaser".equals(member)) {

			PurchaserCollection data = PurchaserCollection.getInstance();

			PurchaserEntity entity;

			entity = data.login(id, pw);

			if (entity != null) {
				session.setAttribute("purchaserLogin", entity);
				session.setAttribute("member", "purchaser");

				out.println("<h1>[로그인 성공]</h1>");
				out.println(" <a href='/work/work04/logout'>로그아웃</a>&nbsp;&nbsp;");
				out.println("<a href='/work/work04/purchaserUpdateForm'>회원정보수정</a>&nbsp;&nbsp;");
				out.println("<a href='/work/work04/productList'>상품목록보기</a>&nbsp;&nbsp;<br>");
				out.println("<hr>" + entity.getPurchaserName()
						+ "님 어서오십시요.<br>");

			} else {

				out.println("<h1>[로그인 실패]</h1><br>");
				out.println("<hr>아이디 또는 비밀번호가 틀립니다.<br>다시 로그인 하세요<br>");
				out.println("<a href='/work/work04/loginForm.html'>로그인</a>");
			}

		} else {

			SellerCollection data = SellerCollection.getInstance();

			SellerEntity entity;

			entity = data.login(id, pw);
			if (entity != null) {
				session.setAttribute("sellerLogin", entity);
				session.setAttribute("member", "seller");
				out.println("<h1>[로그인 성공]</h1>");
				out.println(" <a href='/work/work04/logout'>로그아웃</a>&nbsp;&nbsp;");
				out.println("<a href='/work/work04/sellerUpdateForm'>회원정보수정</a>&nbsp;&nbsp;");
				out.println("<a href='/work/work04/productList'>상품목록보기</a>&nbsp;&nbsp;");
				out.println("<a href='/work/work04/product/productAddForm.html'>상품등록하기</a>&nbsp;&nbsp;");
				out.println("<hr>" + entity.getSellerName() + "님 어서오십시요.<br>");

			} else {
				out.println("<h1>[로그인 실패]</h1><br>");
				out.println("<hr>아이디 또는 비밀번호가 틀립니다.<br>다시 로그인 하세요<br>");
				out.println("<a href='/work/work04/loginForm.html'>로그인</a>");
			}

		}

		out.println("</body></html>");
	}
}// end class
