package work04.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work04.data.PurchaserCollection;
import work04.entity.PurchaserEntity;
import work04.util.ValidationUtil;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work04.PurchaserUpdate", urlPatterns = { "/work04/purchaserUpdate" })
public class PurchaserUpdateServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			String purchaserId = request.getParameter("purchaserId");
			String purchaserPw = request.getParameter("purchaserPw");
			String purchaserName = request.getParameter("purchaserName");
			String purchaserAddr = request.getParameter("purchaserAddr");
			String purchaserPhone1 = request.getParameter("purchaserPhone1");
			String purchaserPhone2 = request.getParameter("purchaserPhone2");
			String purchaserPhone3 = request.getParameter("purchaserPhone3");
			String purchaserEmail = request.getParameter("purchaserEmail");

			String purchaserPhone = purchaserPhone1 + "-" + purchaserPhone2
					+ "-" + purchaserPhone3;

			PurchaserEntity entity = new PurchaserEntity(purchaserId,
					purchaserPw, purchaserName, purchaserAddr, purchaserPhone,
					purchaserEmail);

			if (!ValidationUtil.checkRequired(purchaserId)
					|| !ValidationUtil.checkAlphaDigit(purchaserId)
					|| !ValidationUtil.lessLength(purchaserId, 10)) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[아이디 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/purchaserUpdateForm'>회원 수정</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(purchaserPw)
					|| !ValidationUtil.checkAlphaDigit(purchaserPw)
					|| !ValidationUtil.lessLength(purchaserPw, 10)) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[비밀번호 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/purchaserUpdateForm'>회원 수정</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(purchaserName)
					|| !ValidationUtil.lessLength(purchaserName, 10)) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[이름 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/purchaserUpdateForm'>회원 수정</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(purchaserAddr)) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[주소 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/purchaserUpdateForm'>회원 수정</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(purchaserPhone1)
					|| !ValidationUtil.checkRequired(purchaserPhone2)
					|| !ValidationUtil.checkRequired(purchaserPhone3)
					|| !ValidationUtil.checkDigit(purchaserPhone1)
					|| !ValidationUtil.lessLength(purchaserPhone1, 5)
					|| !ValidationUtil.checkDigit(purchaserPhone2)
					|| !ValidationUtil.lessLength(purchaserPhone2, 5)
					|| !ValidationUtil.checkDigit(purchaserPhone3)
					|| !ValidationUtil.lessLength(purchaserPhone3, 5)) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[전화번호 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/purchaserUpdateForm'>회원 수정</a>");
				out.print("</font>");
				out.print("<center>");

			} else if (!ValidationUtil.checkRequired(purchaserEmail)) {

				out.print("<center>");
				out.print("<font color='red'>");
				out.println("[이메일 정보 오류]");
				out.println("<hr>");
				out.println("<a href='/work/work04/purchaserUpdateForm'>회원 수정</a>");
				out.print("</font>");
				out.print("<center>");

			} else {

				PurchaserCollection data = PurchaserCollection.getInstance();
				boolean result = data.purchaserUpdate(entity);

				if (result) {

					out.println("<h1>[구매자 회원정보 수정 성공]</h1>");
					out.println(" <a href='/work/work04/logout'>로그아웃</a>&nbsp;&nbsp;");
					out.println("<a href='/work/work04/purchaserUpdateForm'>회원정보수정</a>&nbsp;&nbsp;");
					out.println("<a href='/work/work04/productList'>상품목록보기</a><br>&nbsp;&nbsp;");
					out.println("<hr>구매자 회원정보를 수정하였습니다.<br>");

				} else {
					out.println("<h1>[구매자 회원정보 수정 실패]</h1><br>");
					out.println("<hr>");
					out.println("<hr>구매자 회원정보 수정 중 오류가 발생했습니다.<br>");
					out.println("<a href='/work/work04/purchaserUpdateForm'>회원정보수정</a>");
				}

			}
		} else {

			out.print("<center>");
			out.print("<font color='red'>[ 로그인이 필요한 페이지 입니다.]</font>");
			out.println("<hr />");
			out.print("<a href='loginForm.html'>로그인</a>");
			out.print("<center>");
		}
		out.println("</body></html>");

	}

}
