package work04.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work04.data.PurchaserCollection;
import work04.entity.PurchaserEntity;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work04.PurchaserUpdateForm", urlPatterns = { "/work04/purchaserUpdateForm" })
public class PurchaserUpdateFormServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
			PurchaserEntity entity = (PurchaserEntity) session
					.getAttribute("purchaserLogin");

			String purchaserId = entity.getPurchaserId();
			String purchaserPw = entity.getPurchaserPw();
			String purchaserName = entity.getPurchaserName();
			String purchaserAddr = entity.getPurchaserAddr();
			String purchaserPhone = entity.getPurchaserPhone();
			String purchaserPhone1 = purchaserPhone.split("-")[1];
			String purchaserPhone2 = purchaserPhone.split("-")[2];
			String purchaserEmail = entity.getPurchaserEmail();

			PurchaserCollection data = PurchaserCollection.getInstance();

			entity = data.purchaserUpdateForm(purchaserId);

			StringBuffer buffer = new StringBuffer();
			buffer.append("<h1>[구매자 회원정보 수정]</h1>");
			buffer.append(" <a href='/work/work04/logout'>로그아웃</a>&nbsp;&nbsp;");
			buffer.append("<a href='/work/work04/productList'>상품 목록</a>&nbsp;&nbsp;");
			buffer.append("<hr>");
			buffer.append("<form action='/work/work04/purchaserUpdate' method='post'>");
			buffer.append("<input type='hidden' name='purchaserId' value='"
					+ purchaserId + "' />");
			buffer.append("<table border='1'>");
			buffer.append("<tr>");
			buffer.append("<th>아이디</th>");
			buffer.append("<td>" + purchaserId + "</td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>비밀번호</th>");
			buffer.append("<td><input type='password' name='purchaserPw' size='20' value=''></input></td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>이름</th>");
			buffer.append("<td><input type='text' name='purchaserName' size='20' value='"
					+ purchaserName + "'></input></td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>주소</th>");
			buffer.append("<td><input type='text' name='purchaserAddr' size='40' value='"
					+ purchaserAddr + "'></input></td>");
			buffer.append("</tr>");
			buffer.append(" <tr>");
			buffer.append("<th>전화번호</th>");
			buffer.append("<td><select name='purchaserPhone1'>");
			buffer.append("<option value='010'>010</option>");
			buffer.append("</select>");
			buffer.append("-<input type='text' name='purchaserPhone2' size='4' value='"
					+ purchaserPhone1 + "'></input>");
			buffer.append("-<input type='text' name='purchaserPhone3' size='4' value='"
					+ purchaserPhone2 + "'></input>");
			buffer.append("</td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>이메일</th>");
			buffer.append("<td><input type='text' name='purchaserEmail' size='20' value='"
					+ purchaserEmail + "'></input></td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th colspan='2'>");
			buffer.append("<input type='submit' value='수정'></input>");
			buffer.append("<input type='reset' value='초기화'></input>");
			buffer.append("</th>");
			buffer.append("</tr>");
			buffer.append("</table>");
			buffer.append("</form>");

			out.println(buffer.toString());
		} else {

			out.print("<center>");
			out.print("<font color='red'>[ 로그인이 필요한 페이지 입니다.]</font>");
			out.println("<hr />");
			out.print("<a href='loginForm.html'>로그인</a>");
			out.print("<center>");
		}
		out.println("</body></html>");

	}

}
