package work04.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work04.data.SellerCollection;
import work04.entity.SellerEntity;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work04.SellerUpdateForm", urlPatterns = { "/work04/sellerUpdateForm" })
public class SellerUpdateFormServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			SellerEntity entity = (SellerEntity) session
					.getAttribute("sellerLogin");
			String id = entity.getSellerId();

			SellerCollection data = SellerCollection.getInstance();

			entity = data.sellerUpdateForm(id);

			String sellerId = entity.getSellerId();
			String sellerPw = entity.getSellerPw();
			String sellerName = entity.getSellerName();
			String sellerAddr = entity.getSellerAddr();
			String sellerPhone = entity.getSellerPhone();
			String sellerPhone1 = sellerPhone.split("-")[1];
			String sellerPhone2 = sellerPhone.split("-")[2];

			String sellerEmail = entity.getSellerEmail();
			String sellerRegNum = entity.getSellerRegNum();
			String sellerRegNum1 = sellerRegNum.split("-")[0];
			String sellerRegNum2 = sellerRegNum.split("-")[1];
			String sellerRegNum3 = sellerRegNum.split("-")[2];

			String sellerAccount = entity.getSellerAccount();

			StringBuffer buffer = new StringBuffer();
			buffer.append("<h1>[판매자 회원 수정]</h1>");
			buffer.append(" <a href='/work/work04/logout'>로그아웃</a>&nbsp;&nbsp;");
			buffer.append("<a href='/work/work04/productList'>상품목록보기</a>&nbsp;&nbsp;");
			buffer.append("<a href='/work/work04/product/productAddForm.html'>상품등록하기</a>&nbsp;&nbsp;");
			buffer.append("<hr>");
			buffer.append("<form action='/work/work04/sellerUpdate' method='post'>");
			buffer.append("<input type='hidden' name='sellerId' value="
					+ sellerId + "></input>");
			buffer.append("<table border=1>");
			buffer.append("<table border='1'>");
			buffer.append("<tr>");
			buffer.append("<th>아이디</th>");
			buffer.append("<td>" + sellerId + "</td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>비밀번호</th>");
			buffer.append("<td><input type='password' name='sellerPw' size='20'></input></td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>이름</th>");
			buffer.append("<td><input type='text' name='sellerName' size='20' value="
					+ sellerName + "></input></td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>주소</th>");
			buffer.append("<td><input type='text' name='sellerAddr' size='40' value="
					+ sellerAddr + "></input></td>");
			buffer.append("</tr>");
			buffer.append(" <tr>");
			buffer.append("<th>전화번호</th>");
			buffer.append("<td><select name='sellerPhone1'>");
			buffer.append("<option value='010'>010</option>");
			buffer.append("</select>");
			buffer.append(" -<input type='text' name='sellerPhone2' size='4' value="
					+ sellerPhone1 + "></input>");
			buffer.append("-<input type='text' name='sellerPhone3' size='4' value="
					+ sellerPhone2 + "></input>");
			buffer.append(" </td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>이메일</th>");
			buffer.append("<td><input type='text' name='sellerEmail' size='20' value="
					+ sellerEmail + "></input></td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>사업자 등록 번호</th>");
			buffer.append("<td>");
			buffer.append("<input type='text' name='sellerRegNum1' size='5' value="
					+ sellerRegNum1 + "></input>");
			buffer.append("-<input type='text' name='sellerRegNum2' size='5'  value="
					+ sellerRegNum2 + "></input>");
			buffer.append("-<input type='text' name='sellerRegNum3'  size='5' value="
					+ sellerRegNum3 + "></input>");
			buffer.append("</td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th>계좌번호</th>");
			buffer.append("<td><input type='text' name='sellerAccount' size='40' value="
					+ sellerAccount + "></input></td>");
			buffer.append("</tr>");
			buffer.append("<tr>");
			buffer.append("<th colspan='2'>");
			buffer.append("<input type='submit' value='수정'></input>");
			buffer.append("<input type='reset' value='초기화'></input>");
			buffer.append("</th>");
			buffer.append("</tr>");
			buffer.append("</table>");
			buffer.append("</form>");

			out.println(buffer.toString());

		} else {

			out.print("<center>");
			out.print("<font color='red'>[ 로그인이 필요한 페이지 입니다.]</font>");
			out.println("<hr />");
			out.print("<a href='loginForm.html'>로그인</a>");
			out.print("<center>");
		}
		out.println("</body></html>");

	}

}
