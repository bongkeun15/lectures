package work04.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work04.data.ProductCollection;
import work04.entity.ProductEntity;
import work04.entity.SellerEntity;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work04.ProductList", urlPatterns = { "/work04/productList" })
public class ProductListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		
		
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {
		
		String member = (String) session.getAttribute("member");

		ProductCollection productCollection = ProductCollection.getInstance();
		HashMap<String, ProductEntity> list = null;

		

		out.println("<h1>[상품 목록]</h1>");
		out.println(" <a href='/work/work04/logout'>로그아웃</a>&nbsp;&nbsp;");

		if ("purchaser".equals(member)) {

			out.println("<a href='/work/work04/purchaserUpdateForm'>회원정보수정</a>&nbsp;&nbsp;");
			list = productCollection.getProductList();

		} else {

			out.println("<a href='/work/work04/sellerUpdateForm'>회원정보수정</a>&nbsp;&nbsp;");
			out.println("<a href='/work/work04/product/productAddForm.html'>상품 등록</a>&nbsp;&nbsp;");
			SellerEntity entity = (SellerEntity) session
					.getAttribute("sellerLogin");
			list = productCollection.getProductListById(entity.getSellerId());
		}

		out.println("<hr>");
		out.println("<table border=1>");
		out.println("<tr>");
		out.println("<td>번호</td>");
		out.println("<td>상품명</td>");
		out.println("<td>카테고리</td>");
		out.println("<td>가격</td>");
		out.println("<td>제조사</td>");
		out.println("<td>재고</td>");
		out.println("<td>등록일자</td>");
		out.println("</tr>");

		if (list.size() == 0) {
			out.println("<tr>");
			out.println("<td colspan=7>상품 목록이 없습니다.</td>");
			out.println("</tr>");

		} else {

			int i = 0;
			Set<String> keys = list.keySet();
			for (String key : keys) {
				ProductEntity entity = list.get(key);
				out.println("<tr>");
				out.println("<td>" + (i++ + 1) + "</td>");
				out.println("<td>" + entity.getProductName() + "</td>");
				out.println("<td>" + entity.getCategoryId() + "</td>");
				out.println("<td>" + entity.getProductPrice() + "</td>");
				out.println("<td>" + entity.getProductCompany() + "</td>");
				out.println("<td>" + entity.getProductQuantity() + "</td>");
				out.println("<td>" + entity.getProductDate() + "</td>");
				out.println("</tr>");
			}

		}
		out.println("</table>");
		} else {

			out.print("<center>");
			out.print("<font color='red'>[ 로그인이 필요한 페이지 입니다.]</font>");
			out.println("<hr />");
			out.print("<a href='loginForm.html'>로그인</a>");
			out.print("<center>");
		}
		out.println("</body></html>");
	}

}
