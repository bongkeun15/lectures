package work04.data;

import java.util.HashMap;

import work04.entity.ProductEntity;
import work04.entity.PurchaserEntity;

public class ProductCollection {
	private static ProductCollection instance;
	private HashMap<String, ProductEntity> products;
	private  HashMap<String, String> categories;


	private ProductCollection() {
		categories = new HashMap<String, String>();
		categories.put("CNS01_100", "가전-영상");
		categories.put("CNS01_200", "가전-주방");
		categories.put("CNS01_300", "가전-생활");
		categories.put("CNS01_400", "가전-계절");
		categories.put("CNS02_100", "컴퓨터-데스크탑");
		categories.put("CNS02_200", "컴퓨터-노트북");
		categories.put("CNS02_300", "컴퓨터-태블릿");
		categories.put("CNS02_400", "컴퓨터-프리터기");
		categories.put("CNS03_100", "휴대폰-스마트폰");
		categories.put("CNS03_200", "휴대폰-피쳐폰");
		categories.put("CNS03_300", "휴대폰-주변기기");
		categories.put("CNS04_100", "도서-소설");
		categories.put("CNS04_200", "도서-아동");
		categories.put("CNS04_300", "도서-인문");
		categories.put("CNS04_400", "도서-IT");
		categories.put("CNS05_100", "생활-식품");
		categories.put("CNS05_200", "생활-주방");
		
		products = new HashMap<String, ProductEntity>();
		
		
	}

	public static ProductCollection getInstance() {
		if (instance == null) {
			instance = new ProductCollection();
		}
		return instance;
	}

	// 상품 목록 , 구매자 목록 리스트
	public HashMap<String, ProductEntity> getProductList() {
		return products;
	}

	// 상품 목록 , 판매자 목록 리스트
	public HashMap<String, ProductEntity> getProductListById(String id) {
		HashMap<String, ProductEntity> sellList = new HashMap<String, ProductEntity>();

		for (ProductEntity member : products.values()) {
			if (member.getSellerId().trim().equals(id.trim())) {
				sellList.put(member.getProductId(), member);
			}
		}
		return sellList;
	}

	// 상품 저장 , key는 productId
	public boolean productAdd(ProductEntity entity) {

		if (!isExistProduct(entity)) {
			String categoryName = categories.get(entity.getCategoryId());
			entity.setCategoryName(categoryName);
			products.put(entity.getProductId(), entity);
			return true;
		}
		return false;
	}

	// 상품 중복 검사 ( 제품명으로 조건 검사 )
	private boolean isExistProduct(ProductEntity entity) {

		for (ProductEntity member : products.values()) {
			if (member.getProductName().equals(entity.getProductName())) {
				return true;
			}
		}

		return false;
	}

}
