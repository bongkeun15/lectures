package work04.data;

import java.util.HashMap;

import work04.entity.PurchaserEntity;

public class PurchaserCollection {

	private static PurchaserCollection instance;
	private HashMap<String, PurchaserEntity> purchasers;

	public HashMap<String, PurchaserEntity> getPurchasers() {
		return purchasers;
	}

	private PurchaserCollection() {
		
		purchasers = new HashMap<String, PurchaserEntity>();

	}

	public static PurchaserCollection getInstance() {
		if (instance == null) {
			instance = new PurchaserCollection();
		}
		return instance;
	}

	// 구매자 회원 등록
	public boolean purchaserAdd(PurchaserEntity entity) {

		if (!isExistPurchaser(entity)) {
			purchasers.put(entity.getPurchaserId(), entity);
			return true;
		}
		return false;
	}

	// 회원 중복 검사
	private boolean isExistPurchaser(PurchaserEntity entity) {

		for (PurchaserEntity member : purchasers.values()) {
			if (member.getPurchaserId().equals(entity.getPurchaserId())) {
				return true;
			}
		}

		return false;
	}

	// 로그인
	public PurchaserEntity login(String purchaserId, String pwd) {
		for (PurchaserEntity member : purchasers.values()) {
			if (member.getPurchaserId().equals(purchaserId)
					&& member.getPurchaserPw().equals(pwd)) {
				return member;
			}
		}
		return null;
	}

	// 회원수정폼
	public PurchaserEntity purchaserUpdateForm(String id) {

		for (PurchaserEntity member : purchasers.values()) {
			if (member.getPurchaserId().equals(id)) {
				return member;
			}
		}
		return null;
	}

	// 회원수정
	public boolean purchaserUpdate(PurchaserEntity entity) {

		for (PurchaserEntity member : purchasers.values()) {
			if (member.getPurchaserId().equals(entity.getPurchaserId())) {
				purchasers.put(entity.getPurchaserId(), entity);
				return true;
			}
		}
		return false;
	}

}
