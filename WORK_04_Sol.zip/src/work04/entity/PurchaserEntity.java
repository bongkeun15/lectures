package work04.entity;

public class PurchaserEntity {
	
	private String purchaserId; 	// 구매자 아이디
	private String purchaserPw;		// 구매자 비번
	private String purchaserName;	// 구매자 이름
	private String purchaserAddr;	// 구매자 주소
	private String purchaserPhone;	// 구매자 전화번호
	private String purchaserEmail;	// 구매자 이메일

	
	
	public String getPurchaserId() {
		return purchaserId;
	}

	public void setPurchaserId(String purchaserId) {
		this.purchaserId = purchaserId;
	}

	public String getPurchaserPw() {
		return purchaserPw;
	}

	public void setPurchaserPw(String purchaserPw) {
		this.purchaserPw = purchaserPw;
	}

	public String getPurchaserName() {
		return purchaserName;
	}

	public void setPurchaserName(String purchaserName) {
		this.purchaserName = purchaserName;
	}

	public String getPurchaserAddr() {
		return purchaserAddr;
	}

	public void setPurchaserAddr(String purchaserAddr) {
		this.purchaserAddr = purchaserAddr;
	}

	public String getPurchaserPhone() {
		return purchaserPhone;
	}

	public void setPurchaserPhone(String purchaserPhone) {
		this.purchaserPhone = purchaserPhone;
	}

	public String getPurchaserEmail() {
		return purchaserEmail;
	}

	public void setPurchaserEmail(String purchaserEmail) {
		this.purchaserEmail = purchaserEmail;
	}

	

	public PurchaserEntity(String purchaserId, String purchaserPw,
			String purchaserName, String purchaserAddr, String purchaserPhone,
			String purchaserEmail) {
		super();
		this.purchaserId = purchaserId;
		this.purchaserPw = purchaserPw;
		this.purchaserName = purchaserName;
		this.purchaserAddr = purchaserAddr;
		this.purchaserPhone = purchaserPhone;
		this.purchaserEmail = purchaserEmail;


	}

	public PurchaserEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
