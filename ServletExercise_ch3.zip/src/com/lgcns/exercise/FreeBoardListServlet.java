package com.lgcns.exercise;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GuestBookListServlet
 */
@WebServlet(name = "FreeBoardList", urlPatterns = { "/freeboardList" })
public class FreeBoardListServlet extends HttpServlet {

	/**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	    // JDBC 드라이버 및 DB URL 정보
	    String driver = "oracle.jdbc.driver.OracleDriver";
	    String url = "jdbc:oracle:thin:@192.168.0.100:1521:VCC";
	   

	    Connection con = null;
	    PreparedStatement stmt= null;
	    ResultSet rs = null;

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

	    try{
	        //JDBC 드라이버 로딩
    	    Class.forName(driver);
    	    //CONNECTION 획득(본인의 계정 입력)
    	    con = DriverManager.getConnection(url, "student##", "student##");
    	    
    	    
            //쿼리 작성
    	    String sql = "select bnum, content, writeDate, mid from FREEBOARD order by bnum desc";
    	    // STATEMENT 생성
    	    stmt = con.prepareStatement(sql);
            //쿼리 수행
    	    rs = stmt.executeQuery();

            out.println("<html><head><title>한줄 게시판 목록</title>");
            out.println("</head><body>");
    	    out.println("<table border='1'>");

            //수행 결과 처리
    	    while(rs.next()) {

    	        int bnum = rs.getInt("bnum");
    	        String content = rs.getString("content");
    	        String writeDate = rs.getString("writeDate");
    	        String mid = rs.getString("mid");
    	        System.out.println("번호 :"+bnum);
    	        System.out.println("내용 :"+content);
    	        System.out.println("작성일시 :"+writeDate);
    	        System.out.println("작성자ID:"+mid);

                out.println("<tr>");
    	        out.println("<td>" + bnum + "</td>");
    	        out.println("<td>" + content + "</td>");
    	        out.println("<td>" + writeDate + "</td>");
    	        out.println("<td>" + mid + "</td>");
    	        out.println("</tr>");
    	    }

    	    out.println("</table><br/>");
            out.println("</body></html>");

	    } catch(Exception e) {
	        e.printStackTrace();

	        out.println("<html><head><title>오류 발생</title>");
	        out.println("</head><body>");
	        out.println("<font color='red'>");
	        out.println("오류가 발생했습니다.");
	        out.println("</font>");
	        out.println("</body></html>");

	    } finally {
	        try {
	            rs.close();
	            stmt.close();
	            con.close();
	        } catch(Exception e1) {
	            e1.printStackTrace();
	        }
            out.close();
	    }
	}

}
