drop table cart cascade constraints;
drop table category cascade constraints;
drop table grade cascade constraints;
drop table prodcomment cascade constraints;
drop table prodorder cascade constraints;
drop table product cascade constraints;
drop table purchasermember cascade constraints;
drop table sellermember cascade constraints;


--------------------------------------------------------
--  파일이 생성됨 - 일요일-1월-18-2015   
--------------------------------------------------------


--------------------------------------------------------
--  DDL for Table PURCHASERMEMBER
--------------------------------------------------------

  CREATE TABLE "PURCHASERMEMBER" 
   (	"PURCHASER_ID" VARCHAR2(20) PRIMARY KEY, 
	"PURCHASER_PW" VARCHAR2(10) NOT NULL, 
	"PURCHASER_NAME" VARCHAR2(20)  NOT NULL, 
	"PURCHASER_ADDR" VARCHAR2(100)  NOT NULL, 
	"PURCHASER_PHONE" VARCHAR2(15)  NOT NULL, 
	"PURCHASER_EMAIL" VARCHAR2(50)  NOT NULL, 
	"PURCHASER_SCORE" NUMBER(5,0) DEFAULT 0 --회원점수
   );

--------------------------------------------------------
--  DDL for Table SELLERMEMBER
--------------------------------------------------------

  CREATE TABLE "SELLERMEMBER" 
   (	"SELLER_ID" VARCHAR2(20) PRIMARY KEY, 
	"SELLER_PW" VARCHAR2(10)  NOT NULL, 
	"SELLER_NAME" VARCHAR2(20)  NOT NULL, 
	"SELLER_ADDR" VARCHAR2(100)  NOT NULL, 
	"SELLER_PHONE" VARCHAR2(15)  NOT NULL, 
	"SELLER_EMAIL" VARCHAR2(50)  NOT NULL, 
	"SELLER_REG_NUM" VARCHAR2(20)  NOT NULL, 
	"SELLER_ACCOUNT" VARCHAR2(20)  NOT NULL
   );

--------------------------------------------------------
--  DDL for Table CATEGORY
--------------------------------------------------------

  CREATE TABLE "CATEGORY" 
   (	"CATEGORY_ID" VARCHAR2(20) PRIMARY KEY, 
	"CATEGORY_LARGE" VARCHAR2(20), 
	"CATEGORY_MIDDLE" VARCHAR2(20)
   );
   
   -------------------------------------------------------
--  DDL for Table GRADE
--------------------------------------------------------

  CREATE TABLE "GRADE" 
   (	"GRADE_ID" VARCHAR2(10) PRIMARY KEY, 
	"GRADE_MIN" NUMBER(5,0), 
	"GRADE_MAX" NUMBER(5,0)
   );
   
   --------------------------------------------------------
--  DDL for Table PRODUCT
--------------------------------------------------------

  CREATE TABLE "PRODUCT" 
   (	"PRODUCT_ID" VARCHAR2(20) PRIMARY KEY, 
	"CATEGORY_ID" VARCHAR2(20) REFERENCES CATEGORY( CATEGORY_ID), 
	"PRODUCT_NAME" VARCHAR2(30) NOT NULL, 
	"PRODUCT_PRICE" NUMBER(10,0) NOT NULL, 
	"PRODUCT_INFO" VARCHAR2(100) NOT NULL, 
	"PRODUCT_COMPANY" VARCHAR2(20) NOT NULL, 
	"PRODUCT_DATE" DATE DEFAULT SYSDATE, 
	"PRODUCT_QUANTITY" NUMBER(3,0) NOT NULL, 
	"SELLER_ID" VARCHAR2(10) REFERENCES SELLERMEMBER(SELLER_ID) 
   );


--------------------------------------------------------
--  DDL for Table CART
--------------------------------------------------------

  CREATE TABLE "CART" 
   (	"PRODUCT_ID" VARCHAR2(20) NOT NULL, 
	"PURCHASER_ID" VARCHAR2(20) NOT NULL, 
	"CART_QUANTITY" NUMBER(3,0) NOT NULL
   );


--------------------------------------------------------
--  DDL for Table PRODORDER
--------------------------------------------------------

  CREATE TABLE "PRODORDER" 
   (	"ORDER_ID" VARCHAR2(20) PRIMARY KEY, 
	"PRODUCT_ID" VARCHAR2(20) REFERENCES PRODUCT(PRODUCT_ID) , 
	"PURCHASER_ID" VARCHAR2(20) REFERENCES PURCHASERMEMBER(PURCHASER_ID), 
	"ORDER_QUANTITY" NUMBER(3,0) DEFAULT 0, 
	"ORDER_CONFIRM" CHAR(1) DEFAULT 'F', 
	"ORDER_DATE" DATE DEFAULT SYSDATE
   );

--------------------------------------------------------
--  DDL for Table PRODCOMMENT
--------------------------------------------------------

  CREATE TABLE "PRODCOMMENT" 
   (	"ORDER_ID" VARCHAR2(20) REFERENCES PRODORDER (ORDER_ID), 
	"COMM_CONTENT" VARCHAR2(200) NOT NULL,
	"COMM_SCORE" NUMBER(1,0) DEFAULT 1, 
	"COMM_DATE" DATE DEFAULT SYSDATE -- 작성일자  
   );






Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS01_100','가전','영상');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS01_200','가전','주방');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS01_300','가전','생활');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS01_400','가전','계절');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS02_100','컴퓨터','데스크탑');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS02_200','컴퓨터','노트북');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS02_300','컴퓨터','태블릿');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS02_400','컴퓨터','프린터기');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS03_100','휴대폰','스마트폰');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS03_200','휴대폰','피쳐폰');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS03_300','휴대폰','주변기기');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS04_100','도서','소설');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS04_200','도서','아동');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS04_300','도서','인문');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS04_400','도서','IT');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS05_100','생활','식품');
Insert into CATEGORY (CATEGORY_ID,CATEGORY_LARGE,CATEGORY_MIDDLE) values ('CNS05_200','생활','주방');

Insert into GRADE (GRADE_ID,GRADE_MIN,GRADE_MAX) values ('A',1000,10000);
Insert into GRADE (GRADE_ID,GRADE_MIN,GRADE_MAX) values ('B',500,999);
Insert into GRADE (GRADE_ID,GRADE_MIN,GRADE_MAX) values ('C',300,499);
Insert into GRADE (GRADE_ID,GRADE_MIN,GRADE_MAX) values ('D',100,299);
Insert into GRADE (GRADE_ID,GRADE_MIN,GRADE_MAX) values ('E',0,99);

Insert into PURCHASERMEMBER (PURCHASER_ID,PURCHASER_PW,PURCHASER_NAME,PURCHASER_ADDR,PURCHASER_PHONE,PURCHASER_EMAIL,PURCHASER_SCORE) values ('purchaser','1111','구매왕','경기도 고양시','010-1234-4321','purchaser@lgcns.com',0);
Insert into PURCHASERMEMBER (PURCHASER_ID,PURCHASER_PW,PURCHASER_NAME,PURCHASER_ADDR,PURCHASER_PHONE,PURCHASER_EMAIL,PURCHASER_SCORE) values ('hong','1234','홍기동','인천광역시','010-2288-9080','hongs@gmail.com',24);
Insert into PURCHASERMEMBER (PURCHASER_ID,PURCHASER_PW,PURCHASER_NAME,PURCHASER_ADDR,PURCHASER_PHONE,PURCHASER_EMAIL,PURCHASER_SCORE) values ('kims','1111','유관숙','서울시 강남구','010-9876-0987','kims@korea.com',24);
Insert into SELLERMEMBER (SELLER_ID,SELLER_PW,SELLER_NAME,SELLER_ADDR,SELLER_PHONE,SELLER_EMAIL,SELLER_REG_NUM,SELLER_ACCOUNT) values ('cns','1111','판매왕','서울시','010-1111-2222','cns@lgcns.com','123-45-67890','987654321');
Insert into SELLERMEMBER (SELLER_ID,SELLER_PW,SELLER_NAME,SELLER_ADDR,SELLER_PHONE,SELLER_EMAIL,SELLER_REG_NUM,SELLER_ACCOUNT) values ('dapanda','1111','다판다','경기도','010-3333-4444','dapanda@gmail.com','999-12-12345','123456789');


Insert into PRODUCT (PRODUCT_ID,CATEGORY_ID,PRODUCT_NAME,PRODUCT_PRICE,PRODUCT_INFO,PRODUCT_COMPANY,PRODUCT_DATE,PRODUCT_QUANTITY,SELLER_ID) values ('cns1421555790167','CNS02_100','멀티미디어 슬림PC',2200000,'속도빠른 PC','LG전자',to_date('15/01/18','RR/MM/DD'),6,'cns');
Insert into PRODUCT (PRODUCT_ID,CATEGORY_ID,PRODUCT_NAME,PRODUCT_PRICE,PRODUCT_INFO,PRODUCT_COMPANY,PRODUCT_DATE,PRODUCT_QUANTITY,SELLER_ID) values ('cns1421555840160','CNS04_400','Jsp서블릿',24000,'웹 프로그래밍 기초','LGCNS',to_date('15/01/18','RR/MM/DD'),5,'cns');
Insert into PRODUCT (PRODUCT_ID,CATEGORY_ID,PRODUCT_NAME,PRODUCT_PRICE,PRODUCT_INFO,PRODUCT_COMPANY,PRODUCT_DATE,PRODUCT_QUANTITY,SELLER_ID) values ('cns1421555978058','CNS02_100','프리미엄 슬림PC',120000,'향상된 성능','LG전자',to_date('15/01/18','RR/MM/DD'),10,'cns');
Insert into PRODUCT (PRODUCT_ID,CATEGORY_ID,PRODUCT_NAME,PRODUCT_PRICE,PRODUCT_INFO,PRODUCT_COMPANY,PRODUCT_DATE,PRODUCT_QUANTITY,SELLER_ID) values ('dapanda1421556206265','CNS04_100','태백산맥',12000,'태백산맥은..','해냄출판사',to_date('15/01/18','RR/MM/DD'),27,'dapanda');
Insert into PRODUCT (PRODUCT_ID,CATEGORY_ID,PRODUCT_NAME,PRODUCT_PRICE,PRODUCT_INFO,PRODUCT_COMPANY,PRODUCT_DATE,PRODUCT_QUANTITY,SELLER_ID) values ('dapanda1421556238099','CNS04_100','삼국지',15000,'삼국지','민음사',to_date('15/01/18','RR/MM/DD'),50,'dapanda');
Insert into PRODUCT (PRODUCT_ID,CATEGORY_ID,PRODUCT_NAME,PRODUCT_PRICE,PRODUCT_INFO,PRODUCT_COMPANY,PRODUCT_DATE,PRODUCT_QUANTITY,SELLER_ID) values ('cns1420121274763','CNS03_100','G3',980000,'파워풀한 성능','LG전자',to_date('15/01/01','RR/MM/DD'),50,'cns');





Insert into PRODORDER (ORDER_ID,PRODUCT_ID,PURCHASER_ID,ORDER_QUANTITY,ORDER_CONFIRM,ORDER_DATE) values ('2015011800334','cns1421555978058','purchaser',10,'T',to_date('15/01/18','RR/MM/DD'));
Insert into PRODORDER (ORDER_ID,PRODUCT_ID,PURCHASER_ID,ORDER_QUANTITY,ORDER_CONFIRM,ORDER_DATE) values ('2015011800716','dapanda1421556238099','purchaser',10,'F',to_date('15/01/18','RR/MM/DD'));
Insert into PRODORDER (ORDER_ID,PRODUCT_ID,PURCHASER_ID,ORDER_QUANTITY,ORDER_CONFIRM,ORDER_DATE) values ('2015010100918','cns1421555978058','hong',10,'T',to_date('15/01/01','RR/MM/DD'));
Insert into PRODORDER (ORDER_ID,PRODUCT_ID,PURCHASER_ID,ORDER_QUANTITY,ORDER_CONFIRM,ORDER_DATE) values ('2015010100295','cns1421555790167','kims',5,'T',to_date('15/01/01','RR/MM/DD'));
Insert into PRODORDER (ORDER_ID,PRODUCT_ID,PURCHASER_ID,ORDER_QUANTITY,ORDER_CONFIRM,ORDER_DATE) values ('2015010100662','cns1421555840160','kims',10,'T',to_date('15/01/01','RR/MM/DD'));
Insert into PRODORDER (ORDER_ID,PRODUCT_ID,PURCHASER_ID,ORDER_QUANTITY,ORDER_CONFIRM,ORDER_DATE) values ('2015010100983','cns1421555840160','hong',5,'T',to_date('15/01/01','RR/MM/DD'));


Insert into PRODCOMMENT (ORDER_ID,COMM_CONTENT,COMM_SCORE,COMM_DATE) values ('2015010100918','별로네요. 쩝..',3,to_date('15/01/01','RR/MM/DD'));
Insert into PRODCOMMENT (ORDER_ID,COMM_CONTENT,COMM_SCORE,COMM_DATE) values ('2015011800334','굿이에요. ^^',5,to_date('15/01/01','RR/MM/DD'));
Insert into PRODCOMMENT (ORDER_ID,COMM_CONTENT,COMM_SCORE,COMM_DATE) values ('2015010100295','좋아요.....',5,to_date('15/01/01','RR/MM/DD'));
Insert into PRODCOMMENT (ORDER_ID,COMM_CONTENT,COMM_SCORE,COMM_DATE) values ('2015010100662','너무 좋아요',5,to_date('15/01/01','RR/MM/DD'));
Insert into PRODCOMMENT (ORDER_ID,COMM_CONTENT,COMM_SCORE,COMM_DATE) values ('2015010100983','보통이네요',3,to_date('15/01/01','RR/MM/DD'));

Insert into CART (PRODUCT_ID,PURCHASER_ID,CART_QUANTITY) values ('cns1421555790167','purchaser',1);


commit;