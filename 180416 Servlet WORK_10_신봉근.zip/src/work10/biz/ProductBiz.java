package work10.biz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import work10.common.JdbcTemplate;
import work10.entity.MessageEntity;
import work10.entity.ProductEntity;
import work10.exception.CommonException;

public class ProductBiz {

	// 상품등록
	public void productAdd(ProductEntity entity) throws CommonException {

		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		try {

			String sql = "insert into product ( product_id,category_id,product_name,product_price,product_info,product_company,product_quantity,seller_id )" + " values ( ? , ? , ?, ? ,? ,? ,? , ?) ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, entity.getProductId());
			pstmt.setString(2, entity.getCategoryId());
			pstmt.setString(3, entity.getProductName());
			pstmt.setInt(4, entity.getProductPrice());
			pstmt.setString(5, entity.getProductInfo());
			pstmt.setString(6, entity.getProductCompany());
			pstmt.setInt(7, entity.getProductQuantity());
			pstmt.setString(8, entity.getSellerId());

			int result = pstmt.executeUpdate();

			if (result == 0) {
				throw new Exception();
			}
			JdbcTemplate.commit(con);
		} catch (Exception e) {
			JdbcTemplate.rollback(con);
			MessageEntity message = new MessageEntity("error", 7);
			message.setUrl("/work/work10/product/productAddForm.html");
			message.setLinkTitle("상품 등록");
			throw new CommonException(message);
		} finally {

			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(con);
		}

	}

	// 상품 목록
	public ArrayList<ProductEntity> productAllList() throws CommonException {

		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
		try {

			String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date ,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String product_id = rs.getString("product_id");
				String category_id = rs.getString("category_id");
				String product_name = rs.getString("product_name");
				int product_price = rs.getInt("product_price");
				String product_info = rs.getString("product_info");
				String product_company = rs.getString("product_company");
				String product_date = rs.getString("product_date");
				int product_quantity = rs.getInt("product_quantity");
				String seller_id = rs.getString("seller_id");
				String category_name = rs.getString("large") + "-" + rs.getString("middle");
				ProductEntity entity = new ProductEntity(product_id, category_id, product_name, product_price, product_company, product_quantity, product_info, product_date, seller_id);
				entity.setCategoryName(category_name);
				list.add(entity);
			}
		} catch (Exception e) {
			MessageEntity message = new MessageEntity("error", 8);
			message.setUrl("/work/work10/login");
			message.setLinkTitle("로그인");
			throw new CommonException(message);
		} finally {

			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(con);
		}
		return list;
	}

	public ArrayList<ProductEntity> productList(String id) throws CommonException {

		Connection con = JdbcTemplate.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
		try {
			String sql = "select product_id, p.category_id,product_name,product_price,product_info,product_company,to_char(product_date,'yyyy-MM-dd') product_date,product_quantity,seller_id, c.category_large as large , c.category_middle as middle from product p, category c where p.category_id = c.category_id and seller_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				String product_id = rs.getString("product_id");
				String category_id = rs.getString("category_id");
				String product_name = rs.getString("product_name");
				int product_price = rs.getInt("product_price");
				String product_info = rs.getString("product_info");
				String product_company = rs.getString("product_company");
				String product_date = rs.getString("product_date");
				int product_quantity = rs.getInt("product_quantity");
				String seller_id = rs.getString("seller_id");
				String category_name = rs.getString("large") + "-" + rs.getString("middle");
				ProductEntity entity = new ProductEntity(product_id, category_id, product_name, product_price, product_company, product_quantity, product_info, product_date, seller_id);
				entity.setCategoryName(category_name);
				list.add(entity);
			}
		} catch (Exception e) {
			MessageEntity message = new MessageEntity("error", 8);
			message.setUrl("/work/work10/login");
			message.setLinkTitle("로그인");
			throw new CommonException(message);
		} finally {

			JdbcTemplate.close(rs);
			JdbcTemplate.close(pstmt);
			JdbcTemplate.close(con);
		}

		return list;
	}

    // 구매자 상품 검색
    public ArrayList<ProductEntity> productPurchaserSearch(String searchName, String searchValue) throws CommonException {

        /*
         * 1. searchName과 searchValue 인자를 사용하여 검색 목록을 리턴한다.
         */
        Connection con = JdbcTemplate.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
        String sql = null;
        
        try {
            
//            System.out.println( "productBiz 오류 1" );
            if (searchName.equals( "productName" )) {
                System.out.println( "productBiz / productName 검색" );
            // 상품명 검색
            sql = " select                                           " +    
                  " product_id,                                      " +   // 1 상품아이디
                  " product_name,                                    " +   // 2 상품명
                  " c.category_large||'-'||c.category_middle ctgr,   " +   // 3 카테고리
                  " product_price,                                   " +   // 4 가격
                  " product_company,                                 " +   // 5 제조사
                  " product_quantity,                                " +   // 6 재고 
                  " to_char(product_date,'yyyy-MM-dd') product_date, " +   // 7 등록일자
                                                                     
                  " p.category_id,                                   " +   // 8  불필요
                  " product_info,                                    " +   // 9  불필요
                  " seller_id                                        " +   // 10 불필요
                                                                     
                  " from product p, category c                       " +    
                                                                     
                  " where p.category_id = c.category_id              " +   
                  " and p.product_name like ?                        " ;
            
            } else {
                System.out.println( "productBiz / company 검색" );
            // 제조사 검색
            sql = " select                                           " +    
                  " product_id,                                      " +   // 1 상품아이디
                  " product_name,                                    " +   // 2 상품명
                  " c.category_large||'-'||c.category_middle ctgr,   " +   // 3 카테고리
                  " product_price,                                   " +   // 4 가격
                  " product_company,                                 " +   // 5 제조사
                  " product_quantity,                                " +   // 6 재고 
                  " to_char(product_date,'yyyy-MM-dd') product_date, " +   // 7 등록일자
                                                                     
                  " p.category_id,                                   " +   // 8  불필요
                  " product_info,                                    " +   // 9  불필요
                  " seller_id                                        " +   // 10 불필요
                                                                     
                  " from product p, category c                       " +    
                                                                     
                  " where p.category_id = c.category_id              " +   
                  " and p.product_company like ?                     " ;
            
            }
            
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, "%" + searchValue + "%");
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
//                System.out.println( "productBiz while 시작" );
            
                String product_id       = rs.getString( 1 );
                String product_name     = rs.getString( 2 );
                String category_name    = rs.getString( 3 );
                int    product_price    = rs.getInt   ( 4 );
                String product_company  = rs.getString( 5 );
                int    product_quantity = rs.getInt   ( 6 );
                String product_date     = rs.getString( 7 );
                
                String category_id      = rs.getString( 8 );
                String product_info     = rs.getString( 9 );
                String seller_id        = rs.getString( 10 );
                
                ProductEntity entity = new ProductEntity(product_id, category_id, product_name, product_price, product_company,
                                                         product_quantity, product_info, product_date, seller_id);
                
                entity.setCategoryName(category_name);
                
                list.add(entity);
                
//                System.out.println( "productBiz while 끝" );
            }
            
            
        } catch (Exception e) {
            System.out.println( "에러 !! " );
            
        } finally {
            try {
                rs.close();
                pstmt.close();
                con.close();
            } catch ( SQLException e ) {
                System.out.println( "SQL 에러 !! " );
                e.printStackTrace();
            }
        }
        
        return list;
    }

	// 판매자 상품 검색
    public ArrayList<ProductEntity> productSellerSearch(String sellerId, String searchName, String searchValue) throws CommonException {

        /*
         * 1. searchName과 searchValue 인자를 사용하여 sellerId와 일치하는 판매자가 등록한 검색 목록을
         * 리턴한다.
         */
        Connection con = JdbcTemplate.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<ProductEntity> list = new ArrayList<ProductEntity>();
        String sql = null;
        
        try {
            
//            System.out.println( "productBiz 오류 1" );
            if (searchName.equals( "productName" )) {
//                System.out.println( "productBiz 오류 2" );
            // 상품명 검색
            sql = " select                                           " +    
                  " product_id,                                      " +   // 1 상품아이디
                  " product_name,                                    " +   // 2 상품명
                  " c.category_large||'-'||c.category_middle ctgr,   " +   // 3 카테고리
                  " product_price,                                   " +   // 4 가격
                  " product_company,                                 " +   // 5 제조사
                  " product_quantity,                                " +   // 6 재고 
                  " to_char(product_date,'yyyy-MM-dd') product_date, " +   // 7 등록일자
                                                                     
                  " p.category_id,                                   " +   // 8  불필요
                  " product_info,                                    " +   // 9  불필요
                  " seller_id                                        " +   // 10 불필요
                                                                     
                  " from product p, category c                       " +    
                                                                     
                  " where p.category_id = c.category_id              " +   
                  " and p.product_name like ?                        " ;
            
            } else {
//                System.out.println( "productBiz 오류 3" );
            // 제조사 검색
            sql = " select                                           " +    
                  " product_id,                                      " +   // 1 상품아이디
                  " product_name,                                    " +   // 2 상품명
                  " c.category_large||'-'||c.category_middle ctgr,   " +   // 3 카테고리
                  " product_price,                                   " +   // 4 가격
                  " product_company,                                 " +   // 5 제조사
                  " product_quantity,                                " +   // 6 재고 
                  " to_char(product_date,'yyyy-MM-dd') product_date, " +   // 7 등록일자
                                                                     
                  " p.category_id,                                   " +   // 8  불필요
                  " product_info,                                    " +   // 9  불필요
                  " seller_id                                        " +   // 10 불필요
                                                                     
                  " from product p, category c                       " +    
                                                                     
                  " where p.category_id = c.category_id              " +   
                  " and p.product_company like ?                     " ;
            
            }
            
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, "%" + searchValue + "%");
            rs = pstmt.executeQuery();
            System.out.println( "productBiz 오류 7" );
            
            while (rs.next()) {
            
                String product_id       = rs.getString( 1 );
                String product_name     = rs.getString( 2 );
                String category_name    = rs.getString( 3 );
                int    product_price    = rs.getInt   ( 4 );
                String product_company  = rs.getString( 5 );
                int    product_quantity = rs.getInt   ( 6 );
                String product_date     = rs.getString( 7 );
                
                String category_id      = rs.getString( 8 );
                String product_info     = rs.getString( 9 );
                String seller_id        = rs.getString( 10 );
                
                ProductEntity entity = new ProductEntity(product_id, category_id, product_name, product_price, product_company,
                                                         product_quantity, product_info, product_date, seller_id);
                
                entity.setCategoryName(category_name);
                
                list.add(entity);
                
            }
            
            
        } catch (Exception e) {
            System.out.println( "에러 !! " );
            
        } finally {
            try {
                rs.close();
                pstmt.close();
                con.close();
            } catch ( SQLException e ) {
                System.out.println( "SQL 에러 !! " );
                e.printStackTrace();
            }
           
        }
        
        return list;
    }
}// end class