package work10.entity;

import java.util.ArrayList;
import java.util.HashMap;

public class MessageEntity {
	// HashMap<Type, ArrayList<Message>>
	private static HashMap<String, ArrayList<String>> messageList = new HashMap<String, ArrayList<String>>();
	static {
		ArrayList<String> error = new ArrayList<String>();

		error.add("[로그인 오류]"); // 0
		error.add("[로그아웃 오류]"); // 1
		error.add("[장바구니 담기 오류]"); // 2
		error.add("[장바구니 수정 오류]"); // 3
		error.add("[장바구니 삭제 오류]"); // 4
		error.add("[장바구니 조회 오류]"); // 5
		error.add("[상품 구매 오류]"); // 6
		error.add("[상품 등록 오류]"); // 7
		error.add("[상품 조회 오류]"); // 8
		error.add("[회원 등록 오류]"); // 9
		error.add("[회원 수정 오류]"); // 10
		error.add("[구매 조회 오류]"); // 11
		error.add("[구매 확정 오류]"); // 12
		error.add("[구매 취소 오류]"); // 13
		error.add("[구매후기 작성 오류]"); // 14
		error.add("[제품상세 보기 오류]"); // 15
		error.add("[판매자 관리 오류]"); // 16
		
		ArrayList<String> validation = new ArrayList<String>();
		// 상품 등록 관련 오류

		validation.add("[아이디 정보 오류]"); 	//0
		validation.add("[비밀번호 정보 오류]"); //1
		validation.add("[이름 정보 오류]"); 	//2
		validation.add("[주소 정보 오류]"); 	//3
		validation.add("[전화번호 정보 오류]");	//4
		validation.add("[이메일 정보 오류]");	//5
		validation.add("[사업자 등록번호 정보 오류]");	//6
		validation.add("[계좌번호 정보 오류]");			//7
		validation.add("[장바구니 수량 정보 오류]");		//8

		validation.add("[카테고리 정보 오류]");			//9
		validation.add("[상품명 정보 오류]");			//10
		validation.add("[가격 정보 오류]");			//11
		validation.add("[제조사 정보 오류]");			//12
		validation.add("[수량 정보 오류]");			//13
		validation.add("[상품 소개 정보 오류]");		//14

		ArrayList<String> success = new ArrayList<String>();
		success.add("[로그인 성공]"); // 0
		success.add("[로그아웃 성공]"); // 1
		success.add("[장바구니 담기 성공]"); // 2
		success.add("[장바구니 수정 성공]"); // 3
		success.add("[장바구니 삭제 성공]"); // 4
		success.add("[상품 구매 성공]"); // 5
		success.add("[상품 등록 성공]"); // 6
		success.add("[회원 등록 성공]"); // 7
		success.add("[회원 수정 성공]"); // 8
		success.add("[구매 확정 성공]"); // 9
		success.add("[구매 취소 성공]"); // 10
		success.add("[구매후기 작성 성공]"); // 11

		ArrayList<String> message = new ArrayList<String>();
		message.add("[이 페이지는 로그인이 필요합니다.]");

		messageList.put("error", error); // 0
		messageList.put("validation", validation);// 1
		messageList.put("success", success); // 2
		messageList.put("message", message); // 3
	}
	private String url;
	private String linkTitle;
	private String type;
	private int index;

	public MessageEntity() {
		/*
		 * ArrayList<String> error = new ArrayList<String>();
		 * error.add("[학과검색 오류]"); error.add("[교수정보 등록 오류]");
		 * error.add("[로그인 오류]"); error.add("[교수정보 수정 오류]");
		 * error.add("[내 강의과목 검색 오류]"); error.add("[개설가능과목 검색 오류]");
		 * error.add("[강의 하기 오류]"); error.add("[강의 중복 등록 오류]");
		 * error.add("[폐강 적용 오류]"); error.add("[설문 검색 오류]");
		 * error.add("[성적 조회 오류]"); error.add("[성적 수정 오류]");
		 * 
		 * ArrayList<String> validation = new ArrayList<String>();
		 * validation.add("[아이디 정보 오류]"); validation.add("[비밀번호 정보 오류]");
		 * validation.add("[이름 정보 오류]"); validation.add("[주소 정보 오류]");
		 * 
		 * ArrayList<String> success = new ArrayList<String>();
		 * success.add("[교수정보 등록 성공]"); success.add("[교수 로그인 성공]");
		 * success.add("[교수정보 수정 성공]");
		 * 
		 * ArrayList<String> message = new ArrayList<String>();
		 * message.add("[이 페이지는 로그인이 필요합니다.]");
		 * 
		 * messageList.put("error", error); messageList.put("validation",
		 * validation); messageList.put("success", success);
		 * messageList.put("message", message);
		 */
	}

	public MessageEntity(String type, int index) {
		// this();

		this.type = type;
		this.index = index;
	}

	public String getMessage() {
		return messageList.get(type).get(index);
	}

	public String getUrl() {
		return url;
	}

	public String getLinkTitle() {
		return linkTitle;
	}

	public String getType() {
		return type;
	}

	public int getIndex() {
		return index;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setLinkTitle(String linkTitle) {
		this.linkTitle = linkTitle;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setIndex(int index) {
		this.index = index;
	}

}
