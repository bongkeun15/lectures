/*
 *  1. 상품 검색 서블릿
 *   - 로그인이 성공후에 사용 가능하다.
 */

package work10.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work10.biz.ProductBiz;
import work10.entity.ProductEntity;
import work10.entity.SellerEntity;
import work10.exception.CommonException;



public class ProductSearchServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		
		/*
		 *  1. productList.jsp의 파라미터 값을 얻는다.
		 *  
		 *  2. 구매자가 상품 검색한 경우에는 ProductBiz의 productPurchaserSearch()메소드를 요청하고
		 *     판매자가 상품 검색한 경우에는 ProductBiz의 productSellerSearch() 메소드를 요청한다.
		 *     
		 *  3. 실행결과를 저장하고 productList.jsp로 RequestDispatcher 처리하여 상품검색 목록을 
		 *     출력한다.
		 *   
		 *  4. 로그인이 되지 않은 상황에서 요청이 된 경우에는 다음 방법으로 메시지를 출력한다.
		 *   
		 *     MessageEntity message = new MessageEntity("message", 0);
			   message.setUrl("loginForm.html");
			   message.setLinkTitle("로그인");
			   session.setAttribute("message", message);
			   response.sendRedirect("message.jsp");
		 *   
		 */
        request.setCharacterEncoding( "UTF-8" );
        HttpSession session = request.getSession();
        
        String searchName = request.getParameter( "searchName" );
        String searchValue = request.getParameter( "searchValue" );
        
        String member = (String) session.getAttribute( "member" );
        
        ProductBiz pb = new ProductBiz();

        if (member.equals( "purchaser" )) {
            try {
                
                ArrayList<ProductEntity> list = pb.productPurchaserSearch( searchName, searchValue );
                request.setAttribute( "productList", list );
                request.setAttribute( "searchWord", searchValue );
                RequestDispatcher rd = request.getRequestDispatcher("/work10/product/productList.jsp");
                rd.forward( request, response );
                
            } catch ( CommonException e ) {
                e.printStackTrace();
            }
            
            
        } else if (member.equals( "seller" )) {
            
            try {
                session.getAttribute( "sellerLogin" );
                
                SellerEntity entity = (SellerEntity) session.getAttribute( "sellerLogin" );
                String sellerId = entity.getSellerId();
                
                ArrayList<ProductEntity> list = pb.productSellerSearch( sellerId, searchName, searchValue );
                request.setAttribute( "productList", list );
                
                RequestDispatcher rd = request.getRequestDispatcher("/work10/product/productList.jsp");
                rd.forward( request, response );
                
            } catch ( CommonException e ) {
                e.printStackTrace();
            }
            
            
        } else {
            System.out.println( "로그인이 필요하다 !" );
        }
    }
}
