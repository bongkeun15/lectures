package work10.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work10.biz.PurchaserBiz;
import work10.entity.MessageEntity;
import work10.entity.PurchaserEntity;
import work10.exception.CommonException;
import work10.util.ValidationUtil;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work10.PurchaserUpdate", urlPatterns = { "/work10/purchaserUpdate" })
public class PurchaserUpdateServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		if (session.getAttribute("member") != null) {

			// 파라미터 추출
			String purchaserId = request.getParameter("purchaserId");
			String purchaserPw = request.getParameter("purchaserPw");
			String purchaserName = request.getParameter("purchaserName");
			String purchaserAddr = request.getParameter("purchaserAddr");
			String purchaserPhone1 = request.getParameter("purchaserPhone1");
			String purchaserPhone2 = request.getParameter("purchaserPhone2");
			String purchaserPhone3 = request.getParameter("purchaserPhone3");
			String purchaserEmail = request.getParameter("purchaserEmail");
			int purchaserScore = Integer.parseInt(request
					.getParameter("purchaserScore"));

			String purchaserPhone = purchaserPhone1 + "-" + purchaserPhone2
					+ "-" + purchaserPhone3;

			PurchaserEntity entity = new PurchaserEntity(purchaserId,
					purchaserPw, purchaserName, purchaserAddr, purchaserPhone,
					purchaserEmail, purchaserScore);

			if (!ValidationUtil.checkRequired(purchaserId)
					|| !ValidationUtil.checkAlphaDigit(purchaserId)
					|| !ValidationUtil.lessLength(purchaserId, 10)) {

				MessageEntity message = new MessageEntity("validation", 0);
				message.setUrl("/work/work10/purchaserUpdateForm");
				message.setLinkTitle("회원 등록");
//				session.setAttribute("message", message);
				request.setAttribute("message", message);
				
			} else if (!ValidationUtil.checkRequired(purchaserPw)
					|| !ValidationUtil.checkAlphaDigit(purchaserPw)
					|| !ValidationUtil.lessLength(purchaserPw, 10)) {

				MessageEntity message = new MessageEntity("validation", 1);
				message.setUrl("/work/work10/purchaserUpdateForm");
				message.setLinkTitle("회원 등록");
//              session.setAttribute("message", message);
                request.setAttribute("message", message);

			} else if (!ValidationUtil.checkRequired(purchaserName)
					|| !ValidationUtil.lessLength(purchaserName, 10)) {

				MessageEntity message = new MessageEntity("validation", 2);
				message.setUrl("/work/work10/purchaserUpdateForm");
				message.setLinkTitle("회원 등록");
//              session.setAttribute("message", message);
                request.setAttribute("message", message);
				
			} else if (!ValidationUtil.checkRequired(purchaserAddr)) {

				MessageEntity message = new MessageEntity("validation", 3);
				message.setUrl("/work/work10/purchaserUpdateForm");
				message.setLinkTitle("회원 등록");
//              session.setAttribute("message", message);
                request.setAttribute("message", message);
				
			} else if (!ValidationUtil.checkRequired(purchaserPhone1)
					|| !ValidationUtil.checkRequired(purchaserPhone2)
					|| !ValidationUtil.checkRequired(purchaserPhone3)
					|| !ValidationUtil.checkDigit(purchaserPhone1)
					|| !ValidationUtil.lessLength(purchaserPhone1, 5)
					|| !ValidationUtil.checkDigit(purchaserPhone2)
					|| !ValidationUtil.lessLength(purchaserPhone2, 5)
					|| !ValidationUtil.checkDigit(purchaserPhone3)
					|| !ValidationUtil.lessLength(purchaserPhone3, 5)) {

				MessageEntity message = new MessageEntity("validation", 4);
				message.setUrl("/work/work10/purchaserUpdateForm");
				message.setLinkTitle("회원 등록");
//              session.setAttribute("message", message);
                request.setAttribute("message", message);
				
			} else if (!ValidationUtil.checkRequired(purchaserEmail)) {

				MessageEntity message = new MessageEntity("validation", 5);
				message.setUrl("/work/work10/purchaserUpdateForm");
				message.setLinkTitle("회원 등록");
//              session.setAttribute("message", message);
                request.setAttribute("message", message);
				
			} else {
				PurchaserBiz biz = new PurchaserBiz();

				try {
					biz.purchaserUpdate(entity);

					// 성공
					MessageEntity message = new MessageEntity("success", 8);
					message.setUrl("/work/work10/productList");
					message.setLinkTitle("상품 목록보기");
//	                session.setAttribute("message", message);
	                request.setAttribute("message", message);

				} catch (CommonException e) {
					request.setAttribute("message", e.getMessageEntity());
				}
			}
			
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
//          session.setAttribute("message", message);
            request.setAttribute("message", message);
			
		}
//		response.sendRedirect("message.jsp");
		RequestDispatcher rd = request.getRequestDispatcher( "message.jsp" );
        rd.forward( request, response );
		
	}

}
