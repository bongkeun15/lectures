package work10.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import work10.biz.CartBiz;
import work10.entity.CartEntity;
import work10.entity.MessageEntity;
import work10.entity.PurchaserEntity;
import work10.exception.CommonException;

/**
 * Servlet implementation class ProductAddServlet
 */

@WebServlet(name = "work10.ProductCartUpdate", urlPatterns = { "/work10/productCartUpdate" })
public class ProductCartUpdateServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();

		if (session.getAttribute("member") != null) {
			String productId = request.getParameter("productId"); // 상품 아이디
			String purchaserId = ((PurchaserEntity) request.getSession()
					.getAttribute("purchaserLogin")).getPurchaserId();
			int cartQuantity = Integer.parseInt(request
					.getParameter("cartQuantity"));

			CartBiz biz = new CartBiz();

			try {

				CartEntity entity = new CartEntity();
				entity.setProductId(productId);
				entity.setPurchaserId(purchaserId);
				entity.setCartQuantity(cartQuantity);
				biz.productUpdateCart(entity);

				// 성공
				MessageEntity message = new MessageEntity("success", 3);
				message.setUrl("/work/work10/productCartList");
				message.setLinkTitle("장바구니 목록");
//				session.setAttribute("message", message);
				request.setAttribute("message", message);

			} catch (CommonException e) {
				request.setAttribute("message", e.getMessageEntity());

			}
		} else {
			MessageEntity message = new MessageEntity("message", 0);
			message.setUrl("loginForm.html");
			message.setLinkTitle("로그인");
			request.setAttribute("message", message);
			
		}
//		response.sendRedirect("message.jsp");
		RequestDispatcher rd = request.getRequestDispatcher( "message.jsp" );
        rd.forward( request, response );
	}

}
