package com.lgcns.workshop4;

public class Phone {
	String userName;
	int callMinute;
	int data;
	int freeCallMinute;
	int freeData;
	boolean planYn;
	
	public void registerCallingPlan(){
		System.out.println("[알림] " + userName + "님이 요금제에 가입하셨습니다. 무료 통화 : 200분  무료 데이터 : 350MB\n");
		this.freeCallMinute = 200;
		this.freeData = 350;
		this.planYn = true;
	}
	
	public void doCall(int call){
		if(call <= 0){
			System.out.println("[에러] 음수만큼 통화를 사용할 수 없습니다.");
		} else {
			System.out.println("[알림] " + userName + "님이 " + call + "분 통화했습니다." );
			callMinute += call;
			if(callMinute >= freeCallMinute && callMinute - call <= freeCallMinute && planYn){
				System.out.println("[알림] 모든 무료 통화를 소진하였습니다.");
			}else if(freeCallMinute != 0){
				System.out.println("[알림] 남은 무료 통화 : " + ( freeCallMinute - callMinute > 0 ? freeCallMinute - callMinute : 0 ) + "분");
			}
		}
		System.out.println();
	}
	
	public void doInternet(int data){
		if(data <= 0){
			System.out.println("[에러] 음수만큼 데이터를 사용할 수 없습니다.");
		} else {
			System.out.println("[알림] " + userName + "님이  데이터를 " + data + "MB 사용하였습니다." );
			this.data += data;
			if(data >= freeData && this.data - data <= freeData && planYn){
				System.out.println("[알림] 모든 무료 데이터를 소진하였습니다.");
			}else if(freeData != 0){
				System.out.println("[알림] 남은 무료 데이터 : " + ( freeData - this.data > 0 ? freeData - this.data : 0 ) + "MB");
			}
		}
		System.out.println();
	}
	
	public int calculateTotalFee(){
		int callPrice = (freeCallMinute - callMinute >= 0 ? 0 : (callMinute - freeCallMinute) * 110 );
		int dataPrice = (freeData - data >= 0 ? 0 : (data - freeData) * 50 );
		int planFee = (planYn ? 18000 : 0);
		return callPrice + dataPrice + planFee;
	}
	
	public void printPhoneInfo(){
		System.out.println("====================");
		System.out.println("고객명 : " + this.userName);
		if(planYn){
			System.out.println("무료 통화량 : " + freeCallMinute + "분");
			System.out.println("무료 데이터 : " + freeData + "MB");
		}
		System.out.println("통화 초과 사용량 : " + (callMinute - freeCallMinute >= 0 ? callMinute - freeCallMinute : 0 ) + "분");
		System.out.println("데이터 초과 사용량 : " + (data - freeData >= 0 ? data - freeData : 0 ) + "MB");
		System.out.println("이 달의 청구요금 : " + calculateTotalFee() + "원");
		System.out.println("====================\n");
	}
}
