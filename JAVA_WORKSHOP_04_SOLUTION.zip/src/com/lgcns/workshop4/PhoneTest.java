package com.lgcns.workshop4;

public class PhoneTest {

	public static void main(String[] args) {
		Phone user1 = new Phone();
		user1.userName = "철수";
		
		user1.registerCallingPlan();
		
		user1.doCall(150);
		user1.doCall(-30);
		user1.doInternet(100);
		user1.doCall(30);
		user1.doInternet(450);
		user1.doInternet(-50);
		user1.doInternet(30);
		
		user1.printPhoneInfo();
		
		
		Phone user2 = new Phone();
		user2.userName = "영희";
		
		user2.doCall(-300);
		user2.doCall(20);
		user2.doInternet(230);
		user2.doCall(210);
		user2.doInternet(150);
		user2.doInternet(-10);
		
		user2.printPhoneInfo();
	}

}
