package work02.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import work02.util.ValidationUtil;

@WebServlet(name = "work02.PurchaserAdd", urlPatterns = { "/work02/purchaserAdd" })
public class PurchaserAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String purchaserId = request.getParameter("purchaserId");
		String purchaserPw = request.getParameter("purchaserPw");
		String purchaserName = request.getParameter("purchaserName");
		String purchaserAddr = request.getParameter("purchaserAddr");
		String purchaserPhone1 = request.getParameter("purchaserPhone1");
		String purchaserPhone2 = request.getParameter("purchaserPhone2");
		String purchaserPhone3 = request.getParameter("purchaserPhone3");
		String purchaserEmail = request.getParameter("purchaserEmail");
		String purchaserPhone = purchaserPhone1 + "-" + purchaserPhone2 + "-"
				+ purchaserPhone3;

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		if (!ValidationUtil.checkRequired(purchaserId)
				|| !ValidationUtil.checkAlphaDigit(purchaserId)
				|| !ValidationUtil.lessLength(purchaserId, 10)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[아이디 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/purchaser/purchaserForm.html'>구매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(purchaserPw)
				|| !ValidationUtil.checkAlphaDigit(purchaserPw)
				|| !ValidationUtil.lessLength(purchaserPw, 10)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[비밀번호 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/purchaser/purchaserForm.html'>구매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(purchaserName)
				|| !ValidationUtil.lessLength(purchaserName, 10)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[이름 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/purchaser/purchaserForm.html'>구매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");
		} else if (!ValidationUtil.checkRequired(purchaserAddr)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[주소 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/purchaser/purchaserForm.html'>구매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(purchaserPhone1)
				|| !ValidationUtil.checkRequired(purchaserPhone2)
				|| !ValidationUtil.checkRequired(purchaserPhone3)
				|| !ValidationUtil.checkDigit(purchaserPhone1)
				|| !ValidationUtil.lessLength(purchaserPhone1, 5)
				|| !ValidationUtil.checkDigit(purchaserPhone2)
				|| !ValidationUtil.lessLength(purchaserPhone2, 5)
				|| !ValidationUtil.checkDigit(purchaserPhone3)
				|| !ValidationUtil.lessLength(purchaserPhone3, 5)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[전화번호 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/purchaser/purchaserForm.html'>구매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(purchaserEmail)) {

			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[이메일 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/purchaser/purchaserForm.html'>구매 회원 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else {
			out.println("아이디: " + purchaserId + "<br>");
			out.println("비밀번호: " + purchaserPw + "<br>");
			out.println("이름: " + purchaserName + "<br>");
			out.println("주소: " + purchaserAddr + "<br>");
			out.println("전화번호: " + purchaserPhone + "<br>");
			out.println("이메일: " + purchaserEmail + "<br>");

		}
		out.println("</body></html>");
	}

}// end class
