

/*
 * 	클래스 파일: ProductAddServlet.java
 *  맵핑명: work02.ProductAdd
 *  urlPattern: /work02/productAdd
 *  기능: 상품 등록
 *  구현: 상품입력폼 유효성 검사 필요하며 조건은 다음과 같다.
 *  
 *   - 가격, 수량은 숫자만 입력해야 한다.
     - 수량은 3자리를 초과할 수 없다.
     - 모든 항목은 반드시 값을 입력해야 한다.

 *  
 * 
 * 
 */
package work02.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import work02.util.ValidationUtil;

@WebServlet(name = "work02.ProductAdd", urlPatterns = { "/work02/productAdd" })
public class ProductAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String categoryId = request.getParameter("categoryId");
		String productName = request.getParameter("productName");
		String productPrice = request.getParameter("productPrice");
		String productCompany = request.getParameter("productCompany");
		String productQuantity = request.getParameter("productQuantity");
		String productInfo = request.getParameter("productInfo");

		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();
		out.println("<html><body>");

		if (!ValidationUtil.checkRequired(categoryId)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[카테고리 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productName)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[상품명 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productPrice)
				|| !ValidationUtil.checkDigit(productPrice)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[가격 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productCompany)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[제조사 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productQuantity)
				|| !ValidationUtil.checkDigit(productQuantity)
				|| !ValidationUtil.lessLength(productQuantity, 4)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[수량 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else if (!ValidationUtil.checkRequired(productInfo)) {
			out.print("<center>");
			out.print("<font color='red'>");
			out.println("[상품 소개 정보 오류]");
			out.println("<hr>");
			out.println("<a href='/work/work02/product/productAddForm.html'>상품 등록</a>");
			out.print("</font>");
			out.print("<center>");

		} else {

			out.println("카테고리: " + categoryId + "<br>");
			out.println("상품명: " + productName + "<br>");
			out.println("가격: " + productPrice + "<br>");
			out.println("제조사: " + productCompany + "<br>");
			out.println("수량: " + productQuantity + "<br>");
			out.println("소개: " + productInfo + "<br>");

		}

		out.println("</body></html>");

	}

}
