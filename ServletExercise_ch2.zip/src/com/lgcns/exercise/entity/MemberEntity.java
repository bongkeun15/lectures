package com.lgcns.exercise.entity;

public class MemberEntity {
	private String mid;
	private String pwd;
	private String name;
	
	public MemberEntity(){
		
	}

	public MemberEntity(String mid, String pwd, String name) {	
		this.mid = mid;
		this.pwd = pwd;
		this.name = name;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
