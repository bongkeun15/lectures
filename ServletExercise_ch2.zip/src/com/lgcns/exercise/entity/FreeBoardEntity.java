package com.lgcns.exercise.entity;

public class FreeBoardEntity {

	private int bnum;
	private String mid;
	private String writeDay;
	private String content;

	public FreeBoardEntity() {

	}

	public FreeBoardEntity(int bnum, String mid, String writeDay, String content) {
		this.bnum = bnum;
		this.mid = mid;
		this.writeDay = writeDay;
		this.content = content;
	}

	public String getWriteDay() {
		return writeDay;
	}	

	public int getBnum() {
		return bnum;
	}

	public void setBnum(int bnum) {
		this.bnum = bnum;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public void setWriteDay(String writeDay) {
		this.writeDay = writeDay;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
