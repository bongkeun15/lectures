package com.lgcns.exercise.biz;


public class FreeBoardBiz {

	

}
