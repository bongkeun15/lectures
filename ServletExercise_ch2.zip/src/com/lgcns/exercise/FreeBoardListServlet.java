package com.lgcns.exercise;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lgcns.exercise.biz.FreeBoardBiz;
import com.lgcns.exercise.data.FreeBoardCollection;
import com.lgcns.exercise.entity.FreeBoardEntity;

/**
 * Servlet implementation class GuestBookListServlet
 */
@WebServlet(name = "FreeBoardList", urlPatterns = { "/freeboardList" })
public class FreeBoardListServlet extends HttpServlet {

	/**
     *
     */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        long current = System.currentTimeMillis();
		SimpleDateFormat dateTime = new SimpleDateFormat("HH:mm:ss");
		String currentTime = dateTime.format(new Date(current));
		
        out.println("<html><head><title>한줄 게시판 목록</title>");
        out.println("</head><body>");
	    out.println("<table border='1'>");
	    out.println("<tr>");
        out.println("<td>1</td>");
        out.println("<td>첫번째 내용입니다.</td>");
        out.println("<td>" + currentTime + "</td>");
        out.println("<td>test</td>");
        out.println("</tr>");
	    out.println("</table><br/>");
        out.println("</body></html>");

		
	}

}
