package com.lgcns.exercise.data;

import java.util.ArrayList;

import com.lgcns.exercise.entity.MemberEntity;

public class MemberCollection {
	private static MemberCollection instance;
	private ArrayList<MemberEntity> list;

	private MemberCollection() {
		list = new ArrayList<MemberEntity>();
		list.add(new MemberEntity("test", "test", "테스트"));
	}

	public static MemberCollection getInstance() {
		if (instance == null) {
			instance = new MemberCollection();
		}
		return instance;
	}

	public MemberEntity login(String mid, String pwd) {
		for(MemberEntity member : list){
			if(member.getMid().equals(mid) && member.getPwd().equals(pwd)){
				return member;
			}
		}
		return null;
	}
}
