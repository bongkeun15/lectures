package com.lgcns.exercise.data;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.lgcns.exercise.entity.FreeBoardEntity;


public class FreeBoardCollection {
	private static FreeBoardCollection instance;
	private ArrayList<FreeBoardEntity> list;
	private FreeBoardCollection(){
		list=new ArrayList<FreeBoardEntity>();
		list.add(new FreeBoardEntity(1, "test", "2013-02-09 16:37:14", "첫번째 내용입니다."));
		
	}
	public static FreeBoardCollection getInstance(){
		if(instance==null){
			instance=new FreeBoardCollection();
		}
		return instance;
	}
	public ArrayList<FreeBoardEntity> list(){
		return list;
	}
	public void write(String mid, String content){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String wdate = sdf.format(new Date());
		list.add(new FreeBoardEntity(list.size()+1, mid, wdate, content));
	}
}
