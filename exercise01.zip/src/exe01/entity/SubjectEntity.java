package exe01.entity;

public class SubjectEntity {
	
	private String subjectId;			// 과목 아이디
	private String subjectName;			// 과목 명
	private String subjectInfo;			// 과목 설명
	private String professorId;			// 교수 아이디
	private String professorName;		// 교수 명
	private int score;					// 학점
	private String survey = "미평가";		// 설문 작성 여부

}
