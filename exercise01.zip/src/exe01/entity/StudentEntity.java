package exe01.entity;

public class StudentEntity {
	
	private String studentId;			// 학생 아이디
	private String studentPass;			// 학생 비밀번호
	private String studentName;			// 학생 명
	private String department;			// 학과
	private String studentAddr;			// 학생 주소
	
}
