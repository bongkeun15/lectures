package exe01.entity;

public class DepartmentEntity {
	
	private String deptCode;		// 학과 코드
	private String deptName;		// 학과 명
	
}
