package exe01.entity;

import java.util.ArrayList;
import java.util.HashMap;

public class MessageEntity {

	private HashMap<String, ArrayList<String>> messageList = new HashMap<String, ArrayList<String>>();
	private String url;
	private String linkTitle;
	private String type;
	private int index;
	
	public MessageEntity() {

		ArrayList<String> error = new ArrayList<String>();
		error.add("[학과검색 오류]");			// 0
		error.add("[학생정보 등록 오류]");		// 1
		error.add("[로그인 오류]");			// 2
		error.add("[학생정보 수정 오류]");		// 3
		error.add("[수강 신청 오류]");			// 4
		error.add("[설문 등록 오류]");			// 5
		
		ArrayList<String> validation = new ArrayList<String>();
		validation.add("[아이디 정보 오류]");		// 0
		validation.add("[비밀번호 정보 오류]");		// 1
		validation.add("[이름 정보 오류]");		// 2
		validation.add("[주소 정보 오류]");		// 3
		
		ArrayList<String> success = new ArrayList<String>();
		success.add("[학생정보 등록 성공]");	// 0
		success.add("[학생 로그인 성공]");		// 1
		success.add("[학생정보 수정 성공]");	// 2
		success.add("[수강 신청 성공]");		// 3
		success.add("[설문등록 성공]");		// 4
		success.add("[로그아웃 성공]");		// 5
		
		ArrayList<String> message = new ArrayList<String>();
		message.add("[이 페이지는 로그인이 필요합니다.]");	// 0
		
		messageList.put("error", error);
		messageList.put("validation", validation);
		messageList.put("success", success);
		messageList.put("message", message);
	}
	
	public MessageEntity(String type, int index) {
		this();
		
		this.type = type;
		this.index = index;
	}

	public String getMessage() {
		return messageList.get(type).get(index);
	}

	public String getUrl() {
		return url;
	}

	public String getLinkTitle() {
		return linkTitle;
	}

	public String getType() {
		return type;
	}

	public int getIndex() {
		return index;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setLinkTitle(String linkTitle) {
		this.linkTitle = linkTitle;
	}

}
