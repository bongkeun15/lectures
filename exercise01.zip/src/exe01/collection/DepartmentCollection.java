package exe01.collection;

import java.util.ArrayList;

import exe01.entity.DepartmentEntity;

public class DepartmentCollection {
	private static DepartmentCollection collection = new DepartmentCollection();
	private ArrayList<DepartmentEntity> departmentList = new ArrayList<DepartmentEntity>();
	
	private DepartmentCollection() {
		DepartmentEntity dept01 = new DepartmentEntity();
		DepartmentEntity dept02 = new DepartmentEntity();
		DepartmentEntity dept03 = new DepartmentEntity();
		
		dept01.setDeptCode("d01");
		dept01.setDeptName("국문학과");
		dept02.setDeptCode("d02");
		dept02.setDeptName("영문학과");
		dept03.setDeptCode("d03");
		dept03.setDeptName("소프웨어공학과");	
		
		departmentList.add(dept01);
		departmentList.add(dept02);
		departmentList.add(dept03);
	}
	
	public static DepartmentCollection getInstance() {
		return collection;
	}
	
	public ArrayList<DepartmentEntity> getDepartmentList() {
		return departmentList;
	}
}
