package exe01.collection;

import java.util.HashMap;

import exe01.entity.StudentEntity;

public class StudentCollection {
	
	// Key는 학생 아이디 이다.
	private HashMap<String, StudentEntity> studentList = new HashMap<String, StudentEntity>();
	private static StudentCollection collection = new StudentCollection();
	
	private StudentCollection() {
		StudentEntity dto = new StudentEntity();
		dto.setStudentId("cns");
		dto.setStudentPass("exercise");
		dto.setDepartment("d03");
		dto.setStudentName("신입생");
		dto.setStudentAddr("서울");
		
		studentList.put("cns", dto);
	}

	public static StudentCollection getInstance() {
		return collection;
	}
	
	/*
	 *  1. 새로운 학생정보를 저장하는 메소드이다.
	 *  2. parameter로 전달된 StudentEntity 객체를 이용하여 이미 등록된 학생인지 확인한다.
	 *    2.1 학생 정보가 이미 존재하면 0을 return 한다.
	 *    2.2 학생 정보가 새로운 것이면 HashMap에 저장하고 1을 return 한다.
	 */
	public int addStudent(StudentEntity student) {

	}

	/*
	 *  1. 로그인 체크를 위한 메소드이다.
	 *  2. 학생아이디를 이용하여 StudentEntity 객체를 찾는다.
	 *  3. 전달받은 학생 비밀번호와 StudentEntity에 저장된 학생 비밀번호가 같은지 확인한다.
	 *    3.1 아이디와 비밀번호가 맞으면 StudentEntity 객체를 return 한다.
	 *    3.2 아이디와 비밀번호가 하나라도 틀릴 경우 NULL을 return 한다.
	 */
	public StudentEntity findStudent(String studentId, String studentPass) {

	}

	/*
	 *  1. 학생정보를 수정하는 메소드이다.
	 *  2. parameter로 전달된 StudentEntity 객체를 이용하여 등록된 학생인지 확인한다.
	 *    2.1 학생정보를 찾은 경우 전달받은 새로운 StudentEntity로 갱신하고 1을 return 한다.
	 *    2.2 학생정보를 찾지 못할 경우 0을 return 한다.
	 */
	public int updateStudent(StudentEntity student) {

	}

}
