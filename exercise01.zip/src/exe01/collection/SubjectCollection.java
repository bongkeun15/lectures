package exe01.collection;

import java.util.ArrayList;

import exe01.entity.SubjectEntity;

public class SubjectCollection {
	private static SubjectCollection collection = new SubjectCollection();
	private ArrayList<SubjectEntity> subjectList = new ArrayList<SubjectEntity>();
	
	private SubjectCollection() {
		SubjectEntity sub01 = new SubjectEntity();
		SubjectEntity sub02 = new SubjectEntity();
		SubjectEntity sub03 = new SubjectEntity();
		
		sub01.setSubjectId("s01");
		sub01.setSubjectName("Java");
		sub01.setSubjectInfo("자바 언어 기본");
		sub01.setProfessorId("p01");
		sub01.setProfessorName("홍길동");
		sub01.setScore(95);
		
		sub02.setSubjectId("s02");
		sub02.setSubjectName("Database");
		sub02.setSubjectInfo("오라클 데이터베이스");
		sub02.setProfessorId("p02");
		sub02.setProfessorName("강감찬");	
		sub03.setScore(85);
		
		sub03.setSubjectId("s03");
		sub03.setSubjectName("Servlet");
		sub03.setSubjectInfo("서블릿 & JSP");
		sub03.setProfessorId("p03");
		sub03.setProfessorName("이순신");	
		sub03.setScore(75);
		
		subjectList.add(sub01);
		subjectList.add(sub02);
		subjectList.add(sub03);		
	}

	public static SubjectCollection getInstance() {
		return collection;
	}

	/*
	 *  1. 모든 개설과목을 검색하는 메소드이다.
	 *  2. ArrayList에 저장된 모든 정보를 return 한다.
	 */
	public ArrayList<SubjectEntity> searchSubject() {

	}

	/*
	 *  1. 과목 아이디를 이용하여 하나의 개설과목을 검색하는 메소드이다.
	 *  2. ArrayList에 저장된 학과 중 parameter로 전달된 학과가 있는지 검색하고 결과를 return 한다.
	 *  2. 검색 결과 학과가 존재하지 않으면 NULL을 return 한다.
	 */
	public SubjectEntity searchSubject(String subjectId) {

	}
}
