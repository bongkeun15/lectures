package exe01.collection;

import java.util.HashMap;

import exe01.entity.SubjectEntity;

public class CourseRegistrationCollection {

	// HashMap<학생아이디, HashMap<과목아이디, SubjectEntity>>
	private HashMap<String, HashMap<String, SubjectEntity>> courseRegistrationList = new HashMap<String, HashMap<String, SubjectEntity>>();
	private static CourseRegistrationCollection collection = new CourseRegistrationCollection();
	
	private CourseRegistrationCollection() {}
	
	public static CourseRegistrationCollection getInstance() {
		return collection;
	}
	
	/*
	 *  1. 학과에 개설된 개설과목 중 선택한 과목에 대해 수강신청하는 메소드 이다.
	 *  2. 학생 아이디를 이용하여 학생이 신청한 수강신청 목록을 검색한다.
	 *    2.1 검색한 수강신청 목록의 결과가 NULL일 경우 학생이 최초의 수강신청을 한 것이다.
	 *      2.1.1 새로운 수강과목을 저장할 HashMap 객체를 생성한다.
	 *      2.1.2 전달받은 과목을 HashMap에 저장한다.
	 *      2.1.3 새롭게 만들어진 HashMap을 courseRegistrationList에 추가한다.
	 *      2.1.4 추가에 성공하면 1을 return 한다.
	 *    
	 *    2.2 검색한 수강신청 목록의 결과가 있을 경우
	 *      2.2.1 전달받은 과목이 수강신청 목록에 이미 저장되어 있는 확인한다.
	 *        2.2.1.1 전달받은 과목이 이미 저장되어 있으면 0을 return 한다.
	 *        2.2.1.2 전달받은 과목이 저장되어 있지 않으면 그 과목을 HashMap에 추가하고 1을 return 한다. 
	 */
	public int addCourseRegistration(SubjectEntity subject, String studentId) {

	}

	/*
	 *  1. 학생이 신청한 수강신청 목록을 검색하는 메소드 이다.
	 *  2. 학생 아이디를 이용하여 수강과목을 검색하고 검색한 결과인 HashMap 객체를 return 한다.
	 */
	public HashMap<String, SubjectEntity> searchCourseRegistration(String studentId) {

	}

	/*
	 *  1. 수강신청 과목에 대해 설문 정보를 등록하는 메소드 이다.
	 *  2. 학생이 신청한 수강과목 목록을 검색한다.
	 *  3. 수강과목 목록 중 설문을 저장할 과목을 검색한다.
	 *  4. 수강과목에 대해 설문을 저장한다.
	 *  5. 설문이 완료되면 1을 return 하고, 그 이외의 경우 0을 return 한다.
	 */
	public int insertSurvey(String studentId, String subjectId, String survey) {

	}

}
