package exe01.biz;

import java.util.HashMap;

import exe01.collection.CourseRegistrationCollection;
import exe01.entity.SubjectEntity;

public class CourseRegistrationBiz {

	/*
	 *  1. CourseRegistrationCollection 객체를 얻는다.
	 *  2. collection 객체의 addCourseRegistration()를 호출하고 그 결과를 return 한다.
	 */
	public int addCourseRegistration(SubjectEntity subject, String studentId) {

	}

	/*
	 *  1. CourseRegistrationCollection 객체를 얻는다.
	 *  2. collection 객체의 searchCourseRegistration()를 호출하고 그 결과를 return 한다.
	 */
	public HashMap<String, SubjectEntity> searchCourseRegistration(String studentId) {

	}

	/*
	 *  1. CourseRegistrationCollection 객체를 얻는다.
	 *  2. collection 객체의 insertSurvey()를 호출하고 그 결과를 return 한다.
	 */
	public int insertSurvey(String studentId, String subjectId, String survey) {

	}

}
