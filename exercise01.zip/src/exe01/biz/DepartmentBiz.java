package exe01.biz;

import java.util.ArrayList;

import exe01.collection.DepartmentCollection;
import exe01.entity.DepartmentEntity;

public class DepartmentBiz {

	/*
	 *  1. DepartmentCollection 객체를 얻는다.
	 *  2. collection 객체의 getDepartmentList()를 호출하고 그 결과를 return 한다.
	 */
	public ArrayList<DepartmentEntity> getDepartmentList() {
		DepartmentCollection collection = DepartmentCollection.getInstance();
		
		return collection.getDepartmentList();
	}
	
}
