package exe01.biz;

import java.util.ArrayList;

import exe01.collection.SubjectCollection;
import exe01.entity.SubjectEntity;

public class SubjectBiz {

	/*
	 *  1. SubjectCollection 객체를 얻는다.
	 *  2. collection 객체의 searchSubject()를 호출하고 그 결과를 return 한다.
	 */
	public ArrayList<SubjectEntity> searchSubject() {

	}

	/*
	 *  1. SubjectCollection 객체를 얻는다.
	 *  2. collection 객체의 searchSubject(subjectId)를 호출하고 그 결과를 return 한다.
	 */
	public SubjectEntity searchSubject(String subjectId) {

	}
	
}
