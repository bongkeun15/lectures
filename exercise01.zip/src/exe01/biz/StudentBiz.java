package exe01.biz;

import exe01.collection.StudentCollection;
import exe01.entity.StudentEntity;

public class StudentBiz {

	/*
	 *  1. StudentCollection 객체를 얻는다.
	 *  2. collection 객체의 addStudent()를 호출하고 그 결과를 return 한다.
	 */
	public int addStudent(StudentEntity dto) {
		int result = 0;
		
		StudentCollection collection = StudentCollection.getInstance();
		result = collection.addStudent(dto);
		
		return result;
	}

	/*
	 *  1. StudentCollection 객체를 얻는다.
	 *  2. collection 객체의 findStudent()를 호출하고 그 결과를 return 한다.
	 */
	public StudentEntity findStudent(String studentId, String studentPass) {
		StudentCollection collection = StudentCollection.getInstance();
		
		return collection.findStudent(studentId, studentPass);
	}

	/*
	 *  1. StudentCollection 객체를 얻는다.
	 *  2. collection 객체의 updateStudent()를 호출하고 그 결과를 return 한다.
	 */
	public int updateStudent(StudentEntity dto) {
		StudentCollection collection = StudentCollection.getInstance();
		
		return collection.updateStudent(dto);
	}

}
