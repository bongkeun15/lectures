package exe01.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.CourseRegistrationBiz;
import exe01.biz.SubjectBiz;
import exe01.entity.MessageEntity;
import exe01.entity.StudentEntity;
import exe01.entity.SubjectEntity;

@WebServlet(name="exe01.CourseRegistrationServlet", urlPatterns={"/exe01/courseRegistration"})
public class CourseRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. session에 StudentEntity가 저장되어 있지 않으면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : message code 0
	 *    	-. 연결 URL : /exercise/exe01/welcome.html
	 *    	-. 링크 문자 : 처음으로
	 *    
	 *  2. 수강신청을 위해 parameter를 받는다.
	 *  
	 *  3. 전달받은 parameter를 이용하여 SubjectBiz 객체의 searchSubject()를 호출하고 그 결과를 받는다.
	 *  
	 *  4. CourseRegistrationBiz 객체의 addCourseRegistration()를 사용하여 수강신청을 하고, 그 결과를 받는다.
	 *     (성공 시 return 1, 실패 시 return 0)
	 *    4.1 수강신청에 성공하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : success code 3
	 *    	-. 연결 URL : /exercise/exe01/courseRegistrationList
	 *    	-. 링크 문자 : 수강과목
	 *    4.2 수강신청에 실패하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : error code 4
	 *    	-. 연결 URL : /exercise/exe01/subjectList
	 *    	-. 링크 문자 : 수강신청    
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}
}
