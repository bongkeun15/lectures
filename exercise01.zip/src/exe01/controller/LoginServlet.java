package exe01.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.StudentBiz;
import exe01.entity.MessageEntity;
import exe01.entity.StudentEntity;

@WebServlet(name="exe01.LoginServlet", urlPatterns={"/exe01/login"})
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. 로그인을 위해 전달된 parameter를 받는다.
	 *    1.1 학생 아이디는 NULL이어서는 안되고, 10자를 초과할 수 없다.
	 *    	-. code : validation code 0
	 *    1.2 학생 비밀번호는 NULL이어서는 안되고, 10자를 초과할 수 없다.
	 *    	-. code : validation code 1
	 *    1.3 위 조건을 만족하지 않으면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. 연결 URL : /exercise/exe01/student/login.html
	 *    	-. 링크 문자 : 학생 로그인
	 *  
	 *  2. StudentBiz 객체의 findStudent()를 호출하고 그 결과를 받는다.
	 *     
	 *    2.1 로그인 성공의 경우 학생정보를 담은 StudentEntity 객체가 return 된다.
	 *    2.2 로그인 실패의 경우 null이 return 된다.
	 *    2.3 로그인에 성공하면 성공하면 Session에 StudentEntity 객체를 저장하고 
	 *        message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : success code 1
	 *    	-. 연결 URL : /exercise/exe01/student/main.jsp
	 *    	-. 링크 문자 : 학생 메인으로
	 *    2.4 로그인에 실패하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : error code 2
	 *    	-. 연결 URL : /exercise/exe01/student/login.html
	 *    	-. 링크 문자 : 학생 로그인   
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
