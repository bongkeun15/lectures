package exe01.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.StudentBiz;
import exe01.entity.MessageEntity;
import exe01.entity.StudentEntity;

@WebServlet(name="exe01.UpdateStudentServlet", urlPatterns={"/exe01/updateStudent"})
public class UpdateStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. 학생 수정을 위해 전달된 parameter를 받는다.
	 *    1.1 비밀번호는 NULL이어서는 안되고, 10자를 초과할 수 없다.
	 *    	-. code : validation code 1
	 *    1.2 학생이름은 NULL이어서는 안되고, 10자를 초과할 수 없다.
	 *    	-. code : validation code 2
	 *    1.3 주소는 NULL이어서는 안된다.
	 *    	-. code : validation code 3
	 *    1.4 위 조건을 만족하지 않으면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. 연결 URL : /exercise/exe01/student/updateStudent.jsp
	 *    	-. 링크 문자 : 학생 정보수정
	 *  
	 *  2. jsp에서 전달된 데이터를 session에 저장된 StudentEntity에 저장한다.
	 *  
	 *  3. StudentBiz 객체의 updateStudent()를 호출하여 학생 정보를 수정하고, 그 결과를 받는다.
	 *     (성공 시 return 1, 실패 시 return 0)
	 *    3.1 학생정보 수정에 성공하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : success code 2
	 *    	-. 연결 URL : /exercise/exe01/student/main.jsp
	 *    	-. 링크 문자 : 학생 메인으로
	 *    3.2 학생정보 수정에 실패하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : error code 3
	 *    	-. 연결 URL : /exercise/exe01/student/updateStudent.jsp
	 *    	-. 링크 문자 : 학생 정보수정    
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
