package exe01.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.StudentBiz;
import exe01.entity.MessageEntity;
import exe01.entity.StudentEntity;

@WebServlet(name="exe01.EnrollStudentServlet", urlPatterns={"/exe01/enrollStudent"})
public class EnrollStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/*
	 *  1. 학생정보 등록을 위해 전달된 parameter를 받는다.
	 *    1.1 학생 아이디는 NULL이어서는 안되고, 10자를 초과할 수 없다.
	 *      -. code : validation code 0
	 *    1.2 비밀번호는 NULL이어서는 안되고, 10자를 초과할 수 없다.
	 *    	-. code : validation code 1
	 *    1.3 학생이름은 NULL이어서는 안되고, 10자를 초과할 수 없다.
	 *    	-. code : validation code 2
	 *    1.4 주소는 NULL이어서는 안된다.
	 *    	-. code : validation code 3
	 *    1.5 위 조건을 만족하지 않으면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. 연결 URL : /exercise/exe01/enrollStudentForm
	 *    	-. 링크 문자 : 학생 등록
	 *  
	 *  2. jsp에서 전달된 데이터를 StudentEntity 객체에 저장한다.
	 *  
	 *  3. StudentBiz 객체의 addStudent()를 호출하여 학생 정보를 저장하고, 그 결과를 받는다.
	 *     (성공 시 return 1, 실패 시 return 0)
	 *    3.1 학생정보 등록에 성공하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : success code 0
	 *    	-. 연결 URL : /exercise/exe01/student/login.html
	 *    	-. 링크 문자 : 로그인
	 *    3.2 학생정보 등록에 실패하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : error code 1
	 *    	-. 연결 URL : /exercise/exe01/enrollStudentForm
	 *    	-. 링크 문자 : 학생 등록   
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
