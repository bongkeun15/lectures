package exe01.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.CourseRegistrationBiz;
import exe01.entity.MessageEntity;
import exe01.entity.StudentEntity;
import exe01.entity.SubjectEntity;

@WebServlet(name="exe01.SearchRecordServlet", urlPatterns={"/exe01/searchRecord"})
public class SearchRecordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. session에 StudentEntity가 저장되어 있지 않으면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : message code 0
	 *    	-. 연결 URL : /exercise/exe01/welcome.html
	 *    	-. 링크 문자 : 처음으로
	 *    
	 *  2. CourseRegistrationBiz 객체의 searchCourseRegistration()를 호출하여 수강신청한 과목의 
	 *     정보를 검색하고, 그 결과를 받는다.
	 *    2.1 return 받은 HashMap 객체를 Session에 저장한다. 
	 *    2.2 정보를 출력하는 scoreList.jsp로 이동한다. 
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
