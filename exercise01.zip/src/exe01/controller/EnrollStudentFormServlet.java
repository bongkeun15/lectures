package exe01.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.DepartmentBiz;
import exe01.entity.DepartmentEntity;
import exe01.entity.MessageEntity;

@WebServlet(name="exe01.EnrollStudentFormServlet", urlPatterns={"/exe01/enrollStudentForm"})
public class EnrollStudentFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/*
	 *  1. DepartmentBiz 객체의 getDepartmentList()를 학과 정보를 검색하고, 그 결과를 받는다.
	 *    1.1 return 받은 학과정보가 null이 아니면 session에 학과정보를 저장한다.
	 *      1.1.1 학생 등록 폼(enrollStudent.jsp)으로 이동한다.
	 *      
	 *    1.2 return 받은 학과정보가 null이면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : error code 0
	 *    	-. 연결 URL : /exercise/exe01/welcome.html
	 *    	-. 링크 문자 : 처음으로  
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
