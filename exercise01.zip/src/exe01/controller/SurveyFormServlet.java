package exe01.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name="exe01.SurveyFormServlet", urlPatterns={"/exe01/surveyForm"})
public class SurveyFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. 설문을 위해 전달된 parameter를 받는다.
	 *  
	 *  2. jsp에서 전달된 데이터를 session에 저장한다.
	 *  
	 *  3. 설문 작성을 위한 폼(surveyForm.jsp)으로 이동한다. 
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
