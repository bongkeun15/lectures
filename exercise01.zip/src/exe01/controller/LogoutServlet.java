package exe01.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.entity.MessageEntity;

@WebServlet(name="exe01.LogoutServlet", urlPatterns={"/exe01/logout"})
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. session을 무효화 시킨다.
	 * 
	 *  2. message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : success code 5
	 *    	-. 연결 URL : /exercise/exe01/welcome.html
	 *    	-. 링크 문자 : 처음으로 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
