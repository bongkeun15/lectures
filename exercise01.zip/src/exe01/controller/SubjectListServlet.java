package exe01.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.SubjectBiz;
import exe01.entity.SubjectEntity;

@WebServlet(name="exe01.SubjectListServlet", urlPatterns={"/exe01/subjectList"})
public class SubjectListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. SubjectBiz 객체의 searchSubject()를 호출하여 개설된 과목 정보를 검색하고, 그 결과를 받는다.
	 *    1.1 return 받은 ArrayList 객체를 Session에 저장한다. 
	 *    1.2 정보를 출력하는 subjectList.jsp로 이동한다. 
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		SubjectBiz biz = new SubjectBiz();
		ArrayList<SubjectEntity> subjectList = biz.searchSubject();
		
		HttpSession session = request.getSession();
		session.setAttribute("subjectList", subjectList);

		response.sendRedirect("/exercise/exe01/student/subjectList.jsp");
	}

}
