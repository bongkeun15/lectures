package exe01.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exe01.biz.CourseRegistrationBiz;
import exe01.entity.MessageEntity;
import exe01.entity.StudentEntity;

@WebServlet(name="exe01.SurveyRegisterServlet", urlPatterns={"/exe01/surveyRegister"})
public class SurveyRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*
	 *  1. session에 StudentEntity가 저장되어 있지 않으면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : message code 0
	 *    	-. 연결 URL : /exercise/exe01/welcome.html
	 *    	-. 링크 문자 : 처음으로
	 *    
	 *  2. 설문 등록을 위해 전달된 parameter를 받는다.
	 *  
	 *  3. CourseRegistrationBiz 객체의 insertSurvey()를 호출하여 설문을 저장하고, 그 결과를 받는다.
	 *     (성공 시 return 1, 실패 시 return 0)
	 *    3.1 설문 작성에 성공하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : success code 4
	 *    	-. 연결 URL : /exercise/exe01/courseRegistrationList
	 *    	-. 링크 문자 : 수강과목
	 *    3.2 설문 작성에 실패하면 message.jsp를 이용하여 메시지를 출력한다.
	 *    	-. code : error code 5
	 *    	-. 연결 URL : /exercise/exe01/courseRegistrationList
	 *    	-. 링크 문자 : 수강과목    
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
